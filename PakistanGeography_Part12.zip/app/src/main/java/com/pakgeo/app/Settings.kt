@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.pakgeo.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(prefs: Prefs, nav: (String) -> Unit, onBack: () -> Unit) {
    var confirm by remember { mutableStateOf<String?>(null) }

    if (confirm != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(tr("Are you sure?", "کیا آپ کو یقین ہے؟")) },
            text = { Text(tr("This cannot be undone.", "یہ عمل واپس نہیں ہو سکتا۔")) },
            confirmButton = {
                TextButton(onClick = {
                    when (confirm) {
                        "progress" -> prefs.resetProgress()
                        "bookmarks" -> prefs.clearBookmarks()
                        else -> prefs.clearScores()
                    }
                    confirm = null
                }) { Text(tr("Yes", "ہاں")) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) { Text(tr("Cancel", "منسوخ")) }
            }
        )
    }

    PageScaffold(tr("Settings", "ترتیبات"), onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionTitle(tr("Language", "زبان"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.lang == "en", onClick = { prefs.changeLang("en") }, label = { Text("English") })
                FilterChip(selected = prefs.lang == "ur", onClick = { prefs.changeLang("ur") }, label = { Text("اردو") })
            }

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Theme", "تھیم"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.themeMode == "system", onClick = { prefs.changeThemeMode("system") }, label = { Text(tr("System", "سسٹم")) })
                FilterChip(selected = prefs.themeMode == "light", onClick = { prefs.changeThemeMode("light") }, label = { Text(tr("Light", "لائٹ")) })
                FilterChip(selected = prefs.themeMode == "dark", onClick = { prefs.changeThemeMode("dark") }, label = { Text(tr("Dark", "ڈارک")) })
            }

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Colour", "رنگ"))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AppColor.values().forEach { ac ->
                    val selected = prefs.colorKey == ac.key
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(ac.light)
                                .border(
                                    if (selected) 3.dp else 0.dp,
                                    MaterialTheme.colorScheme.onBackground,
                                    CircleShape
                                )
                                .clickable { prefs.changeColor(ac.key) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) Text("✓", color = Color.White, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            tr(ac.en, ac.ur), fontSize = 12.sp, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Reading text size", "پڑھنے کی تحریر کا سائز"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.fontSize == 15, onClick = { prefs.changeFontSize(15) }, label = { Text(tr("Small", "چھوٹا")) })
                FilterChip(selected = prefs.fontSize == 17, onClick = { prefs.changeFontSize(17) }, label = { Text(tr("Medium", "درمیانہ")) })
                FilterChip(selected = prefs.fontSize == 20, onClick = { prefs.changeFontSize(20) }, label = { Text(tr("Large", "بڑا")) })
            }
            Text(
                tr("Sample text for reading", "پڑھنے کے لیے نمونہ تحریر"),
                fontSize = prefs.fontSize.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Data", "ڈیٹا"))
            OutlinedButton(onClick = { confirm = "progress" }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Reset reading progress", "پڑھنے کی پیش رفت صاف کریں"))
            }
            OutlinedButton(onClick = { confirm = "bookmarks" }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Clear bookmarks", "بک مارکس صاف کریں"))
            }
            OutlinedButton(onClick = { confirm = "scores" }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("Clear scores, mistakes and streak", "اسکور، غلطیاں اور سلسلہ صاف کریں"))
            }

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Information", "معلومات"))
            OutlinedButton(onClick = { nav("guide") }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("App guidelines", "ایپ ہدایات"))
            }
            OutlinedButton(onClick = { nav("about") }, modifier = Modifier.fillMaxWidth()) {
                Text(tr("About the app", "ایپ کے بارے میں"))
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Pakistan Geography  •  v1.0",
                fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
        }
    }
}

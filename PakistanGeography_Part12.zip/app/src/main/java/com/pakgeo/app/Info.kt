@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pakgeo.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class GuideItem(
    val emoji: String,
    val titleEn: String, val titleUr: String,
    val bodyEn: String, val bodyUr: String
)

private val guideItems = listOf(
    GuideItem("🚀", "Getting started", "شروعات",
        "The dashboard shows all 15 topics. Tap a topic card to see its sections, or tap Book to read chapter by chapter. Use the gear icon at the top to change language, theme and text size.",
        "ڈیش بورڈ پر تمام 15 موضوعات نظر آتے ہیں۔ کسی موضوع کے کارڈ پر ٹیپ کر کے اس کے حصے دیکھیں، یا باب بہ باب پڑھنے کے لیے کتاب پر ٹیپ کریں۔ زبان، تھیم اور تحریر کا سائز بدلنے کے لیے اوپر گیئر کا نشان استعمال کریں۔"),
    GuideItem("📖", "Reading the Book", "کتاب پڑھنا",
        "Open a chapter and swipe left or right to move between sections, or use the Previous and Next buttons. Sections you open are marked as read. Tap the star to bookmark a section.",
        "کوئی باب کھولیں اور حصوں کے درمیان جانے کے لیے دائیں یا بائیں سوائپ کریں، یا پچھلا اور اگلا بٹن استعمال کریں۔ جو حصے آپ کھولیں گے وہ پڑھے ہوئے شمار ہوں گے۔ کسی حصے کو محفوظ کرنے کے لیے ستارے پر ٹیپ کریں۔"),
    GuideItem("🔍", "Search and Bookmarks", "تلاش اور بک مارکس",
        "Search looks in titles and text, in both English and Urdu. Type at least two letters. Bookmarks collects all the sections you starred, so you can return to them quickly.",
        "تلاش عنوانات اور متن دونوں میں، انگریزی اور اردو میں، دیکھتی ہے۔ کم از کم دو حروف لکھیں۔ بک مارکس میں وہ تمام حصے جمع ہوتے ہیں جنہیں آپ نے ستارہ لگایا ہے، تاکہ آپ جلدی واپس آ سکیں۔"),
    GuideItem("📝", "Quiz modes", "کوئز کی اقسام",
        "Quiz: one topic or all, with a difficulty level.\nSelf Test: choose several topics.\nRandom Quiz: random questions from the whole bank, different every time.\nDaily Challenge: 5 questions, one try a day, keeps a streak.\nPast Papers: CSS, PMS and NTS style questions.\nMistakes: practise the questions you got wrong.",
        "کوئز: ایک موضوع یا سب، مشکل کی سطح کے ساتھ۔\nسیلف ٹیسٹ: کئی موضوعات چنیں۔\nرینڈم کوئز: پورے ذخیرے سے بے ترتیب سوالات، ہر بار مختلف۔\nروزانہ چیلنج: 5 سوالات، دن میں ایک کوشش، سلسلہ برقرار رکھتا ہے۔\nپچھلے پرچے: سی ایس ایس، پی ایم ایس اور این ٹی ایس طرز کے سوالات۔\nغلطیاں: جو سوال غلط ہوئے ان کی مشق۔"),
    GuideItem("✍️", "Answering questions", "سوالات کے جواب",
        "Multiple-choice and true/false questions show the right answer and a short reason as soon as you answer. For fill in the blank, type a short answer in English or Urdu; spelling matters. A wrong answer is saved in Mistakes until you answer it correctly.",
        "کثیر انتخابی اور درست غلط سوالات میں جواب دیتے ہی صحیح جواب اور مختصر وجہ نظر آتی ہے۔ خالی جگہ پر کرنے کے لیے انگریزی یا اردو میں مختصر جواب لکھیں؛ ہجے اہم ہیں۔ غلط جواب غلطیوں میں محفوظ ہو جاتا ہے جب تک آپ اسے درست نہ کریں۔"),
    GuideItem("⏱", "Timer", "ٹائمر",
        "In Quiz, Self Test and Past Papers you can set 15, 30 or 60 seconds per question. When time runs out the question counts as wrong and the answer is shown.",
        "کوئز، سیلف ٹیسٹ اور پچھلے پرچوں میں آپ ہر سوال کے لیے 15، 30 یا 60 سیکنڈ مقرر کر سکتے ہیں۔ وقت ختم ہونے پر سوال غلط شمار ہوتا ہے اور جواب دکھایا جاتا ہے۔"),
    GuideItem("🃏", "Flashcards", "فلیش کارڈز",
        "Tap a card to flip it and see the answer. Use I know it for cards you remember and Again for cards you want to see more often. Hide known cards to focus on the rest.",
        "جواب دیکھنے کے لیے کارڈ پر ٹیپ کر کے اسے پلٹیں۔ جو کارڈ آپ کو یاد ہوں ان کے لیے مجھے آتا ہے اور جنہیں بار بار دیکھنا ہو ان کے لیے دوبارہ دبائیں۔ باقی پر توجہ کے لیے جانے ہوئے کارڈ چھپا دیں۔"),
    GuideItem("📊", "Progress and Scores", "پیش رفت اور اسکور",
        "Progress shows how much you have read, by topic. Scores shows your best result for each quiz type and your recent attempts.",
        "پیش رفت موضوع کے لحاظ سے دکھاتی ہے کہ آپ نے کتنا پڑھا ہے۔ اسکور ہر کوئز کی قسم کا بہترین نتیجہ اور حالیہ کوششیں دکھاتا ہے۔"),
    GuideItem("📥", "Saving as PDF", "پی ڈی ایف میں محفوظ کرنا",
        "Open Save PDF from the dashboard or from the Book screen. Choose the whole book, one chapter or one section. Save it to Downloads or share it. The PDF uses the current app language.",
        "ڈیش بورڈ یا کتاب کی اسکرین سے پی ڈی ایف محفوظ کریں کھولیں۔ پوری کتاب، ایک باب یا ایک حصہ چنیں۔ اسے ڈاؤن لوڈز میں محفوظ کریں یا شیئر کریں۔ پی ڈی ایف موجودہ ایپ کی زبان میں بنتی ہے۔"),
    GuideItem("🎯", "A study plan for exams", "امتحان کی تیاری کا منصوبہ",
        "1. Read one chapter from the Book.\n2. Take a Quiz on that topic.\n3. Practise your Mistakes.\n4. Revise with Flashcards.\n5. Finish with Past Papers and Random Quizzes, with a timer, before the exam.\nCheck the numbers in your syllabus book; figures in the app are approximate.",
        "1. کتاب سے ایک باب پڑھیں۔\n2. اسی موضوع پر کوئز دیں۔\n3. اپنی غلطیوں کی مشق کریں۔\n4. فلیش کارڈز سے دہرائی کریں۔\n5. امتحان سے پہلے ٹائمر کے ساتھ پچھلے پرچے اور رینڈم کوئز سے اختتام کریں۔\nاعداد و شمار اپنی نصابی کتاب سے ملا لیں؛ ایپ کے اعداد تقریبی ہیں۔")
)

@Composable
fun GuideScreen(onBack: () -> Unit) {
    val lang = LocalLang.current
    PageScaffold(tr("App guidelines", "ایپ ہدایات"), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(guideItems) { g ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(g.emoji, fontSize = 24.sp)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                if (lang == "ur") g.titleUr else g.titleEn,
                                fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            if (lang == "ur") g.bodyUr else g.bodyEn,
                            fontSize = 15.sp, lineHeight = 25.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    PageScaffold(tr("About the app", "ایپ کے بارے میں"), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🇵🇰", fontSize = 56.sp)
                    Text(
                        tr("Pakistan Geography", "پاکستان جغرافیہ"),
                        fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        tr("Version 1.0", "ورژن 1.0"), fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
            item {
                AboutCard(
                    tr("About", "تعارف"),
                    tr(
                        "Pakistan Geography is a study app in English and Urdu for school, college and competitive-exam students (CSS, PMS, NTS) and anyone who wants to learn about Pakistan's land, rivers, mountains, climate, resources and people.",
                        "پاکستان جغرافیہ انگریزی اور اردو میں ایک مطالعاتی ایپ ہے، جو اسکول، کالج اور مسابقتی امتحانات (سی ایس ایس، پی ایم ایس، این ٹی ایس) کے طلبہ اور پاکستان کی زمین، دریاؤں، پہاڑوں، آب و ہوا، وسائل اور لوگوں کے بارے میں جاننے والے ہر شخص کے لیے ہے۔"
                    )
                )
            }
            item {
                AboutCard(
                    tr("What is inside", "ایپ میں کیا ہے"),
                    tr(
                        "${topics.size} topics, ${allSections.size} sections and ${allQuestions.size} quiz questions.\nBook view, search, bookmarks and progress tracking.\nQuiz, self test, random quiz, daily challenge, past-paper style questions, timer and flashcards.\nQuick facts and Top 10 lists.\nPDF export, themes and text size.",
                        "${topics.size} موضوعات، ${allSections.size} حصے اور ${allQuestions.size} کوئز سوالات۔\nکتاب کا منظر، تلاش، بک مارکس اور پیش رفت کا ریکارڈ۔\nکوئز، سیلف ٹیسٹ، رینڈم کوئز، روزانہ چیلنج، پچھلے پرچوں کے انداز کے سوالات، ٹائمر اور فلیش کارڈز۔\nفوری معلومات اور ٹاپ 10 فہرستیں۔\nپی ڈی ایف، تھیم اور تحریر کا سائز۔"
                    )
                )
            }
            item {
                AboutCard(
                    tr("Please note", "برائے مہربانی نوٹ کریں"),
                    tr(
                        "This app is made for learning. Many numbers (areas, heights, populations, lengths) are approximate and different sources give slightly different figures. For exams, please check important figures against your syllabus book or official sources.",
                        "یہ ایپ سیکھنے کے لیے بنائی گئی ہے۔ بہت سے اعداد (رقبے، بلندیاں، آبادیاں، لمبائیاں) تقریبی ہیں اور مختلف ذرائع میں معمولی فرق ہوتا ہے۔ امتحان کے لیے اہم اعداد اپنی نصابی کتاب یا سرکاری ذرائع سے ملا لیں۔"
                    )
                )
            }
            item {
                AboutCard(
                    tr("Privacy", "رازداری"),
                    tr(
                        "The app works fully offline. It does not ask for your personal details. Your progress, bookmarks, scores and settings are kept only on your phone.",
                        "ایپ مکمل طور پر انٹرنیٹ کے بغیر چلتی ہے۔ یہ آپ سے ذاتی معلومات نہیں مانگتی۔ آپ کی پیش رفت، بک مارکس، اسکور اور ترتیبات صرف آپ کے فون میں محفوظ رہتی ہیں۔"
                    )
                )
            }
        }
    }
}

@Composable
private fun AboutCard(title: String, body: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(body, fontSize = 15.sp, lineHeight = 25.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

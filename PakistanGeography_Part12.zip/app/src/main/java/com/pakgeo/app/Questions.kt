package com.pakgeo.app

/**
 * type: 0 = MCQ, 1 = True/False, 2 = Fill in the blank
 * diff: 0 = Easy, 1 = Medium, 2 = Hard, 3 = CSS/PMS level
 * src: "" or "CSS" / "PMS" / "NTS" (past-paper style)
 */
data class Q(
    val id: String, val topic: Int, val type: Int, val diff: Int, val src: String,
    val qEn: String, val qUr: String,
    val opts: List<Pair<String, String>>, val answer: Int,
    val fibEn: String, val fibUr: String, val alts: List<String>,
    val expEn: String, val expUr: String
)

val allQuestions: List<Q> = questionsPart1 + questionsPart2 + questionsPart3

fun Q.text(lang: String) = if (lang == "ur") qUr else qEn
fun Q.exp(lang: String) = if (lang == "ur") expUr else expEn
fun Q.correctText(lang: String): String =
    if (type == 2) (if (lang == "ur") fibUr else fibEn)
    else opts[answer].let { if (lang == "ur") it.second else it.first }

package com.pakgeo.app

val questionsPart3: List<Q> = listOf(
    // ---- Topic 1 ----
    mcq("1y1", 1, 1, "", "Which is the national language of Pakistan?", "پاکستان کی قومی زبان کون سی ہے؟", 1,
        listOf(o("English", "انگریزی"), o("Urdu", "اردو"), o("Punjabi", "پنجابی"), o("Sindhi", "سندھی")),
        "Urdu is the national language.", "اردو قومی زبان ہے۔"),
    tf("1y2", 1, 0, "", "Pakistan lies in the Northern and Eastern Hemispheres.", "پاکستان شمالی اور مشرقی نصف کرہ میں واقع ہے۔", true,
        "Its latitude is north and its longitude is east.", "اس کا عرض بلد شمالی اور طول بلد مشرقی ہے۔"),
    mcq("1y3", 1, 2, "", "Which country lies across the Arabian Sea from Pakistan's coast?", "پاکستان کے ساحل کے سامنے بحیرہ عرب کے پار کون سا ملک ہے؟", 2,
        listOf(o("India", "بھارت"), o("Afghanistan", "افغانستان"), o("Oman", "عمان"), o("China", "چین")),
        "Oman lies across the sea.", "عمان سمندر کے پار ہے۔"),

    // ---- Topic 2 ----
    mcq("2y1", 2, 1, "", "Which city is called the \"Fruit Garden of Pakistan\"?", "کون سا شہر \"پاکستان کا پھلوں کا باغ\" کہلاتا ہے؟", 0,
        listOf(o("Quetta", "کوئٹہ"), o("Multan", "ملتان"), o("Peshawar", "پشاور"), o("Lahore", "لاہور")),
        "Quetta is famous for its orchards.", "کوئٹہ اپنے باغات کے لیے مشہور ہے۔"),
    mcq("2y2", 2, 0, "", "Which city is called the \"Manchester of Pakistan\"?", "کون سا شہر \"پاکستان کا مانچسٹر\" کہلاتا ہے؟", 2,
        listOf(o("Karachi", "کراچی"), o("Lahore", "لاہور"), o("Faisalabad", "فیصل آباد"), o("Gujranwala", "گوجرانوالہ")),
        "Faisalabad is the textile centre.", "فیصل آباد ٹیکسٹائل کا مرکز ہے۔"),
    tf("2y3", 2, 1, "", "Gilgit-Baltistan has a border with China.", "گلگت بلتستان کی چین کے ساتھ سرحد ہے۔", true,
        "It lies in the far north-east.", "یہ انتہائی شمال مشرق میں ہے۔"),

    // ---- Topic 3 ----
    mcq("3y1", 3, 1, "", "Which of these is the longest glacier?", "ان میں سے طویل ترین گلیشیئر کون سا ہے؟", 0,
        listOf(o("Siachen", "سیاچن"), o("Biafo", "بیافو"), o("Hispar", "ہسپر"), o("Baltoro", "بالتورو")),
        "Siachen is about 76 km long.", "سیاچن تقریباً 76 کلومیٹر لمبا ہے۔"),
    mcq("3y2", 3, 2, "", "Who first climbed Nanga Parbat, in 1953?", "1953 میں نانگا پربت پہلی بار کس نے سر کیا؟", 3,
        listOf(o("Edmund Hillary", "ایڈمنڈ ہلیری"), o("Reinhold Messner", "رین ہولڈ میسنر"), o("Tenzing Norgay", "تینزنگ نورگے"), o("Hermann Buhl", "ہرمن بول")),
        "He climbed it alone on 3 July 1953.", "اس نے اسے 3 جولائی 1953 کو اکیلے سر کیا۔"),
    mcq("3y3", 3, 1, "", "Takht-e-Sulaiman is the highest peak of which range?", "تختِ سلیمان کس سلسلے کی بلند ترین چوٹی ہے؟", 2,
        listOf(o("Kirthar", "کیرتھر"), o("Salt Range", "سالٹ رینج"), o("Sulaiman Range", "کوہ سلیمان"), o("Hindu Kush", "ہندوکش")),
        "It is about 3,487 m high.", "یہ تقریباً 3,487 میٹر بلند ہے۔"),

    // ---- Topic 4 ----
    mcq("4y1", 4, 1, "", "Which dam is the world's largest earth-filled dam by structural volume?", "کون سا ڈیم ساخت کے حجم کے لحاظ سے دنیا کا سب سے بڑا مٹی بھرا ڈیم ہے؟", 0,
        listOf(o("Tarbela", "تربیلا"), o("Mangla", "منگلا"), o("Warsak", "وارسک"), o("Hub", "حب")),
        "Tarbela is on the Indus.", "تربیلا دریائے سندھ پر ہے۔"),
    mcq("4y2", 4, 2, "", "Which river meets the Chenab at Trimmu?", "تریموں کے مقام پر چناب سے کون سا دریا ملتا ہے؟", 1,
        listOf(o("Ravi", "راوی"), o("Jhelum", "جہلم"), o("Sutlej", "ستلج"), o("Kabul", "کابل")),
        "The Jhelum meets the Chenab near Jhang.", "جہلم جھنگ کے قریب چناب سے ملتا ہے۔"),
    tf("4y3", 4, 1, "", "The Kabul River begins in Afghanistan.", "دریائے کابل افغانستان سے شروع ہوتا ہے۔", true,
        "It rises near the Unai Pass.", "یہ درۂ اونائی کے قریب سے نکلتا ہے۔"),

    // ---- Topic 5 ----
    mcq("5y1", 5, 1, "", "Which months are the hottest in Pakistan's plains?", "پاکستان کے میدانوں میں سب سے گرم مہینے کون سے ہیں؟", 0,
        listOf(o("May–June", "مئی جون"), o("December–January", "دسمبر جنوری"), o("August–September", "اگست ستمبر"), o("October–November", "اکتوبر نومبر")),
        "The pre-monsoon heat peaks in May and June.", "مون سون سے پہلے کی گرمی مئی جون میں عروج پر ہوتی ہے۔"),
    tf("5y2", 5, 1, "", "Murree receives snow in winter.", "مری میں سردیوں میں برف باری ہوتی ہے۔", true,
        "Western disturbances bring snow to the hills.", "مغربی ہوائیں پہاڑوں میں برف لاتی ہیں۔"),
    mcq("5y3", 5, 2, "", "Which place is dry because high mountains block the rain?", "کون سی جگہ اس لیے خشک ہے کہ بلند پہاڑ بارش روک لیتے ہیں؟", 2,
        listOf(o("Murree", "مری"), o("Islamabad", "اسلام آباد"), o("Gilgit", "گلگت"), o("Kaghan", "کاغان")),
        "Gilgit gets only about 130 mm a year.", "گلگت میں سالانہ صرف تقریباً 130 ملی میٹر بارش ہوتی ہے۔"),

    // ---- Topic 6 ----
    mcq("6y1", 6, 1, "", "Which plateau lies between the Indus and Jhelum rivers and has the ancient city of Taxila?", "کون سا سطح مرتفع دریائے سندھ اور جہلم کے درمیان ہے اور قدیم شہر ٹیکسلا یہیں ہے؟", 0,
        listOf(o("Potohar", "پوٹھوہار"), o("Deosai", "دیوسائی"), o("Balochistan", "بلوچستان"), o("Kharan", "خاران")),
        "Taxila is on the Potohar Plateau.", "ٹیکسلا پوٹھوہار کے سطح مرتفع پر ہے۔"),
    tf("6y2", 6, 2, "", "The Thar Desert continues into India's Rajasthan.", "صحرائے تھر بھارت کے راجستھان تک جاتا ہے۔", true,
        "It is part of the Great Indian Desert.", "یہ عظیم ہندوستانی صحرا کا حصہ ہے۔"),
    mcq("6y3", 6, 1, "", "In which province is the Kharan Desert?", "صحرائے خاران کس صوبے میں ہے؟", 3,
        listOf(o("Sindh", "سندھ"), o("Punjab", "پنجاب"), o("Khyber Pakhtunkhwa", "خیبر پختونخوا"), o("Balochistan", "بلوچستان")),
        "It lies in western Balochistan.", "یہ مغربی بلوچستان میں ہے۔"),

    // ---- Topic 7 ----
    mcq("7y1", 7, 1, "", "The Passu Cones and the Hussaini suspension bridge are in which valley?", "پاسو کونز اور حسینی معلق پل کس وادی میں ہیں؟", 1,
        listOf(o("Swat", "سوات"), o("Hunza", "ہنزہ"), o("Skardu", "اسکردو"), o("Kaghan", "کاغان")),
        "They are in Gojal, upper Hunza.", "یہ بالائی ہنزہ کے علاقے گوجال میں ہیں۔"),
    mcq("7y2", 7, 1, "", "In which lake is the reflection of Malika Parbat seen?", "ملکہ پربت کا عکس کس جھیل میں نظر آتا ہے؟", 2,
        listOf(o("Attabad", "عطا آباد"), o("Manchar", "منچھر"), o("Saif-ul-Malook", "سیف الملوک"), o("Keenjhar", "کینجھر")),
        "Saif-ul-Malook is near Naran.", "سیف الملوک ناران کے قریب ہے۔"),
    tf("7y3", 7, 2, "", "Keenjhar Lake is a Ramsar wetland.", "کینجھر جھیل رامسر آبی علاقہ ہے۔", true,
        "It is a winter home for migratory birds.", "یہ مہاجر پرندوں کا سرمائی مسکن ہے۔"),

    // ---- Topic 8 ----
    mcq("8y1", 8, 1, "", "Which tree's name means \"wood of the gods\"?", "کس درخت کے نام کا مطلب \"دیوتاؤں کی لکڑی\" ہے؟", 0,
        listOf(o("Deodar", "دیودار"), o("Chinar", "چنار"), o("Kikar", "کیکر"), o("Neem", "نیم")),
        "It comes from the Sanskrit \"devadaru\".", "یہ سنسکرت لفظ \"دیوداروا\" سے آیا ہے۔"),
    tf("8y2", 8, 1, "", "Riverine forests depend on river floods.", "دریائی جنگلات دریا کے سیلاب پر منحصر ہیں۔", true,
        "Dams and barrages reduce the floods they need.", "ڈیم اور بیراج ان کے لیے ضروری سیلاب کم کر دیتے ہیں۔"),
    mcq("8y3", 8, 2, "", "Which tree is the typical \"desert tree\" of Thar and Cholistan?", "تھر اور چولستان کا مخصوص \"صحرائی درخت\" کون سا ہے؟", 3,
        listOf(o("Chinar", "چنار"), o("Deodar", "دیودار"), o("Mangrove", "مینگرو"), o("Khejri", "کھیجڑی")),
        "Khejri survives with very little water.", "کھیجڑی بہت کم پانی میں زندہ رہتا ہے۔"),

    // ---- Topic 9 ----
    mcq("9y1", 9, 1, "", "Pink \"Himalayan salt\" comes mainly from which mine?", "گلابی \"ہمالیائی نمک\" بنیادی طور پر کس کان سے آتا ہے؟", 1,
        listOf(o("Kalabagh", "کالاباغ"), o("Khewra", "کھیوڑہ"), o("Warcha", "وارچھا"), o("Jatta", "جٹہ")),
        "Khewra is in the Salt Range.", "کھیوڑہ سالٹ رینج میں ہے۔"),
    mcq("9y2", 9, 2, "", "Chromite is the ore of which metal?", "کرومائٹ کس دھات کی کچ دھات ہے؟", 2,
        listOf(o("Copper", "تانبا"), o("Iron", "لوہا"), o("Chromium", "کرومیم"), o("Zinc", "جست")),
        "Chromium is used in stainless steel.", "کرومیم سٹینلیس اسٹیل میں استعمال ہوتا ہے۔"),
    tf("9y3", 9, 1, "", "Reko Diq is in Chagai district.", "ریکوڈک ضلع چاغی میں ہے۔", true,
        "Chagai is in Balochistan.", "چاغی بلوچستان میں ہے۔"),

    // ---- Topic 10 ----
    mcq("10y1", 10, 1, "", "Basmati rice is grown mainly in the Kallar tract of which province?", "باسمتی چاول زیادہ تر کس صوبے کے کلر کے علاقے میں اگتا ہے؟", 0,
        listOf(o("Punjab", "پنجاب"), o("Sindh", "سندھ"), o("Balochistan", "بلوچستان"), o("Khyber Pakhtunkhwa", "خیبر پختونخوا")),
        "Gujranwala, Sheikhupura and Narowal are in this belt.", "گوجرانوالہ، شیخوپورہ اور نارووال اسی پٹی میں ہیں۔"),
    tf("10y2", 10, 1, "", "Sugarcane is crushed in mills mainly from November to March.", "گنا ملوں میں زیادہ تر نومبر سے مارچ تک پیسا جاتا ہے۔", true,
        "This is the crushing season.", "یہ پسائی کا موسم ہے۔"),
    mcq("10y3", 10, 2, "", "Ziarat, Kalat and Quetta are famous for which fruit?", "زیارت، قلات اور کوئٹہ کس پھل کے لیے مشہور ہیں؟", 2,
        listOf(o("Mango", "آم"), o("Banana", "کیلا"), o("Apple", "سیب"), o("Dates", "کھجور")),
        "The cool highlands suit apples.", "ٹھنڈے بلند علاقے سیب کے لیے موزوں ہیں۔"),

    // ---- Topic 11 ----
    mcq("11y1", 11, 1, "", "Which island off Pasni is a nesting site for green turtles?", "پسنی کے قریب کون سا جزیرہ سبز کچھوؤں کے انڈے دینے کی جگہ ہے؟", 1,
        listOf(o("Churna", "چرنا"), o("Astola", "استولا"), o("Manora", "منوڑا"), o("Bundal", "بنڈل")),
        "Astola is Pakistan's largest offshore island.", "استولا پاکستان کا سب سے بڑا سمندری جزیرہ ہے۔"),
    tf("11y2", 11, 1, "", "Gwadar is a deep-water port.", "گوادر گہرے پانی کی بندرگاہ ہے۔", true,
        "Large ships can enter it.", "بڑے جہاز اس میں داخل ہو سکتے ہیں۔"),
    mcq("11y3", 11, 2, "", "In which year was the Karachi Port Trust set up?", "کراچی پورٹ ٹرسٹ کس سال قائم ہوا؟", 2,
        listOf(o("1857", "1857"), o("1873", "1873"), o("1887", "1887"), o("1947", "1947")),
        "It was set up in 1887 under British rule.", "یہ 1887 میں برطانوی دور میں قائم ہوا۔"),

    // ---- Topic 12 ----
    mcq("12y1", 12, 1, "", "Which province has the highest population density?", "کس صوبے میں آبادی کی کثافت سب سے زیادہ ہے؟", 0,
        listOf(o("Punjab", "پنجاب"), o("Sindh", "سندھ"), o("Khyber Pakhtunkhwa", "خیبر پختونخوا"), o("Balochistan", "بلوچستان")),
        "Punjab has about 620 people per km².", "پنجاب میں تقریباً 620 افراد فی مربع کلومیٹر ہیں۔"),
    tf("12y2", 12, 1, "", "About two-thirds of Pakistanis are under 30 years old.", "تقریباً دو تہائی پاکستانی 30 سال سے کم عمر ہیں۔", true,
        "Pakistan has a large youth bulge.", "پاکستان میں نوجوانوں کی بڑی تعداد ہے۔"),
    mcq("12y3", 12, 2, "", "About how many Pakistanis live abroad?", "تقریباً کتنے پاکستانی بیرون ملک رہتے ہیں؟", 1,
        listOf(o("1 million", "10 لاکھ"), o("9 million", "90 لاکھ"), o("30 million", "3 کروڑ"), o("50 million", "5 کروڑ")),
        "Their remittances are a major source of foreign money.", "ان کی ترسیلات زر زرمبادلہ کا بڑا ذریعہ ہیں۔"),

    // ---- Topic 13 ----
    mcq("13y1", 13, 1, "", "In which year did the major Kashmir earthquake occur?", "کشمیر کا بڑا زلزلہ کس سال آیا؟", 3,
        listOf(o("1995", "1995"), o("1999", "1999"), o("2001", "2001"), o("2005", "2005")),
        "It struck on 8 October 2005.", "یہ 8 اکتوبر 2005 کو آیا۔"),
    tf("13y2", 13, 1, "", "Pakistan produces less than 1% of the world's greenhouse gases.", "پاکستان دنیا کی گرین ہاؤس گیسوں کا 1 فیصد سے کم پیدا کرتا ہے۔", true,
        "Yet it is among the countries most affected by climate change.", "پھر بھی یہ موسمیاتی تبدیلی سے سب سے زیادہ متاثر ممالک میں ہے۔"),
    mcq("13y3", 13, 2, "", "Which subduction zone lies off Pakistan's coast?", "پاکستان کے ساحل کے قریب کون سا سبڈکشن زون ہے؟", 0,
        listOf(o("Makran", "مکران"), o("Kirthar", "کیرتھر"), o("Sulaiman", "سلیمان"), o("Potohar", "پوٹھوہار")),
        "It caused the 1945 tsunami.", "اس نے 1945 کی سونامی پیدا کی۔"),

    // ---- Topic 14 ----
    mcq("14y1", 14, 1, "", "Which animal is protected in Deosai National Park?", "دیوسائی نیشنل پارک میں کون سا جانور محفوظ ہے؟", 1,
        listOf(o("Blackbuck", "کالا ہرن"), o("Himalayan brown bear", "ہمالیائی بھورا ریچھ"), o("Indus dolphin", "سندھ ڈولفن"), o("Chiltan markhor", "چلتن مارخور")),
        "Deosai is home to the brown bear.", "دیوسائی بھورے ریچھ کا مسکن ہے۔"),
    tf("14y2", 14, 1, "", "Zarghun Ghar is the highest peak of Balochistan.", "زرغون غر بلوچستان کی بلند ترین چوٹی ہے۔", true,
        "It is about 3,580 m high.", "یہ تقریباً 3,580 میٹر بلند ہے۔"),
    mcq("14y3", 14, 2, "", "Where is the dry port for trade with China?", "چین کے ساتھ تجارت کی خشک بندرگاہ کہاں ہے؟", 2,
        listOf(o("Taftan", "تفتان"), o("Torkham", "طورخم"), o("Sost", "سوست"), o("Wagah", "واہگہ")),
        "Sost is near the Khunjerab Pass.", "سوست درۂ خنجراب کے قریب ہے۔"),

    // ---- Topic 15 ----
    mcq("15y1", 15, 1, "", "Which colour shows snow and glaciers on a physical map?", "طبعی نقشے پر برف اور گلیشیئر کس رنگ سے دکھائے جاتے ہیں؟", 3,
        listOf(o("Blue", "نیلا"), o("Green", "سبز"), o("Brown", "بھورا"), o("White", "سفید")),
        "White is used for snow.", "برف کے لیے سفید رنگ استعمال ہوتا ہے۔"),
    mcq("15y2", 15, 2, "", "The Panjnad is formed by the meeting of which rivers?", "پنجند کن دریاؤں کے ملنے سے بنتا ہے؟", 0,
        listOf(o("The five Punjab rivers", "پنجاب کے پانچ دریا"), o("Kabul and Swat", "کابل اور سوات"), o("Indus and Kabul", "سندھ اور کابل"), o("Gomal and Zhob", "گومل اور ژوب")),
        "It joins the Indus near Mithankot.", "یہ مٹھن کوٹ کے قریب سندھ سے ملتا ہے۔"),
    tf("15y3", 15, 1, "", "Pakistan's longest land border is with India.", "پاکستان کی سب سے لمبی زمینی سرحد بھارت کے ساتھ ہے۔", true,
        "It is about 2,912 km, followed by Afghanistan.", "یہ تقریباً 2,912 کلومیٹر ہے، پھر افغانستان۔")
)

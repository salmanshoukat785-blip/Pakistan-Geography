package com.pakgeo.app

fun c(key: String, en: String, ur: String): Pair<String, Pair<String, String>> =
    key to (en.trimIndent() to ur.trimIndent())

@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pakgeo.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PakGeoApp(prefs: Prefs) {
    val stack = remember { mutableStateListOf("splash") }
    val route = stack.last()
    val dir = if (prefs.lang == "ur") LayoutDirection.Rtl else LayoutDirection.Ltr
    val go: (String) -> Unit = { stack.add(it) }
    val back: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.size - 1) }

    BackHandler(enabled = route != "splash" && stack.size > 1) { back() }

    CompositionLocalProvider(
        LocalLang provides prefs.lang,
        LocalLayoutDirection provides dir
    ) {
        PakTheme(prefs.themeMode, prefs.colorKey) {
            val parts = route.split(":")
            when (parts[0]) {
                "splash" -> SplashScreen {
                    stack.clear()
                    stack.add("dashboard")
                }
                "settings" -> SettingsScreen(prefs, back)
                "book" -> BookScreen(prefs, go, back)
                "search" -> SearchScreen(prefs, go, back)
                "bookmarks" -> BookmarksScreen(prefs, go, back)
                "progress" -> ProgressScreen(prefs, back)
                "topic" -> TopicScreen(prefs, parts[1].toInt(), go, back)
                "reader" -> ReaderScreen(prefs, parts[1].toInt(), parts[2].toInt(), back)
                else -> DashboardScreen(prefs, go)
            }
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.6f) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, tween(900)) }
        launch { alpha.animateTo(1f, tween(900)) }
        delay(2000)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xFF01411C)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = null,
                modifier = Modifier.size(180.dp).scale(scale.value)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Pakistan Geography",
                color = Color.White.copy(alpha = alpha.value),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "پاکستان جغرافیہ",
                color = Color.White.copy(alpha = alpha.value * 0.85f),
                fontSize = 22.sp
            )
        }
    }
}

@Composable
fun DashboardScreen(prefs: Prefs, nav: (String) -> Unit) {
    val context = LocalContext.current
    val soon = tr("Coming in the next part", "یہ اگلے حصے میں آئے گا")
    val grad = Brush.linearGradient(
        listOf(AppColor.from(prefs.colorKey).light, AppColor.from(prefs.colorKey).light.copy(alpha = 0.75f))
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item(span = { GridItemSpan(maxLineSpan) }) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(grad)
                    .statusBarsPadding()
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                tr("Pakistan Geography", "پاکستان جغرافیہ"),
                                color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold
                            )
                            Text(
                                tr("15 topics • Learn • Test • Score", "15 موضوعات • سیکھیں • آزمائیں • اسکور"),
                                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp
                            )
                        }
                        IconButton(onClick = { nav("settings") }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                    }
                }
            }
        }

        // Quick actions
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("📝", tr("Quiz", "کوئز"), Modifier.weight(1f)) {
                    Toast.makeText(context, soon, Toast.LENGTH_SHORT).show()
                }
                QuickAction("🎯", tr("Self Test", "سیلف ٹیسٹ"), Modifier.weight(1f)) {
                    Toast.makeText(context, soon, Toast.LENGTH_SHORT).show()
                }
                QuickAction("🔥", tr("Daily", "روزانہ"), Modifier.weight(1f)) {
                    Toast.makeText(context, soon, Toast.LENGTH_SHORT).show()
                }
                QuickAction("📖", tr("Book", "کتاب"), Modifier.weight(1f)) { nav("book") }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("🔍", tr("Search", "تلاش"), Modifier.weight(1f)) { nav("search") }
                QuickAction("⭐", tr("Bookmarks", "بک مارکس"), Modifier.weight(1f)) { nav("bookmarks") }
                QuickAction("📊", tr("Progress", "پیش رفت"), Modifier.weight(1f)) { nav("progress") }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                tr("Topics", "موضوعات"),
                fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Topic cards
        items(topics.size) { i ->
            val t = topics[i]
            TopicCard(t, grad, prefs.readCount(t.id), sectionsOf(t.id).size) { nav("topic:${t.id}") }
        }
    }
}

@Composable
fun QuickAction(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun TopicCard(t: Topic, grad: Brush, read: Int, total: Int, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(3.dp),
        modifier = Modifier.fillMaxWidth().height(138.dp)
    ) {
        Box(Modifier.fillMaxSize().background(grad).padding(14.dp)) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(t.emoji, fontSize = 28.sp)
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${t.id}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Column {
                    Text(
                        tr(t.en, t.ur),
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 20.sp
                    )
                    Text(
                        "$read / $total",
                        color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(prefs: Prefs, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("Settings", "ترتیبات")) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionTitle(tr("Language", "زبان"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = prefs.lang == "en",
                    onClick = { prefs.changeLang("en") },
                    label = { Text("English") }
                )
                FilterChip(
                    selected = prefs.lang == "ur",
                    onClick = { prefs.changeLang("ur") },
                    label = { Text("اردو") }
                )
            }

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Theme", "تھیم"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = prefs.themeMode == "system",
                    onClick = { prefs.changeThemeMode("system") },
                    label = { Text(tr("System", "سسٹم")) }
                )
                FilterChip(
                    selected = prefs.themeMode == "light",
                    onClick = { prefs.changeThemeMode("light") },
                    label = { Text(tr("Light", "لائٹ")) }
                )
                FilterChip(
                    selected = prefs.themeMode == "dark",
                    onClick = { prefs.changeThemeMode("dark") },
                    label = { Text(tr("Dark", "ڈارک")) }
                )
            }

            Spacer(Modifier.height(8.dp))
            SectionTitle(tr("Colour", "رنگ"))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AppColor.values().forEach { c ->
                    val selected = prefs.colorKey == c.key
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(c.light)
                                .border(
                                    if (selected) 3.dp else 0.dp,
                                    MaterialTheme.colorScheme.onBackground,
                                    CircleShape
                                )
                                .clickable { prefs.changeColor(c.key) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) Text("✓", color = Color.White, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            tr(c.en, c.ur), fontSize = 12.sp, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}

package com.pakgeo.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Saves language, theme, bookmarks and reading progress. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("pg_prefs", Context.MODE_PRIVATE)

    var lang by mutableStateOf(sp.getString("lang", "ur") ?: "ur")
        private set
    var themeMode by mutableStateOf(sp.getString("mode", "system") ?: "system")
        private set
    var colorKey by mutableStateOf(sp.getString("color", "green") ?: "green")
        private set
    var bookmarks by mutableStateOf<Set<String>>(sp.getStringSet("bm", emptySet())?.toSet() ?: emptySet())
        private set
    var readSet by mutableStateOf<Set<String>>(sp.getStringSet("rd", emptySet())?.toSet() ?: emptySet())
        private set

    fun changeLang(v: String) { lang = v; sp.edit().putString("lang", v).apply() }
    fun changeThemeMode(v: String) { themeMode = v; sp.edit().putString("mode", v).apply() }
    fun changeColor(v: String) { colorKey = v; sp.edit().putString("color", v).apply() }

    fun toggleBookmark(key: String) {
        val n: Set<String> = if (key in bookmarks) bookmarks - key else bookmarks + key
        bookmarks = n
        sp.edit().putStringSet("bm", n).apply()
    }

    fun markRead(key: String) {
        if (key in readSet) return
        val n: Set<String> = readSet + key
        readSet = n
        sp.edit().putStringSet("rd", n).apply()
    }

    fun readCount(topicId: Int): Int = readSet.count { it.startsWith("$topicId.") }
}

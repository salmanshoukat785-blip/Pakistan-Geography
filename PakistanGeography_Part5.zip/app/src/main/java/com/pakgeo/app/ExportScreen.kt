@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.pakgeo.app

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ExportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val lang = LocalLang.current
    val scope = rememberCoroutineScope()
    var scopeSel by remember { mutableStateOf(0) }   // 0 book, 1 chapter, 2 section
    var topic by remember { mutableStateOf(1) }
    var secIdx by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }

    val list: List<Section> = when (scopeSel) {
        0 -> allSections
        1 -> sectionsOf(topic)
        else -> sectionsOf(topic).filter { it.index == secIdx }
    }.filter { allContent.containsKey(it.key) }

    val fileName = when (scopeSel) {
        0 -> "Pakistan_Geography_Book_$lang.pdf"
        1 -> "Pakistan_Geography_Chapter${topic}_$lang.pdf"
        else -> "Pakistan_Geography_${topic}_${secIdx + 1}_$lang.pdf"
    }

    val savedMsg = tr("Saved to Downloads", "ڈاؤن لوڈز میں محفوظ ہو گئی")
    val shareMsg = tr("Choose where to save or send the PDF", "PDF محفوظ یا بھیجنے کی جگہ چنیں")
    val errMsg = tr("Could not create PDF", "PDF نہیں بن سکی")

    fun run(share: Boolean) {
        if (list.isEmpty() || busy) return
        busy = true
        scope.launch {
            val file = try {
                withContext(Dispatchers.IO) { PdfExporter.build(context, list, lang, fileName) }
            } catch (e: Exception) {
                null
            }
            busy = false
            if (file == null) {
                Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (share) {
                PdfExporter.share(context, file)
            } else if (PdfExporter.saveToDownloads(context, file)) {
                Toast.makeText(context, savedMsg, Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, shareMsg, Toast.LENGTH_LONG).show()
                PdfExporter.share(context, file)
            }
        }
    }

    PageScaffold(tr("Save as PDF", "PDF میں محفوظ کریں"), onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionTitle(tr("What to save", "کیا محفوظ کرنا ہے"))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = scopeSel == 0, onClick = { scopeSel = 0 }, label = { Text(tr("Whole book", "پوری کتاب")) })
                FilterChip(selected = scopeSel == 1, onClick = { scopeSel = 1 }, label = { Text(tr("One chapter", "ایک باب")) })
                FilterChip(selected = scopeSel == 2, onClick = { scopeSel = 2; secIdx = 0 }, label = { Text(tr("One section", "ایک حصہ")) })
            }

            if (scopeSel >= 1) {
                SectionTitle(tr("Chapter", "باب"))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    topics.forEach { t ->
                        FilterChip(
                            selected = topic == t.id,
                            onClick = { topic = t.id; secIdx = 0 },
                            label = { Text("${t.id}. ${if (lang == "ur") t.ur else t.en}", fontSize = 12.sp) }
                        )
                    }
                }
            }
            if (scopeSel == 2) {
                SectionTitle(tr("Section", "حصہ"))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    sectionsOf(topic).forEach { s ->
                        FilterChip(
                            selected = secIdx == s.index,
                            onClick = { secIdx = s.index },
                            label = { Text("${s.index + 1}. ${if (lang == "ur") s.ur else s.en}", fontSize = 12.sp) }
                        )
                    }
                }
            }

            Text(
                if (list.isEmpty()) tr(
                    "No content available here yet. It will be added in updates.",
                    "یہاں ابھی مواد دستیاب نہیں۔ اپڈیٹس میں شامل کیا جائے گا۔"
                ) else tr(
                    "${list.size} section(s) will be included. The PDF follows the app language.",
                    "${list.size} حصے شامل ہوں گے۔ PDF ایپ کی زبان میں بنے گی۔"
                ),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )

            Button(
                enabled = list.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = { run(false) }
            ) { Text(if (busy) tr("Please wait...", "انتظار کریں...") else tr("Save to Downloads", "ڈاؤن لوڈز میں محفوظ کریں")) }
            OutlinedButton(
                enabled = list.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = { run(true) }
            ) { Text(tr("Share PDF", "PDF شیئر کریں")) }
        }
    }
}

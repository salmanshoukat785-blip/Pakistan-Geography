package com.pakgeo.app

val contentPart1: Map<String, Pair<String, String>> = mapOf(
    c("1.0",
"""
Pakistan is a country in South Asia. Its full name is the Islamic Republic of Pakistan. It came into being on 14 August 1947.

• Capital: Islamabad
• Largest city: Karachi
• National language: Urdu (English is also used officially)
• Currency: Pakistani Rupee
• Provinces: Punjab, Sindh, Khyber Pakhtunkhwa, Balochistan
• Other units: Gilgit-Baltistan, Azad Jammu & Kashmir, Islamabad Capital Territory

Pakistan has high mountains in the north, plains in the centre, deserts in the south-east and a coastline on the Arabian Sea.
""",
"""
پاکستان جنوبی ایشیا میں واقع ایک ملک ہے۔ اس کا پورا نام اسلامی جمہوریہ پاکستان ہے۔ یہ 14 اگست 1947 کو وجود میں آیا۔

• دارالحکومت: اسلام آباد
• سب سے بڑا شہر: کراچی
• قومی زبان: اردو (انگریزی بھی سرکاری طور پر استعمال ہوتی ہے)
• کرنسی: پاکستانی روپیہ
• صوبے: پنجاب، سندھ، خیبر پختونخوا، بلوچستان
• دیگر اکائیاں: گلگت بلتستان، آزاد جموں و کشمیر، وفاقی دارالحکومت اسلام آباد

پاکستان کے شمال میں بلند پہاڑ، وسط میں میدان، جنوب مشرق میں صحرا اور جنوب میں بحیرہ عرب کا ساحل ہے۔
"""),

    c("1.1",
"""
Pakistan lies in the north-western part of South Asia, in the Northern and Eastern Hemispheres.

• Latitude: about 23°30′ N to 37° N
• Longitude: about 61° E to 75°31′ E
• The southernmost point of the country lies close to the Tropic of Cancer.
• It is bordered by Iran, Afghanistan, China and India, and by the Arabian Sea in the south.

Pakistan sits at the meeting point of South Asia, Central Asia, West Asia and China. This is what makes its location so important.
""",
"""
پاکستان جنوبی ایشیا کے شمال مغربی حصے میں، شمالی اور مشرقی نصف کرہ میں واقع ہے۔

• عرض بلد: تقریباً 23°30′ شمالی سے 37° شمالی
• طول بلد: تقریباً 61° مشرقی سے 75°31′ مشرقی
• ملک کا جنوبی ترین مقام خط سرطان کے قریب ہے۔
• اس کے ساتھ ایران، افغانستان، چین اور بھارت کی سرحدیں ہیں اور جنوب میں بحیرہ عرب ہے۔

پاکستان جنوبی ایشیا، وسطی ایشیا، مغربی ایشیا اور چین کے سنگم پر واقع ہے۔ اسی وجہ سے اس کا محل وقوع بہت اہم ہے۔
"""),

    c("1.2",
"""
The total area of Pakistan is about 881,913 square kilometres. This includes Gilgit-Baltistan and Azad Jammu & Kashmir. Some sources give a smaller figure of about 796,095 km², so figures can differ.

• Rank: about 33rd largest country in the world by area
• Balochistan is the largest province by area (about 347,000 km², roughly 44% of the country).
• Punjab is the largest province by population.
• Islamabad Capital Territory is the smallest unit (about 906 km²).
""",
"""
پاکستان کا کل رقبہ تقریباً 881,913 مربع کلومیٹر ہے۔ اس میں گلگت بلتستان اور آزاد جموں و کشمیر بھی شامل ہیں۔ بعض ذرائع میں تقریباً 796,095 مربع کلومیٹر کا کم اعداد و شمار بھی ملتا ہے، اس لیے اعداد میں فرق ہو سکتا ہے۔

• درجہ: رقبے کے لحاظ سے دنیا کا تقریباً 33 واں بڑا ملک
• بلوچستان رقبے کے لحاظ سے سب سے بڑا صوبہ ہے (تقریباً 3,47,000 مربع کلومیٹر، یعنی ملک کا تقریباً 44 فیصد)۔
• پنجاب آبادی کے لحاظ سے سب سے بڑا صوبہ ہے۔
• وفاقی دارالحکومت اسلام آباد سب سے چھوٹی اکائی ہے (تقریباً 906 مربع کلومیٹر)۔
"""),

    c("1.3",
"""
Pakistan's location gives it great importance:

• Gateway to Central Asia: it is the nearest sea route for landlocked Central Asian states.
• Arabian Sea access: ports at Karachi, Port Qasim and Gwadar handle international trade.
• Close to the Persian Gulf and the Strait of Hormuz, through which a large share of the world's oil passes.
• Link with China: the Karakoram Highway crosses the Khunjerab Pass, and CPEC connects China to Gwadar.
• The Indus river system supports farming for millions of people.
• Varied landscapes and climates, from glaciers to deserts.
""",
"""
پاکستان کا محل وقوع اسے غیر معمولی اہمیت دیتا ہے:

• وسطی ایشیا کا دروازہ: خشکی میں گھرے وسطی ایشیائی ممالک کے لیے سمندر تک قریب ترین راستہ۔
• بحیرہ عرب تک رسائی: کراچی، پورٹ قاسم اور گوادر کی بندرگاہیں بین الاقوامی تجارت سنبھالتی ہیں۔
• خلیج فارس اور آبنائے ہرمز کے قریب، جہاں سے دنیا کے تیل کا بڑا حصہ گزرتا ہے۔
• چین سے رابطہ: قراقرم ہائی وے درۂ خنجراب سے گزرتی ہے اور سی پیک چین کو گوادر سے جوڑتا ہے۔
• دریائے سندھ کا نظام کروڑوں لوگوں کی زراعت کا سہارا ہے۔
• گلیشیئرز سے صحراؤں تک متنوع زمینی ساخت اور آب و ہوا۔
"""),

    c("1.4",
"""
Approximate lengths of Pakistan's borders (figures vary slightly by source):

• Afghanistan: about 2,430 km (the Durand Line)
• India: about 2,912 km (the Radcliffe Line, the Line of Control and the Working Boundary)
• Iran: about 909 km
• China: about 585 km
• Arabian Sea coastline: about 1,046 km

Afghanistan lies to the north and north-west, China to the north-east, India to the east and Iran to the west.
""",
"""
پاکستان کی سرحدوں کی تقریبی لمبائی (مختلف ذرائع میں معمولی فرق ہو سکتا ہے):

• افغانستان: تقریباً 2,430 کلومیٹر (ڈیورنڈ لائن)
• بھارت: تقریباً 2,912 کلومیٹر (ریڈکلف لائن، لائن آف کنٹرول اور ورکنگ باؤنڈری)
• ایران: تقریباً 909 کلومیٹر
• چین: تقریباً 585 کلومیٹر
• بحیرہ عرب کی ساحلی پٹی: تقریباً 1,046 کلومیٹر

افغانستان شمال اور شمال مغرب میں، چین شمال مشرق میں، بھارت مشرق میں اور ایران مغرب میں واقع ہے۔
"""),

    c("1.5",
"""
Pakistan has four land neighbours:

• Afghanistan (north and north-west): main crossings at Torkham and Chaman.
• China (north-east): crossing at the Khunjerab Pass, one of the highest border crossings in the world (about 4,693 m).
• India (east): main crossing at Wagah–Attari.
• Iran (west): main crossing at Taftan.

In the south, across the Arabian Sea, lies Oman. Tajikistan is very close in the north, but the narrow Wakhan Corridor of Afghanistan separates the two countries, so they do not share a border.
""",
"""
پاکستان کے چار خشکی کے ہمسایہ ممالک ہیں:

• افغانستان (شمال اور شمال مغرب): اہم گزرگاہیں طورخم اور چمن۔
• چین (شمال مشرق): درۂ خنجراب کی گزرگاہ، جو دنیا کی بلند ترین سرحدی گزرگاہوں میں سے ہے (تقریباً 4,693 میٹر)۔
• بھارت (مشرق): اہم گزرگاہ واہگہ اٹاری۔
• ایران (مغرب): اہم گزرگاہ تفتان۔

جنوب میں بحیرہ عرب کے پار عمان واقع ہے۔ تاجکستان شمال میں بہت قریب ہے، مگر افغانستان کی تنگ واخان پٹی دونوں ممالک کو الگ کرتی ہے، اس لیے ان کی مشترکہ سرحد نہیں ہے۔
"""),

    c("1.6",
"""
Latitude and longitude are imaginary lines used to find any place on Earth.

• Latitude lines run east–west and are measured north or south of the Equator (0° to 90°).
• Longitude lines (meridians) run north–south and are measured east or west of the Prime Meridian at Greenwich (0° to 180°).

Pakistan extends from about 23°30′ N to 37° N and from about 61° E to 75°31′ E.

Examples (approximate): Islamabad 33.7° N, 73.0° E; Lahore 31.5° N, 74.3° E; Karachi 24.9° N, 67.0° E.
""",
"""
عرض بلد اور طول بلد خیالی لکیریں ہیں جن سے زمین پر کسی بھی جگہ کا تعین کیا جاتا ہے۔

• عرض بلد کی لکیریں مشرق سے مغرب چلتی ہیں اور خط استوا سے شمال یا جنوب کی طرف ناپی جاتی ہیں (0° سے 90°)۔
• طول بلد کی لکیریں (نصف النہار) شمال سے جنوب چلتی ہیں اور گرینچ کے خط نصف النہار سے مشرق یا مغرب کی طرف ناپی جاتی ہیں (0° سے 180°)۔

پاکستان تقریباً 23°30′ شمالی سے 37° شمالی اور تقریباً 61° مشرقی سے 75°31′ مشرقی کے درمیان پھیلا ہوا ہے۔

مثالیں (تقریبی): اسلام آباد 33.7° شمالی، 73.0° مشرقی؛ لاہور 31.5° شمالی، 74.3° مشرقی؛ کراچی 24.9° شمالی، 67.0° مشرقی۔
"""),

    c("1.7",
"""
Pakistan Standard Time (PKT) is UTC+5, which means it is 5 hours ahead of Greenwich Mean Time.

• The Earth turns 360° in 24 hours, so every 15° of longitude equals 1 hour and 1° equals 4 minutes.
• The standard meridian of Pakistan is 75° E (5 × 15° = 75°).
• The whole country uses a single time zone.
• Pakistan briefly used daylight saving time in 2002 and again in 2008 and 2009, but it does not use it at present.
""",
"""
پاکستان کا معیاری وقت (PKT) یو ٹی سی + 5 ہے، یعنی یہ گرینچ کے معیاری وقت سے 5 گھنٹے آگے ہے۔

• زمین 24 گھنٹوں میں 360° گھومتی ہے، اس لیے 15° طول بلد کا فرق 1 گھنٹہ اور 1° کا فرق 4 منٹ ہوتا ہے۔
• پاکستان کا معیاری نصف النہار 75° مشرقی ہے (5 × 15° = 75°)۔
• پورا ملک ایک ہی ٹائم زون استعمال کرتا ہے۔
• پاکستان میں 2002 اور پھر 2008 اور 2009 میں عارضی طور پر گرمیوں کا وقت (ڈے لائٹ سیونگ) رائج رہا، لیکن اس وقت یہ نافذ نہیں ہے۔
"""),

    c("1.8",
"""
Pakistan is usually divided into six major geographical regions:

1. Northern highlands: the Himalayas, Karakoram and Hindu Kush.
2. Western highlands: the Sulaiman and Kirthar ranges and the Balochistan Plateau.
3. Potohar Plateau and Salt Range.
4. Indus Plain: the fertile plains of Punjab and Sindh.
5. Deserts: Thar, Cholistan, Thal and Kharan.
6. Coastal belt: about 1,046 km along the Arabian Sea.
""",
"""
پاکستان کو عموماً چھ بڑے جغرافیائی خطوں میں تقسیم کیا جاتا ہے:

1. شمالی پہاڑی علاقے: ہمالیہ، قراقرم اور ہندوکش۔
2. مغربی پہاڑی علاقے: کوہ سلیمان، کوہ کیرتھر اور بلوچستان کا سطح مرتفع۔
3. پوٹھوہار کا سطح مرتفع اور سالٹ رینج۔
4. سندھ کا میدان: پنجاب اور سندھ کے زرخیز میدان۔
5. صحرا: تھر، چولستان، تھل اور خاران۔
6. ساحلی پٹی: بحیرہ عرب کے ساتھ تقریباً 1,046 کلومیٹر۔
"""),

    c("1.9",
"""
A map shows the Earth, or part of it, on paper. Most maps have a title, a legend (key), a scale and a north arrow.

Main directions: North, South, East and West. In between are North-East, North-West, South-East and South-West.

Directions in Pakistan:
• India lies to the east, Iran to the west, China to the north-east and Afghanistan to the north-west.
• The Arabian Sea lies to the south.
• Gilgit and K2 are in the far north; Karachi is in the far south.
• Quetta lies west of Lahore; Lahore lies south-west of Islamabad.
""",
"""
نقشہ زمین یا اس کے کسی حصے کو کاغذ پر دکھاتا ہے۔ زیادہ تر نقشوں میں عنوان، علامات کی فہرست (لیجنڈ)، پیمانہ اور شمال کا نشان ہوتا ہے۔

بنیادی سمتیں: شمال، جنوب، مشرق اور مغرب۔ ان کے درمیان شمال مشرق، شمال مغرب، جنوب مشرق اور جنوب مغرب ہیں۔

پاکستان میں سمتیں:
• بھارت مشرق میں، ایران مغرب میں، چین شمال مشرق میں اور افغانستان شمال مغرب میں ہے۔
• بحیرہ عرب جنوب میں ہے۔
• گلگت اور کے ٹو انتہائی شمال میں ہیں، جبکہ کراچی انتہائی جنوب میں ہے۔
• کوئٹہ لاہور کے مغرب میں اور لاہور اسلام آباد کے جنوب مغرب میں واقع ہے۔
""")
)

package com.pakgeo.app

data class Topic(val id: Int, val en: String, val ur: String, val emoji: String)

val topics = listOf(
    Topic(1, "Basic Geography", "بنیادی جغرافیہ", "🌏"),
    Topic(2, "Provinces & Administrative Divisions", "صوبے اور انتظامی تقسیم", "🗺️"),
    Topic(3, "Mountain Ranges & Peaks", "پہاڑی سلسلے اور چوٹیاں", "🏔️"),
    Topic(4, "Rivers & Water Resources", "دریاؤں اور آبی وسائل کا جغرافیہ", "🌊"),
    Topic(5, "Climate of Pakistan", "پاکستان کی آب و ہوا", "⛅"),
    Topic(6, "Plains, Plateaus & Deserts", "میدان، سطح مرتفع اور صحرا", "🏜️"),
    Topic(7, "Lakes, Waterfalls & Natural Sites", "جھیلیں، آبشاریں اور قدرتی مقامات", "🏞️"),
    Topic(8, "Forests & Natural Vegetation", "جنگلات اور قدرتی نباتات", "🌲"),
    Topic(9, "Mineral Resources & Reserves", "معدنی وسائل اور قدرتی ذخائر", "⛏️"),
    Topic(10, "Agriculture & Land Use", "زراعت اور زمینی استعمال", "🌾"),
    Topic(11, "Coastal & Marine Geography", "ساحلی اور سمندری جغرافیہ", "⚓"),
    Topic(12, "Population & Human Geography", "آبادی اور انسانی جغرافیہ", "👥"),
    Topic(13, "Natural Disasters & Environmental Issues", "قدرتی آفات اور ماحولیاتی مسائل", "🌪️"),
    Topic(14, "Important Places & General Knowledge", "اہم جغرافیائی مقامات اور عمومی معلومات", "📍"),
    Topic(15, "Maps & Practical Geography", "نقشہ جات اور عملی جغرافیہ", "🧭")
)

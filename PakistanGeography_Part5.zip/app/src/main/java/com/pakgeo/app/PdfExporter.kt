package com.pakgeo.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

private const val PW = 595
private const val PH = 842
private const val PM = 40f

private class PageWriter(val doc: PdfDocument) {
    var page: PdfDocument.Page? = null
    var canvas: Canvas? = null
    var y = PM
    var num = 0
    private val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 10f
        color = 0xFF777777.toInt()
        textAlign = Paint.Align.CENTER
    }

    fun newPage() {
        finish()
        num += 1
        val p = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, num).create())
        page = p
        canvas = p.canvas
        y = PM
    }

    fun finish() {
        val p = page ?: return
        canvas?.drawText("Pakistan Geography  -  $num", PW / 2f, PH - 18f, footer)
        doc.finishPage(p)
        page = null
        canvas = null
    }

    fun block(text: String, paint: TextPaint, gapAfter: Float) {
        if (text.isEmpty()) return
        if (page == null) newPage()
        val width = (PW - 2 * PM).toInt()
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(5f, 1f)
            .setIncludePad(false)
            .build()
        var line = 0
        while (line < layout.lineCount) {
            val limit = PH - PM - 10f
            val avail = limit - y
            val top = layout.getLineTop(line)
            var end = line
            while (end + 1 < layout.lineCount && layout.getLineBottom(end + 1) - top <= avail) end++
            if (layout.getLineBottom(end) - top > avail) {
                newPage()
                continue
            }
            val c = canvas!!
            c.save()
            c.translate(PM, y - top)
            c.clipRect(0f, top.toFloat(), width.toFloat(), layout.getLineBottom(end).toFloat())
            layout.draw(c)
            c.restore()
            y += (layout.getLineBottom(end) - top)
            line = end + 1
            if (line < layout.lineCount) newPage()
        }
        y += gapAfter
    }
}

object PdfExporter {
    fun build(context: Context, sections: List<Section>, lang: String, fileName: String): File {
        val ur = lang == "ur"
        val doc = PdfDocument()
        val w = PageWriter(doc)

        fun paint(sizePx: Float, bold: Boolean, argb: Int): TextPaint {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
            tp.textSize = sizePx
            tp.color = argb
            tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            return tp
        }

        val title = paint(28f, true, 0xFF01411C.toInt())
        val sub = paint(14f, false, 0xFF555555.toInt())
        val chapter = paint(22f, true, 0xFF01411C.toInt())
        val heading = paint(17f, true, 0xFF222222.toInt())
        val body = paint(13.5f, false, 0xFF111111.toInt())

        w.block(if (ur) "پاکستان جغرافیہ" else "Pakistan Geography", title, 4f)
        w.block(if (ur) "نوٹس اور مطالعہ" else "Study notes", sub, 22f)

        var lastTopic = -1
        for (s in sections) {
            val content = allContent[s.key] ?: continue
            if (s.topicId != lastTopic) {
                if (lastTopic != -1) w.newPage()
                val t = topics.first { it.id == s.topicId }
                val head = if (ur) "باب ${t.id}: ${t.ur}" else "Chapter ${t.id}: ${t.en}"
                w.block(head, chapter, 12f)
                lastTopic = s.topicId
            }
            w.block(if (ur) s.ur else s.en, heading, 6f)
            w.block(if (ur) content.second else content.first, body, 18f)
        }
        w.finish()

        val dir = File(context.cacheDir, "pdfs")
        dir.mkdirs()
        val file = File(dir, fileName)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Saves into the public Downloads folder (Android 10+). Returns false if not possible. */
    fun saveToDownloads(context: Context, file: File): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return false
            context.contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(i, null))
    }
}

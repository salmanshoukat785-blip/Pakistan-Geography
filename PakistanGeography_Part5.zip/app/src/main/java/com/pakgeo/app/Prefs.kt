package com.pakgeo.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Saves language, theme, bookmarks and reading progress. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("pg_prefs", Context.MODE_PRIVATE)

    var lang by mutableStateOf(sp.getString("lang", "ur") ?: "ur")
        private set
    var themeMode by mutableStateOf(sp.getString("mode", "system") ?: "system")
        private set
    var colorKey by mutableStateOf(sp.getString("color", "green") ?: "green")
        private set
    var bookmarks by mutableStateOf<Set<String>>(sp.getStringSet("bm", emptySet())?.toSet() ?: emptySet())
        private set
    var readSet by mutableStateOf<Set<String>>(sp.getStringSet("rd", emptySet())?.toSet() ?: emptySet())
        private set

    var history by mutableStateOf(sp.getString("hist", "") ?: "")
        private set
    var wrongIds by mutableStateOf<Set<String>>(sp.getStringSet("wrong", emptySet())?.toSet() ?: emptySet())
        private set
    var streak by mutableStateOf(sp.getInt("streak", 0))
        private set
    var lastDaily by mutableStateOf(sp.getString("lastDaily", "") ?: "")
        private set
    var lastDailyScore by mutableStateOf(sp.getString("lastDailyScore", "") ?: "")
        private set

    var fontSize by mutableStateOf(sp.getInt("fs", 17))
        private set

    fun changeFontSize(v: Int) { fontSize = v; sp.edit().putInt("fs", v).apply() }

    fun resetProgress() { readSet = emptySet(); sp.edit().remove("rd").apply() }
    fun clearBookmarks() { bookmarks = emptySet(); sp.edit().remove("bm").apply() }
    fun clearScores() {
        history = ""
        wrongIds = emptySet()
        streak = 0
        lastDaily = ""
        lastDailyScore = ""
        sp.edit().remove("hist").remove("wrong").remove("streak")
            .remove("lastDaily").remove("lastDailyScore").apply()
    }

    fun changeLang(v: String) { lang = v; sp.edit().putString("lang", v).apply() }
    fun changeThemeMode(v: String) { themeMode = v; sp.edit().putString("mode", v).apply() }
    fun changeColor(v: String) { colorKey = v; sp.edit().putString("color", v).apply() }

    fun toggleBookmark(key: String) {
        val n: Set<String> = if (key in bookmarks) bookmarks - key else bookmarks + key
        bookmarks = n
        sp.edit().putStringSet("bm", n).apply()
    }

    fun markRead(key: String) {
        if (key in readSet) return
        val n: Set<String> = readSet + key
        readSet = n
        sp.edit().putStringSet("rd", n).apply()
    }

    fun readCount(topicId: Int): Int = readSet.count { it.startsWith("$topicId.") }

    fun saveResult(mode: String, score: Int, total: Int) {
        val entry = "${System.currentTimeMillis()},$mode,$score,$total"
        val list = (history.split(";").filter { it.isNotBlank() } + entry).takeLast(30)
        history = list.joinToString(";")
        sp.edit().putString("hist", history).apply()
    }

    fun noteAnswer(id: String, ok: Boolean) {
        val n: Set<String> = if (ok) wrongIds - id else wrongIds + id
        if (n == wrongIds) return
        wrongIds = n
        sp.edit().putStringSet("wrong", n).apply()
    }

    fun completeDaily(today: String, yesterday: String, score: Int, total: Int) {
        if (lastDaily == today) return
        streak = if (lastDaily == yesterday) streak + 1 else 1
        lastDaily = today
        lastDailyScore = "$score/$total"
        sp.edit().putInt("streak", streak).putString("lastDaily", today)
            .putString("lastDailyScore", lastDailyScore).apply()
    }

    fun effectiveStreak(today: String, yesterday: String): Int =
        if (lastDaily == today || lastDaily == yesterday) streak else 0
}

@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pakgeo.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class QuickList(
    val id: String, val emoji: String, val en: String, val ur: String,
    val numbered: Boolean, val items: List<Pair<String, String>>,
    val noteEn: String = "", val noteUr: String = ""
)

val quickLists: List<QuickList> = listOf(
    QuickList("glance", "🇵🇰", "Pakistan at a Glance", "پاکستان ایک نظر میں", false, listOf(
        "Capital: Islamabad" to "دارالحکومت: اسلام آباد",
        "Largest city: Karachi" to "سب سے بڑا شہر: کراچی",
        "Area: about 881,913 km²" to "رقبہ: تقریباً 881,913 مربع کلومیٹر",
        "Population (2023 census): about 241 million" to "آبادی (مردم شماری 2023): تقریباً 24.1 کروڑ",
        "Independence: 14 August 1947" to "آزادی: 14 اگست 1947",
        "Time zone: UTC+5 (PKT)" to "ٹائم زون: یو ٹی سی + 5 (PKT)",
        "Currency: Pakistani Rupee" to "کرنسی: پاکستانی روپیہ",
        "Calling code: +92" to "کالنگ کوڈ: +92",
        "Highest point: K2 (about 8,611 m)" to "بلند ترین مقام: کے ٹو (تقریباً 8,611 میٹر)",
        "Longest river: Indus" to "سب سے طویل دریا: سندھ",
        "Coastline: about 1,046 km" to "ساحلی پٹی: تقریباً 1,046 کلومیٹر",
        "National tree: Deodar" to "قومی درخت: دیودار",
        "National animal: Markhor" to "قومی جانور: مارخور",
        "National bird: Chukar partridge" to "قومی پرندہ: چکور",
        "National flower: Jasmine" to "قومی پھول: چنبیلی"
    )),
    QuickList("peaks", "🏔️", "Top 10 Highest Peaks", "10 بلند ترین چوٹیاں", true, listOf(
        "K2 – 8,611 m" to "کے ٹو – 8,611 میٹر",
        "Nanga Parbat – 8,126 m" to "نانگا پربت – 8,126 میٹر",
        "Gasherbrum I – 8,080 m" to "گیشربرم اول – 8,080 میٹر",
        "Broad Peak – 8,051 m" to "براڈ پیک – 8,051 میٹر",
        "Gasherbrum II – 8,035 m" to "گیشربرم دوم – 8,035 میٹر",
        "Gasherbrum III – 7,952 m" to "گیشربرم سوم – 7,952 میٹر",
        "Gasherbrum IV – 7,925 m" to "گیشربرم چہارم – 7,925 میٹر",
        "Distaghil Sar – 7,885 m" to "دستغل سر – 7,885 میٹر",
        "Kunyang Chhish – 7,852 m" to "کنیانگ چھیش – 7,852 میٹر",
        "Masherbrum – 7,821 m" to "ماشربرم – 7,821 میٹر"
    ), "Heights are approximate. Several peaks lie on the border with China.",
        "بلندیاں تقریبی ہیں۔ کئی چوٹیاں چین کی سرحد پر واقع ہیں۔"),
    QuickList("cities", "🏙️", "Top 10 Largest Cities", "10 بڑے شہر", true, listOf(
        "Karachi" to "کراچی", "Lahore" to "لاہور", "Faisalabad" to "فیصل آباد",
        "Rawalpindi" to "راولپنڈی", "Gujranwala" to "گوجرانوالہ", "Peshawar" to "پشاور",
        "Multan" to "ملتان", "Hyderabad" to "حیدرآباد", "Islamabad" to "اسلام آباد", "Quetta" to "کوئٹہ"
    ), "Order follows the 2017 census and is approximate; newer counts may differ.",
        "ترتیب مردم شماری 2017 کے مطابق اور تقریبی ہے؛ نئے اعداد میں فرق ہو سکتا ہے۔"),
    QuickList("capitals", "🗺️", "Provinces and Capitals", "صوبے اور دارالحکومت", false, listOf(
        "Punjab – Lahore" to "پنجاب – لاہور",
        "Sindh – Karachi" to "سندھ – کراچی",
        "Khyber Pakhtunkhwa – Peshawar" to "خیبر پختونخوا – پشاور",
        "Balochistan – Quetta" to "بلوچستان – کوئٹہ",
        "Gilgit-Baltistan – Gilgit" to "گلگت بلتستان – گلگت",
        "Azad Jammu & Kashmir – Muzaffarabad" to "آزاد جموں و کشمیر – مظفرآباد",
        "Islamabad Capital Territory – Islamabad" to "وفاقی دارالحکومت – اسلام آباد"
    )),
    QuickList("passes", "⛰️", "Top 10 Mountain Passes", "10 اہم پہاڑی درے", true, listOf(
        "Khyber Pass – Peshawar to Afghanistan" to "درۂ خیبر – پشاور سے افغانستان",
        "Khunjerab Pass – border with China (about 4,693 m)" to "درۂ خنجراب – چین کی سرحد (تقریباً 4,693 میٹر)",
        "Bolan Pass – Quetta to Sibi, Balochistan" to "درۂ بولان – کوئٹہ سے سبی، بلوچستان",
        "Kurram Pass – Kurram to Afghanistan" to "درۂ کرم – کرم سے افغانستان",
        "Gomal Pass – South Waziristan to Afghanistan" to "درۂ گومل – جنوبی وزیرستان سے افغانستان",
        "Tochi Pass – North Waziristan to Afghanistan" to "درۂ توچی – شمالی وزیرستان سے افغانستان",
        "Lowari Pass – Dir to Chitral" to "درۂ لواری – دیر سے چترال",
        "Babusar Pass – Kaghan Valley to Chilas" to "درۂ بابوسر – وادی کاغان سے چلاس",
        "Malakand Pass – route to Swat" to "درۂ ملاکنڈ – سوات کا راستہ",
        "Shandur Pass – Chitral to Ghizer, famous for polo" to "درۂ شندور – چترال سے غذر، پولو کے لیے مشہور"
    )),
    QuickList("dams", "🌊", "Important Dams", "اہم ڈیم", false, listOf(
        "Tarbela – River Indus" to "تربیلا – دریائے سندھ",
        "Mangla – River Jhelum" to "منگلا – دریائے جہلم",
        "Warsak – River Kabul" to "وارسک – دریائے کابل",
        "Hub Dam – Hub River" to "حب ڈیم – دریائے حب",
        "Khanpur – Haro River" to "خانپور – دریائے ہرو",
        "Rawal Dam – Korang River" to "راول ڈیم – دریائے کورنگ",
        "Simly Dam – near Islamabad" to "سملی ڈیم – اسلام آباد کے قریب",
        "Diamer-Bhasha – River Indus (under construction)" to "دیامر بھاشا – دریائے سندھ (زیر تعمیر)",
        "Mohmand – River Swat (under construction)" to "مہمند – دریائے سوات (زیر تعمیر)"
    )),
    QuickList("deserts", "🏜️", "Deserts of Pakistan", "پاکستان کے صحرا", false, listOf(
        "Thar – Sindh (Tharparkar)" to "تھر – سندھ (تھرپارکر)",
        "Cholistan – Punjab, near Bahawalpur" to "چولستان – پنجاب، بہاولپور کے قریب",
        "Thal – Punjab, between the Indus and Jhelum" to "تھل – پنجاب، سندھ اور جہلم کے درمیان",
        "Kharan – Balochistan" to "خاران – بلوچستان"
    )),
    QuickList("lakes", "🏞️", "Famous Lakes", "مشہور جھیلیں", false, listOf(
        "Manchar – Sindh" to "منچھر – سندھ",
        "Keenjhar – near Thatta, Sindh" to "کینجھر – ٹھٹھہ کے قریب، سندھ",
        "Saif-ul-Malook – Kaghan Valley" to "سیف الملوک – وادی کاغان",
        "Dudipatsar – Kaghan Valley" to "دودی پت سر – وادی کاغان",
        "Attabad – Hunza" to "عطا آباد – ہنزہ",
        "Sadpara – Skardu" to "سدپارہ – اسکردو",
        "Shangrila – Skardu" to "شنگریلا – اسکردو",
        "Rawal – Islamabad" to "راول – اسلام آباد",
        "Hanna – near Quetta" to "ہنہ – کوئٹہ کے قریب"
    )),
    QuickList("parks", "🦌", "National Parks", "قومی پارکس", false, listOf(
        "Central Karakoram – Gilgit-Baltistan" to "سینٹرل قراقرم – گلگت بلتستان",
        "Khunjerab – Gilgit-Baltistan" to "خنجراب – گلگت بلتستان",
        "Deosai – Gilgit-Baltistan" to "دیوسائی – گلگت بلتستان",
        "Hingol – Balochistan" to "ہنگول – بلوچستان",
        "Kirthar – Sindh" to "کیرتھر – سندھ",
        "Lal Suhanra – Punjab (Bahawalpur)" to "لال سوہانرا – پنجاب (بہاولپور)",
        "Margalla Hills – Islamabad" to "مارگلہ ہلز – اسلام آباد",
        "Ayubia – Khyber Pakhtunkhwa" to "ایوبیہ – خیبر پختونخوا",
        "Chitral Gol – Khyber Pakhtunkhwa" to "چترال گول – خیبر پختونخوا",
        "Machiara – Azad Kashmir" to "مچھیارا – آزاد کشمیر"
    ))
)

@Composable
fun QuickFactsScreen(nav: (String) -> Unit, onBack: () -> Unit) {
    val lang = LocalLang.current
    PageScaffold(tr("Quick Facts", "فوری معلومات"), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(quickLists) { ql ->
                Card(
                    onClick = { nav("fact:${ql.id}") },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(ql.emoji, fontSize = 28.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(
                            if (lang == "ur") ql.ur else ql.en, fontSize = 16.sp,
                            fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickListScreen(id: String, onBack: () -> Unit) {
    val lang = LocalLang.current
    val ql = quickLists.firstOrNull { it.id == id }
    if (ql == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    PageScaffold(if (lang == "ur") ql.ur else ql.en, onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(ql.items) { i, p ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (ql.numbered) {
                            Box(
                                Modifier.size(30.dp).clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "${i + 1}", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                        }
                        Text(
                            if (lang == "ur") p.second else p.first, fontSize = 15.sp, lineHeight = 24.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            val note = if (lang == "ur") ql.noteUr else ql.noteEn
            if (note.isNotEmpty()) {
                item {
                    Text(
                        note, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

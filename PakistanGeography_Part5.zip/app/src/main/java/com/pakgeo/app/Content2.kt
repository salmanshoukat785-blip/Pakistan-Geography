package com.pakgeo.app

// Topic 2: Provinces and administrative divisions, Topic 3: Mountain ranges and peaks
val contentPart2: Map<String, Pair<String, String>> = mapOf(
    // ================= TOPIC 2 =================
    c("2.0",
"""
Punjab is the most populous province of Pakistan. Its capital is Lahore.

• Area: about 205,000 km² (roughly a quarter of the country)
• Population: more than half of Pakistan's people live here
• Name: "Punjab" means "land of five waters" (Persian)
• Rivers: Indus, Jhelum, Chenab, Ravi and Sutlej
• Land: fertile plains, the Potohar Plateau and Salt Range in the north, and the Cholistan and Thal deserts
• Climate: very hot summers and cool winters
• Major cities: Lahore, Faisalabad, Rawalpindi, Multan, Gujranwala
• Main crops: wheat, rice, cotton and sugarcane

Punjab is called the agricultural heartland of Pakistan.
""",
"""
پنجاب پاکستان کا سب سے زیادہ آبادی والا صوبہ ہے۔ اس کا دارالحکومت لاہور ہے۔

• رقبہ: تقریباً 205,000 مربع کلومیٹر (ملک کا تقریباً چوتھائی حصہ)
• آبادی: پاکستان کی آدھی سے زیادہ آبادی یہیں رہتی ہے
• نام: "پنجاب" کا مطلب ہے "پانچ پانیوں کی سرزمین" (فارسی)
• دریا: سندھ، جہلم، چناب، راوی اور ستلج
• زمین: زرخیز میدان، شمال میں پوٹھوہار کا سطح مرتفع اور سالٹ رینج، اور چولستان اور تھل کے صحرا
• آب و ہوا: شدید گرم گرمیاں اور ٹھنڈی سردیاں
• بڑے شہر: لاہور، فیصل آباد، راولپنڈی، ملتان، گوجرانوالہ
• اہم فصلیں: گندم، چاول، کپاس اور گنا

پنجاب کو پاکستان کا زرعی مرکز کہا جاتا ہے۔
"""),

    c("2.1",
"""
Sindh lies in the south-east of Pakistan. Its capital is Karachi.

• Area: about 141,000 km²
• Borders: Punjab (north), Balochistan (west), India (east) and the Arabian Sea (south)
• The Indus River flows through the whole province and ends in the Indus Delta.
• Landforms: the Indus plain, the Thar Desert in the east and the Kirthar Range in the west
• Lakes: Manchar and Keenjhar
• Ports: Karachi and Port Qasim
• Climate: hot and dry, with a milder sea breeze along the coast
• Major cities: Karachi, Hyderabad, Sukkur, Larkana
• Crops: rice, cotton, sugarcane, mangoes and bananas

Sindh is also home to the ancient site of Mohenjo-daro.
""",
"""
سندھ پاکستان کے جنوب مشرق میں واقع ہے۔ اس کا دارالحکومت کراچی ہے۔

• رقبہ: تقریباً 141,000 مربع کلومیٹر
• سرحدیں: شمال میں پنجاب، مغرب میں بلوچستان، مشرق میں بھارت اور جنوب میں بحیرہ عرب
• دریائے سندھ پورے صوبے سے گزر کر ڈیلٹا پر ختم ہوتا ہے۔
• زمینی ساخت: سندھ کا میدان، مشرق میں صحرائے تھر اور مغرب میں کوہ کیرتھر
• جھیلیں: منچھر اور کینجھر
• بندرگاہیں: کراچی اور پورٹ قاسم
• آب و ہوا: گرم اور خشک، ساحل پر سمندری ہوا سے نسبتاً معتدل
• بڑے شہر: کراچی، حیدرآباد، سکھر، لاڑکانہ
• فصلیں: چاول، کپاس، گنا، آم اور کیلا

سندھ میں موہنجو داڑو کا قدیم مقام بھی واقع ہے۔
"""),

    c("2.2",
"""
Khyber Pakhtunkhwa (KP) lies in the north-west of Pakistan. Its capital is Peshawar.

• Area: about 101,000 km² (after the former FATA merged into KP in 2018)
• Borders: Afghanistan (west), Punjab and Islamabad (east and south-east), Balochistan (south-west), Gilgit-Baltistan and Azad Kashmir (north and north-east)
• Mountains: the Hindu Kush, with Tirich Mir, and the Swat and Kaghan valleys
• Rivers: Indus, Kabul, Swat and Chitral
• Passes: Khyber, Lowari and Malakand
• Dams: Tarbela and Warsak
• Major cities: Peshawar, Mardan, Abbottabad, Mingora (Swat), Kohat, Dera Ismail Khan
• Crops: maize, wheat, sugarcane, tobacco and fruit

KP is known for its mountain scenery and its strategic position next to Afghanistan.
""",
"""
خیبر پختونخوا پاکستان کے شمال مغرب میں واقع ہے۔ اس کا دارالحکومت پشاور ہے۔

• رقبہ: تقریباً 101,000 مربع کلومیٹر (2018 میں سابق فاٹا کے انضمام کے بعد)
• سرحدیں: مغرب میں افغانستان، مشرق اور جنوب مشرق میں پنجاب اور اسلام آباد، جنوب مغرب میں بلوچستان، شمال اور شمال مشرق میں گلگت بلتستان اور آزاد کشمیر
• پہاڑ: کوہ ہندوکش (ترچ میر سمیت)، اور سوات اور کاغان کی وادیاں
• دریا: سندھ، کابل، سوات اور چترال
• درے: خیبر، لواری اور ملاکنڈ
• ڈیم: تربیلا اور وارسک
• بڑے شہر: پشاور، مردان، ایبٹ آباد، مینگورہ (سوات)، کوہاٹ، ڈیرہ اسماعیل خان
• فصلیں: مکئی، گندم، گنا، تمباکو اور پھل

خیبر پختونخوا اپنے پہاڑی مناظر اور افغانستان سے متصل اسٹریٹجک مقام کی وجہ سے مشہور ہے۔
"""),

    c("2.3",
"""
Balochistan is the largest province of Pakistan by area. Its capital is Quetta.

• Area: about 347,000 km² (around 44% of Pakistan)
• Population: the lowest density of all provinces
• Borders: Iran (west), Afghanistan (north), Sindh (east), Punjab and KP (north-east) and the Arabian Sea (south)
• Coast: about 770 km of Pakistan's 1,046 km coastline (the Makran coast)
• Land: a high dry plateau, the Sulaiman and Kirthar ranges, and the Kharan and Chagai deserts
• Rivers: Hingol, Dasht, Zhob, Porali (mostly seasonal)
• Resources: natural gas (Sui), coal, chromite, copper and gold (Reko Diq, Saindak)
• Port: Gwadar
• Climate: very cold winters in the highlands and extreme heat in the lowlands
• Major cities: Quetta, Gwadar, Turbat, Khuzdar, Sibi
""",
"""
بلوچستان رقبے کے لحاظ سے پاکستان کا سب سے بڑا صوبہ ہے۔ اس کا دارالحکومت کوئٹہ ہے۔

• رقبہ: تقریباً 347,000 مربع کلومیٹر (پاکستان کا تقریباً 44 فیصد)
• آبادی: تمام صوبوں میں سب سے کم کثافت
• سرحدیں: مغرب میں ایران، شمال میں افغانستان، مشرق میں سندھ، شمال مشرق میں پنجاب اور خیبر پختونخوا اور جنوب میں بحیرہ عرب
• ساحل: پاکستان کی 1,046 کلومیٹر ساحلی پٹی میں سے تقریباً 770 کلومیٹر (ساحل مکران)
• زمین: بلند خشک سطح مرتفع، کوہ سلیمان اور کوہ کیرتھر، اور خاران اور چاغی کے صحرا
• دریا: ہنگول، دشت، ژوب، پورالی (زیادہ تر موسمی)
• وسائل: قدرتی گیس (سوئی)، کوئلہ، کرومائٹ، تانبا اور سونا (ریکوڈک، سینڈک)
• بندرگاہ: گوادر
• آب و ہوا: بلند علاقوں میں شدید سردی اور نشیبی علاقوں میں شدید گرمی
• بڑے شہر: کوئٹہ، گوادر، تربت، خضدار، سبی
"""),

    c("2.4",
"""
Gilgit-Baltistan lies in the far north of Pakistan. Its capital is Gilgit. It is administered by Pakistan and has its own assembly.

• Area: about 72,971 km²
• Borders: China (north-east), Afghanistan's Wakhan Corridor (north), Khyber Pakhtunkhwa (west), and Azad Kashmir and Kashmir (south)
• The Karakoram, Himalaya and Hindu Kush ranges meet here.
• Peaks: K2, Nanga Parbat, Rakaposhi, Gasherbrum and Broad Peak
• Glaciers: Siachen, Baltoro, Biafo and Hispar
• Rivers: Indus, Gilgit, Hunza and Shyok
• Plateau: Deosai
• Roads: the Karakoram Highway leading to the Khunjerab Pass
• Main towns: Gilgit, Skardu, Hunza (Karimabad), Chilas, Gahkuch

It has the highest mountains and the most glaciers in Pakistan.
""",
"""
گلگت بلتستان پاکستان کے انتہائی شمال میں واقع ہے۔ اس کا دارالحکومت گلگت ہے۔ اس کا انتظام پاکستان کے پاس ہے اور اس کی اپنی اسمبلی ہے۔

• رقبہ: تقریباً 72,971 مربع کلومیٹر
• سرحدیں: شمال مشرق میں چین، شمال میں افغانستان کی واخان پٹی، مغرب میں خیبر پختونخوا، اور جنوب میں آزاد کشمیر اور کشمیر
• یہاں قراقرم، ہمالیہ اور ہندوکش کے سلسلے ملتے ہیں۔
• چوٹیاں: کے ٹو، نانگا پربت، راکاپوشی، گیشربرم اور براڈ پیک
• گلیشیئرز: سیاچن، بالتورو، بیافو اور ہسپر
• دریا: سندھ، گلگت، ہنزہ اور شیوک
• سطح مرتفع: دیوسائی
• سڑک: قراقرم ہائی وے جو درۂ خنجراب تک جاتی ہے
• اہم شہر: گلگت، اسکردو، ہنزہ (کریم آباد)، چلاس، گاہکوچ

پاکستان کے بلند ترین پہاڑ اور سب سے زیادہ گلیشیئرز یہیں ہیں۔
"""),

    c("2.5",
"""
Azad Jammu & Kashmir (AJK) lies in the north-east of Pakistan. Its capital is Muzaffarabad. It is administered by Pakistan and has its own government.

• Area: about 13,300 km²
• Land: green hills and valleys in the foothills of the Himalayas and the Pir Panjal range
• Rivers: Jhelum, Neelum and Poonch
• Mangla Dam stands on the Jhelum River near Mirpur.
• Neelum Valley is famous for its scenery.
• Major towns: Muzaffarabad, Mirpur, Kotli, Rawalakot, Bagh
• The October 2005 earthquake caused great damage here.
• Climate: mild summers and cold, snowy winters in the hills

Forests, rivers and tourism are important to its economy.
""",
"""
آزاد جموں و کشمیر پاکستان کے شمال مشرق میں واقع ہے۔ اس کا دارالحکومت مظفرآباد ہے۔ اس کا انتظام پاکستان کے پاس ہے اور اس کی اپنی حکومت ہے۔

• رقبہ: تقریباً 13,300 مربع کلومیٹر
• زمین: ہمالیہ اور پیر پنجال کے دامن میں سرسبز پہاڑ اور وادیاں
• دریا: جہلم، نیلم اور پونچھ
• منگلا ڈیم میرپور کے قریب دریائے جہلم پر واقع ہے۔
• وادی نیلم اپنے مناظر کی وجہ سے مشہور ہے۔
• اہم شہر: مظفرآباد، میرپور، کوٹلی، راولاکوٹ، باغ
• اکتوبر 2005 کے زلزلے نے یہاں بہت تباہی مچائی۔
• آب و ہوا: پہاڑوں میں معتدل گرمیاں اور ٹھنڈی برفیلی سردیاں

جنگلات، دریا اور سیاحت اس کی معیشت کے لیے اہم ہیں۔
"""),

    c("2.6",
"""
Islamabad is the capital of Pakistan. It is a planned city and a federal capital territory.

• Area: about 906 km²
• Location: at the foot of the Margalla Hills, on the Potohar Plateau, next to Rawalpindi
• Height: about 540 m above sea level
• Planned in the 1960s as the new capital; the city is laid out in a grid of lettered sectors (F, G, H, I)
• Population: more than 2 million (2023 census)
• Places: Faisal Mosque, Daman-e-Koh, Margalla Hills National Park, Shakarparian
• Water: Rawal Lake and Simly Dam
• Climate: humid subtropical, with hot summers, a monsoon season and cool winters

It is one of the greenest and best-planned cities in South Asia.
""",
"""
اسلام آباد پاکستان کا دارالحکومت ہے۔ یہ ایک منصوبہ بند شہر اور وفاقی دارالحکومت کا علاقہ ہے۔

• رقبہ: تقریباً 906 مربع کلومیٹر
• محل وقوع: مارگلہ کی پہاڑیوں کے دامن میں، سطح مرتفع پوٹھوہار پر، راولپنڈی کے ساتھ
• بلندی: سطح سمندر سے تقریباً 540 میٹر
• 1960 کی دہائی میں نئے دارالحکومت کے طور پر منصوبہ بند کیا گیا؛ شہر حروف والے سیکٹروں (ایف، جی، ایچ، آئی) کی صورت میں بنا ہے
• آبادی: 20 لاکھ سے زیادہ (مردم شماری 2023)
• مقامات: فیصل مسجد، دامن کوہ، مارگلہ ہلز نیشنل پارک، شکرپڑیاں
• پانی: راول جھیل اور سملی ڈیم
• آب و ہوا: مرطوب نیم استوائی، گرم گرمیاں، مون سون کا موسم اور ٹھنڈی سردیاں

یہ جنوبی ایشیا کے سب سے سرسبز اور بہترین منصوبہ بند شہروں میں سے ایک ہے۔
"""),

    c("2.7",
"""
A division is an administrative unit between a province and its districts. Each division is headed by a Commissioner.

Pakistan's administrative levels:
1. Federation and provinces
2. Divisions
3. Districts (each led by a Deputy Commissioner)
4. Tehsils (talukas in Sindh)
5. Union councils

Examples of divisions:
• Punjab: Lahore, Rawalpindi, Faisalabad, Multan, Gujranwala, Bahawalpur
• Sindh: Karachi, Hyderabad, Sukkur, Larkana
• Khyber Pakhtunkhwa: Peshawar, Mardan, Hazara, Malakand
• Balochistan: Quetta, Kalat, Makran, Zhob

The number of divisions can change when the government creates new ones, so check an official source for the latest list.
""",
"""
ڈویژن صوبے اور اس کے اضلاع کے درمیان ایک انتظامی اکائی ہے۔ ہر ڈویژن کا سربراہ کمشنر ہوتا ہے۔

پاکستان کی انتظامی سطحیں:
1. وفاق اور صوبے
2. ڈویژن
3. اضلاع (ہر ایک کا سربراہ ڈپٹی کمشنر)
4. تحصیلیں (سندھ میں تعلقے)
5. یونین کونسلیں

ڈویژنوں کی مثالیں:
• پنجاب: لاہور، راولپنڈی، فیصل آباد، ملتان، گوجرانوالہ، بہاولپور
• سندھ: کراچی، حیدرآباد، سکھر، لاڑکانہ
• خیبر پختونخوا: پشاور، مردان، ہزارہ، ملاکنڈ
• بلوچستان: کوئٹہ، قلات، مکران، ژوب

حکومت نئے ڈویژن بناتی رہتی ہے، اس لیے تعداد بدل سکتی ہے۔ تازہ فہرست کے لیے سرکاری ذریعہ دیکھیں۔
"""),

    c("2.8",
"""
A district is the main unit of local administration in Pakistan. Pakistan has well over 150 districts, and the number changes from time to time.

• A district is headed by a Deputy Commissioner (DC).
• Districts are divided into tehsils (talukas in Sindh).
• Districts are grouped into divisions.
• Chagai in Balochistan is the largest district of Pakistan by area (about 44,700 km²).
• Large cities such as Lahore, Karachi and Faisalabad have district status or contain several districts.
• A district's headquarters is usually a major town, such as Jhelum in Jhelum district.

Districts handle land records, law and order, and local development.
""",
"""
ضلع پاکستان میں مقامی انتظامیہ کی بنیادی اکائی ہے۔ پاکستان میں 150 سے زیادہ اضلاع ہیں، اور تعداد وقتاً فوقتاً بدلتی رہتی ہے۔

• ضلع کا سربراہ ڈپٹی کمشنر (ڈی سی) ہوتا ہے۔
• اضلاع تحصیلوں (سندھ میں تعلقوں) میں تقسیم ہوتے ہیں۔
• اضلاع کو ڈویژنوں میں جمع کیا جاتا ہے۔
• بلوچستان کا ضلع چاغی رقبے کے لحاظ سے پاکستان کا سب سے بڑا ضلع ہے (تقریباً 44,700 مربع کلومیٹر)۔
• لاہور، کراچی اور فیصل آباد جیسے بڑے شہر ضلع کی حیثیت رکھتے ہیں یا کئی اضلاع پر مشتمل ہیں۔
• ضلع کا صدر مقام عموماً کوئی بڑا شہر ہوتا ہے، جیسے ضلع جہلم کا صدر مقام جہلم۔

اضلاع زمین کے ریکارڈ، امن و امان اور مقامی ترقی کے کام سنبھالتے ہیں۔
"""),

    c("2.9",
"""
Important cities of Pakistan:

• Karachi (Sindh): the largest city, main port and commercial centre
• Lahore (Punjab): the cultural capital, famous for its history, gardens and the Badshahi Mosque
• Islamabad: the planned federal capital
• Faisalabad (Punjab): the centre of the textile industry, often called the "Manchester of Pakistan"
• Rawalpindi (Punjab): twin city of Islamabad, home of the army headquarters
• Peshawar (Khyber Pakhtunkhwa): one of the oldest living cities in South Asia, at the foot of the Khyber Pass
• Quetta (Balochistan): known as the "Fruit Garden of Pakistan", about 1,680 m above sea level
• Multan (Punjab): the "City of Saints"
• Hyderabad (Sindh): second largest city of Sindh
• Gujranwala (Punjab): an industrial city
""",
"""
پاکستان کے اہم شہر:

• کراچی (سندھ): سب سے بڑا شہر، اہم بندرگاہ اور تجارتی مرکز
• لاہور (پنجاب): ثقافتی دارالحکومت، اپنی تاریخ، باغات اور بادشاہی مسجد کے لیے مشہور
• اسلام آباد: منصوبہ بند وفاقی دارالحکومت
• فیصل آباد (پنجاب): ٹیکسٹائل صنعت کا مرکز، جسے اکثر "پاکستان کا مانچسٹر" کہا جاتا ہے
• راولپنڈی (پنجاب): اسلام آباد کا جڑواں شہر، فوج کے صدر دفاتر کا مقام
• پشاور (خیبر پختونخوا): جنوبی ایشیا کے قدیم ترین آباد شہروں میں سے ایک، درۂ خیبر کے دامن میں
• کوئٹہ (بلوچستان): "پاکستان کا پھلوں کا باغ" کہلاتا ہے، سطح سمندر سے تقریباً 1,680 میٹر بلند
• ملتان (پنجاب): "اولیاء کا شہر"
• حیدرآباد (سندھ): سندھ کا دوسرا بڑا شہر
• گوجرانوالہ (پنجاب): صنعتی شہر
"""),

    // ================= TOPIC 3 =================
    c("3.0",
"""
The Himalayas are the highest mountain system in the world. They stretch about 2,400 km across Asia, and their western end lies in northern Pakistan.

• In Pakistan the Himalayas cover parts of Gilgit-Baltistan, Azad Kashmir and northern Khyber Pakhtunkhwa (such as the Kaghan Valley).
• Nanga Parbat (8,126 m) anchors the western end of the range.
• The Himalayas are young fold mountains, formed when the Indian plate pushed into the Eurasian plate.
• They block the monsoon winds, which is why the northern plains receive rain.
• Snow and glaciers on the Himalayas feed the Indus and its rivers.
• Famous valleys: Kaghan, Neelum and Astore
""",
"""
ہمالیہ دنیا کا بلند ترین پہاڑی نظام ہے۔ یہ ایشیا میں تقریباً 2,400 کلومیٹر پھیلا ہوا ہے اور اس کا مغربی سرا شمالی پاکستان میں ہے۔

• پاکستان میں ہمالیہ گلگت بلتستان، آزاد کشمیر اور شمالی خیبر پختونخوا (جیسے وادی کاغان) کے حصوں پر مشتمل ہے۔
• نانگا پربت (8,126 میٹر) سلسلے کے مغربی سرے پر ہے۔
• ہمالیہ نوجوان تہہ دار پہاڑ ہیں، جو ہندوستانی پلیٹ کے یوریشیائی پلیٹ سے ٹکرانے سے بنے۔
• یہ مون سون ہواؤں کو روکتے ہیں، اسی لیے شمالی میدانوں میں بارش ہوتی ہے۔
• ہمالیہ کی برف اور گلیشیئر دریائے سندھ اور اس کے دریاؤں کو پانی دیتے ہیں۔
• مشہور وادیاں: کاغان، نیلم اور استور
"""),

    c("3.1",
"""
The Karakoram lies north of the Himalayas, mostly in Gilgit-Baltistan. Its name is Turkic and is often taken to mean "black gravel".

• It contains four of the world's fourteen 8,000-metre peaks: K2 (8,611 m), Gasherbrum I (8,080 m), Broad Peak (8,051 m) and Gasherbrum II (8,035 m).
• It has some of the longest glaciers outside the polar regions: Siachen (about 76 km), Baltoro and Biafo (each about 63 km) and Hispar (about 49 km).
• The Karakoram Highway runs through it and crosses the Khunjerab Pass into China.
• Glacier melt feeds the Indus and its tributaries, such as the Hunza, Shigar and Shyok.
• The Baltoro Glacier is the trekking route to K2 Base Camp.
""",
"""
قراقرم ہمالیہ کے شمال میں واقع ہے، زیادہ تر گلگت بلتستان میں۔ اس کا نام ترکی زبان کا ہے اور اس کا مطلب عموماً "کالی بجری" لیا جاتا ہے۔

• اس میں دنیا کی چودہ 8,000 میٹر سے بلند چوٹیوں میں سے چار ہیں: کے ٹو (8,611 میٹر)، گیشربرم اول (8,080 میٹر)، براڈ پیک (8,051 میٹر) اور گیشربرم دوم (8,035 میٹر)۔
• یہاں قطبی علاقوں کے باہر کے طویل ترین گلیشیئرز ہیں: سیاچن (تقریباً 76 کلومیٹر)، بالتورو اور بیافو (ہر ایک تقریباً 63 کلومیٹر) اور ہسپر (تقریباً 49 کلومیٹر)۔
• قراقرم ہائی وے اس سے گزرتی ہے اور درۂ خنجراب سے چین میں داخل ہوتی ہے۔
• گلیشیئروں کا پگھلا ہوا پانی دریائے سندھ اور اس کی شاخوں، جیسے ہنزہ، شگر اور شیوک، کو بھرتا ہے۔
• بالتورو گلیشیئر کے ساتھ کا راستہ کے ٹو بیس کیمپ کا ٹریک ہے۔
"""),

    c("3.2",
"""
The Hindu Kush is a mountain range that runs from Afghanistan into northern Pakistan, mainly through Chitral, Dir and Swat.

• Highest peak in Pakistan's part (and in the whole range): Tirich Mir, 7,708 m
• Length: about 800 km
• Passes: Lowari, Dorah and Baroghil
• Rivers: the Chitral (Kunar) and Kabul rivers
• Chitral's Kalash valleys (Bumburet, Rumbur and Birir) lie in its foothills.
• The ranges are rugged, with snowy peaks and deep valleys, and are an important source of water.

The Hindu Kush has long been a barrier and a route between South and Central Asia.
""",
"""
ہندوکش پہاڑی سلسلہ ہے جو افغانستان سے شمالی پاکستان میں آتا ہے، خاص طور پر چترال، دیر اور سوات سے گزرتا ہے۔

• پاکستان میں (اور پورے سلسلے میں) بلند ترین چوٹی: ترچ میر، 7,708 میٹر
• لمبائی: تقریباً 800 کلومیٹر
• درے: لواری، دورا اور باروغل
• دریا: دریائے چترال (کنڑ) اور دریائے کابل
• چترال کی کیلاش وادیاں (بمبوریت، رمبور اور بریر) اس کے دامن میں ہیں۔
• سلسلے دشوار گزار ہیں، برفیلی چوٹیوں اور گہری وادیوں کے ساتھ، اور پانی کا اہم ذریعہ ہیں۔

ہندوکش طویل عرصے سے جنوبی اور وسطی ایشیا کے درمیان رکاوٹ بھی رہا ہے اور راستہ بھی۔
"""),

    c("3.3",
"""
The Sulaiman Range lies on the western side of the Indus plain, running north to south along the border of Balochistan, Khyber Pakhtunkhwa and Punjab.

• Highest peak: Takht-e-Sulaiman, about 3,487 m
• It separates the Indus plain from the Balochistan Plateau.
• Passes such as the Gomal and Bolan connect the plain with the highlands.
• Fort Munro, near Dera Ghazi Khan, is a hill station in this range.
• The slopes are dry and rocky, with scrub and some juniper forest.
• Seasonal hill streams flow down toward the plain.
""",
"""
کوہ سلیمان دریائے سندھ کے میدان کے مغرب میں واقع ہے، اور بلوچستان، خیبر پختونخوا اور پنجاب کی سرحد کے ساتھ شمال سے جنوب چلتا ہے۔

• بلند ترین چوٹی: تختِ سلیمان، تقریباً 3,487 میٹر
• یہ سندھ کے میدان کو بلوچستان کے سطح مرتفع سے الگ کرتا ہے۔
• گومل اور بولان جیسے درے میدان کو بلند علاقوں سے ملاتے ہیں۔
• ڈیرہ غازی خان کے قریب فورٹ منرو اس سلسلے کا ایک پہاڑی تفریحی مقام ہے۔
• ڈھلوانیں خشک اور پتھریلی ہیں، جن پر جھاڑیاں اور کچھ صنوبر کے جنگلات ہیں۔
• موسمی پہاڑی نالے میدان کی طرف بہتے ہیں۔
"""),

    c("3.4",
"""
The Kirthar Range runs north to south along the border between Sindh and Balochistan, for about 300 km.

• Highest point: about 2,260 m (Kutte Ji Qabar)
• It separates the Indus plain from the Balochistan Plateau in the south.
• Kirthar National Park protects wildlife such as the Sindh ibex and urial.
• Gorakh Hill, in Dadu district, is a popular cool hill station.
• Ranikot Fort, one of the largest forts in the world, lies in its foothills.
• The climate is hot and dry, and rainfall is low.
""",
"""
کوہ کیرتھر سندھ اور بلوچستان کی سرحد کے ساتھ تقریباً 300 کلومیٹر شمال سے جنوب چلتا ہے۔

• بلند ترین مقام: تقریباً 2,260 میٹر (کتے جی قبر)
• یہ جنوب میں سندھ کے میدان کو بلوچستان کے سطح مرتفع سے الگ کرتا ہے۔
• کیرتھر نیشنل پارک سندھ آئبیکس اور اڑیال جیسے جنگلی جانوروں کی حفاظت کرتا ہے۔
• ضلع دادو میں گورکھ ہل ایک مقبول ٹھنڈا پہاڑی مقام ہے۔
• رانی کوٹ کا قلعہ، جو دنیا کے بڑے قلعوں میں سے ایک ہے، اس کے دامن میں ہے۔
• آب و ہوا گرم اور خشک ہے اور بارش کم ہوتی ہے۔
"""),

    c("3.5",
"""
The Salt Range is a line of low hills in northern Punjab, between the Jhelum and Indus rivers, south of the Potohar Plateau.

• Length: about 300 km
• Highest peak: Sakesar, about 1,522 m
• The Khewra Salt Mine, one of the largest salt mines in the world, is here.
• Other minerals: gypsum, coal and limestone
• Lakes: Kallar Kahar, Uchhali and Khabbeki
• Katas Raj, a group of ancient temples, lies in the range.

It is named for its huge deposits of rock salt.
""",
"""
سالٹ رینج شمالی پنجاب میں کم بلند پہاڑیوں کا سلسلہ ہے، جو دریائے جہلم اور سندھ کے درمیان، سطح مرتفع پوٹھوہار کے جنوب میں ہے۔

• لمبائی: تقریباً 300 کلومیٹر
• بلند ترین چوٹی: سکیسر، تقریباً 1,522 میٹر
• کھیوڑہ کی نمک کی کان، جو دنیا کی بڑی نمک کی کانوں میں سے ایک ہے، یہیں ہے۔
• دیگر معدنیات: جپسم، کوئلہ اور چونا پتھر
• جھیلیں: کلر کہار، اچھالی اور کھبیکی
• کٹاس راج، قدیم مندروں کا مجموعہ، اسی سلسلے میں ہے۔

اس کا نام چٹانی نمک کے بہت بڑے ذخائر کی وجہ سے پڑا۔
"""),

    c("3.6",
"""
K2 is the highest mountain in Pakistan and the second highest in the world.

• Height: about 8,611 m (after Mount Everest at 8,848 m)
• Location: the Karakoram range in Gilgit-Baltistan, on the border with China
• Other names: Chogori and Mount Godwin-Austen
• "K2" comes from the early survey mark Karakoram 2.
• First climbed on 31 July 1954 by an Italian expedition.
• First winter ascent: 16 January 2021, by a Nepali team.
• It is known as the "Savage Mountain" because it is steep and very dangerous.
• Trekkers reach its base camp via the Baltoro Glacier, starting from Askole.
""",
"""
کے ٹو پاکستان کا بلند ترین پہاڑ اور دنیا کا دوسرا بلند ترین پہاڑ ہے۔

• بلندی: تقریباً 8,611 میٹر (ماؤنٹ ایورسٹ 8,848 میٹر کے بعد)
• محل وقوع: گلگت بلتستان میں سلسلہ قراقرم، چین کی سرحد پر
• دیگر نام: چوگوری اور ماؤنٹ گاڈون آسٹن
• "کے ٹو" ابتدائی سروے کے نشان "قراقرم 2" سے آیا ہے۔
• پہلی بار 31 جولائی 1954 کو ایک اطالوی مہم نے سر کیا۔
• سردیوں میں پہلی چڑھائی: 16 جنوری 2021 کو ایک نیپالی ٹیم نے۔
• اسے "وحشی پہاڑ" کہا جاتا ہے کیونکہ یہ بہت عمودی اور انتہائی خطرناک ہے۔
• ٹریکر اس کے بیس کیمپ تک بالتورو گلیشیئر کے راستے، اسکولے گاؤں سے شروع ہو کر، پہنچتے ہیں۔
"""),

    c("3.7",
"""
Nanga Parbat is the second highest peak in Pakistan and the ninth highest in the world.

• Height: about 8,126 m
• Location: Diamer district, Gilgit-Baltistan, at the western end of the Himalayas
• Names: "Naked Mountain" (Diamer) and "Killer Mountain", because many climbers have died on it
• Its Rupal Face, about 4,600 m high, is among the tallest mountain faces in the world.
• First climbed on 3 July 1953 by Hermann Buhl, alone and without supplementary oxygen.
• Fairy Meadows is the famous green meadow and base for viewing it.
• The Indus River flows near its base.
""",
"""
نانگا پربت پاکستان کی دوسری اور دنیا کی نویں بلند ترین چوٹی ہے۔

• بلندی: تقریباً 8,126 میٹر
• محل وقوع: ضلع دیامر، گلگت بلتستان، ہمالیہ کے مغربی سرے پر
• نام: "ننگا پہاڑ" (دیامر) اور "قاتل پہاڑ"، کیونکہ اس پر بہت سے کوہ پیما جان گنوا چکے ہیں
• اس کی روپل فیس، تقریباً 4,600 میٹر بلند، دنیا کے بلند ترین پہاڑی رخوں میں سے ہے۔
• پہلی بار 3 جولائی 1953 کو ہرمن بول نے اکیلے اور اضافی آکسیجن کے بغیر سر کیا۔
• فیری میڈوز مشہور سرسبز میدان ہے اور اسے دیکھنے کا مرکز ہے۔
• دریائے سندھ اس کے دامن کے قریب سے گزرتا ہے۔
"""),

    c("3.8",
"""
Rakaposhi is a famous peak of the Karakoram, standing between the Hunza and Nagar valleys in Gilgit-Baltistan.

• Height: about 7,788 m
• Name: often translated as "shining wall" or "wall of mist"
• It rises very steeply from the Hunza valley, one of the greatest height differences over a short distance in the world.
• First climbed in 1958 by a British–Pakistani expedition.
• It can be seen clearly from the Karakoram Highway near Karimabad and Nagar.
• Rakaposhi Base Camp is a popular trek.
""",
"""
راکاپوشی قراقرم کی ایک مشہور چوٹی ہے، جو گلگت بلتستان میں وادی ہنزہ اور نگر کے درمیان کھڑی ہے۔

• بلندی: تقریباً 7,788 میٹر
• نام: اکثر "چمکتی دیوار" یا "دھند کی دیوار" ترجمہ کیا جاتا ہے
• یہ وادی ہنزہ سے بہت عمودی اٹھتی ہے، جو مختصر فاصلے میں بلندی کے سب سے بڑے فرقوں میں سے ایک ہے۔
• پہلی بار 1958 میں ایک برطانوی پاکستانی مہم نے سر کی۔
• یہ قراقرم ہائی وے سے کریم آباد اور نگر کے قریب صاف نظر آتی ہے۔
• راکاپوشی بیس کیمپ ایک مقبول ٹریک ہے۔
"""),

    c("3.9",
"""
Tirich Mir is the highest peak of the Hindu Kush range and the highest mountain in Khyber Pakhtunkhwa.

• Height: about 7,708 m
• Location: Chitral district, near the border with Afghanistan
• First climbed in 1950 by a Norwegian expedition.
• It towers over Chitral town and can be seen from long distances.
• Chitral is the main base for expeditions to the peak.
• Nearby Noshaq (7,492 m) on the Afghan border is the highest peak in Afghanistan.
""",
"""
ترچ میر سلسلہ ہندوکش کی بلند ترین چوٹی اور خیبر پختونخوا کا بلند ترین پہاڑ ہے۔

• بلندی: تقریباً 7,708 میٹر
• محل وقوع: ضلع چترال، افغانستان کی سرحد کے قریب
• پہلی بار 1950 میں ایک ناروے کی مہم نے سر کیا۔
• یہ چترال شہر پر چھایا رہتا ہے اور دور دور سے نظر آتا ہے۔
• چترال اس چوٹی کی مہمات کا اہم مرکز ہے۔
• قریب ہی افغان سرحد پر نوشاخ (7,492 میٹر) افغانستان کی بلند ترین چوٹی ہے۔
"""),

    c("3.10",
"""
Important mountain passes of Pakistan:

• Khyber Pass: connects Peshawar with Afghanistan; a historic route for invaders and traders
• Bolan Pass: links Quetta with Sibi and the Indus plain
• Khunjerab Pass: about 4,693 m; the border crossing with China on the Karakoram Highway
• Lowari Pass: about 3,118 m; links Dir and Chitral, and a long tunnel now passes under it
• Babusar Pass: about 4,173 m; links the Kaghan Valley with Chilas
• Shandur Pass: about 3,700 m; between Chitral and Gilgit-Baltistan, famous for its polo ground
• Kurram, Gomal and Tochi passes: link Pakistan with Afghanistan
• Malakand Pass: the route into Swat

Heights are approximate.
""",
"""
پاکستان کے اہم پہاڑی درے:

• درۂ خیبر: پشاور کو افغانستان سے ملاتا ہے؛ حملہ آوروں اور تاجروں کا تاریخی راستہ
• درۂ بولان: کوئٹہ کو سبی اور سندھ کے میدان سے ملاتا ہے
• درۂ خنجراب: تقریباً 4,693 میٹر؛ قراقرم ہائی وے پر چین کے ساتھ سرحدی گزرگاہ
• درۂ لواری: تقریباً 3,118 میٹر؛ دیر اور چترال کو ملاتا ہے، اور اب اس کے نیچے ایک لمبی سرنگ ہے
• درۂ بابوسر: تقریباً 4,173 میٹر؛ وادی کاغان کو چلاس سے ملاتا ہے
• درۂ شندور: تقریباً 3,700 میٹر؛ چترال اور گلگت بلتستان کے درمیان، اپنے پولو گراؤنڈ کے لیے مشہور
• درۂ کرم، گومل اور توچی: پاکستان کو افغانستان سے ملاتے ہیں
• درۂ ملاکنڈ: سوات جانے کا راستہ

بلندیاں تقریبی ہیں۔
""")
)

package com.pakgeo.app

fun c(key: String, en: String, ur: String): Pair<String, Pair<String, String>> =
    key to (en.trimIndent() to ur.trimIndent())

// ---------- Question builders ----------
fun o(en: String, ur: String): Pair<String, String> = en to ur

fun mcq(
    id: String, topic: Int, diff: Int, src: String,
    qEn: String, qUr: String, answer: Int, opts: List<Pair<String, String>>,
    expEn: String = "", expUr: String = ""
) = Q(id, topic, 0, diff, src, qEn, qUr, opts, answer, "", "", emptyList(), expEn, expUr)

fun tf(
    id: String, topic: Int, diff: Int, src: String,
    qEn: String, qUr: String, truth: Boolean,
    expEn: String = "", expUr: String = ""
) = Q(
    id, topic, 1, diff, src, qEn, qUr,
    listOf("True" to "درست", "False" to "غلط"), if (truth) 0 else 1,
    "", "", emptyList(), expEn, expUr
)

fun fib(
    id: String, topic: Int, diff: Int, src: String,
    qEn: String, qUr: String, aEn: String, aUr: String, alts: List<String>,
    expEn: String = "", expUr: String = ""
) = Q(id, topic, 2, diff, src, qEn, qUr, emptyList(), 0, aEn, aUr, alts, expEn, expUr)

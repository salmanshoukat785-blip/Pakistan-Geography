package com.pakgeo.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

enum class AppColor(
    val key: String, val en: String, val ur: String,
    val light: Color, val dark: Color
) {
    GREEN("green", "Green", "سبز", Color(0xFF01411C), Color(0xFF6FCF97)),
    BLUE("blue", "Blue", "نیلا", Color(0xFF0D47A1), Color(0xFF90CAF9)),
    BROWN("brown", "Brown", "بھورا", Color(0xFF6D4C41), Color(0xFFD7B8A8)),
    PURPLE("purple", "Purple", "جامنی", Color(0xFF6A1B9A), Color(0xFFCE93D8));

    companion object {
        fun from(key: String) = values().firstOrNull { it.key == key } ?: GREEN
    }
}

val LocalLang = staticCompositionLocalOf { "ur" }

@Composable
fun tr(en: String, ur: String): String = if (LocalLang.current == "ur") ur else en

@Composable
fun PakTheme(mode: String, colorKey: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val c = AppColor.from(colorKey)
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.dark,
            onPrimary = Color(0xFF10151A),
            secondary = c.dark,
            background = Color(0xFF101412),
            surface = Color(0xFF181D1A),
            surfaceVariant = Color(0xFF242A26),
            onBackground = Color(0xFFE6EAE7),
            onSurface = Color(0xFFE6EAE7)
        )
    } else {
        lightColorScheme(
            primary = c.light,
            onPrimary = Color.White,
            secondary = c.light,
            background = Color(0xFFF4F7F4),
            surface = Color.White,
            surfaceVariant = Color(0xFFE6ECE7),
            onBackground = Color(0xFF14201A),
            onSurface = Color(0xFF14201A)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

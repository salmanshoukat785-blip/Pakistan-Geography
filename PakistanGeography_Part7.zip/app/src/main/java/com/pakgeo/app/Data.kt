package com.pakgeo.app

data class Section(val topicId: Int, val index: Int, val en: String, val ur: String) {
    val key: String get() = "$topicId.$index"
}

/** (English title) to (Urdu title) for every sub-topic, in order. */
private val sectionTitles: Map<Int, List<Pair<String, String>>> = mapOf(
    1 to listOf(
        "Introduction to Pakistan" to "پاکستان کا تعارف",
        "Location of Pakistan" to "پاکستان کا محل وقوع",
        "Area of Pakistan" to "پاکستان کا رقبہ",
        "Geographical Importance of Pakistan" to "پاکستان کی جغرافیائی اہمیت",
        "Borders of Pakistan" to "پاکستان کی سرحدیں",
        "Neighbouring Countries" to "پاکستان کے ہمسایہ ممالک",
        "Latitude and Longitude" to "پاکستان کے عرض بلد اور طول بلد",
        "Pakistan Standard Time" to "پاکستان کے معیاری وقت کا تعین",
        "Major Geographical Regions" to "پاکستان کے اہم جغرافیائی خطے",
        "Map and Geographical Directions" to "پاکستان کا نقشہ اور جغرافیائی سمتیں"
    ),
    2 to listOf(
        "Geography of Punjab" to "پنجاب کا جغرافیہ",
        "Geography of Sindh" to "سندھ کا جغرافیہ",
        "Geography of Khyber Pakhtunkhwa" to "خیبر پختونخوا کا جغرافیہ",
        "Geography of Balochistan" to "بلوچستان کا جغرافیہ",
        "Geography of Gilgit-Baltistan" to "گلگت بلتستان کا جغرافیہ",
        "Geography of Azad Jammu & Kashmir" to "آزاد جموں و کشمیر کا جغرافیہ",
        "Geography of Islamabad" to "اسلام آباد کا جغرافیہ",
        "Divisions of Pakistan" to "پاکستان کے ڈویژن",
        "Districts of Pakistan" to "پاکستان کے اضلاع",
        "Major Cities of Pakistan" to "پاکستان کے بڑے شہر"
    ),
    3 to listOf(
        "The Himalayas" to "کوہ ہمالیہ",
        "The Karakoram Range" to "کوہ قراقرم",
        "The Hindu Kush" to "کوہ ہندوکش",
        "The Sulaiman Range" to "کوہ سلیمان",
        "The Kirthar Range" to "کوہ کیرتھر",
        "The Salt Range" to "سالٹ رینج",
        "K2" to "کے ٹو (K2)",
        "Nanga Parbat" to "نانگا پربت",
        "Rakaposhi" to "راکاپوشی",
        "Tirich Mir" to "ترچ میر",
        "Important Mountain Passes of Pakistan" to "پاکستان کے اہم پہاڑی درے"
    ),
    4 to listOf(
        "River Indus" to "دریائے سندھ",
        "River Jhelum" to "دریائے جہلم",
        "River Chenab" to "دریائے چناب",
        "River Ravi" to "دریائے راوی",
        "River Sutlej" to "دریائے ستلج",
        "River Kabul" to "دریائے کابل",
        "River Swat" to "دریائے سوات",
        "River Gomal" to "دریائے گومل",
        "Important Dams of Pakistan" to "پاکستان کے اہم ڈیم",
        "Tarbela Dam" to "تربیلا ڈیم",
        "Mangla Dam" to "منگلا ڈیم",
        "Warsak Dam" to "وارسک ڈیم",
        "Important Barrages of Pakistan" to "پاکستان کے اہم بیراج",
        "Canals of Pakistan" to "پاکستان کی نہریں",
        "Water Resources and Irrigation System" to "آبی وسائل اور آبپاشی کا نظام"
    ),
    5 to listOf(
        "Summer Season" to "موسم گرما",
        "Winter Season" to "موسم سرما",
        "Monsoon Rains" to "مون سون بارشیں",
        "Effects of Western Disturbances" to "مغربی ہواؤں کے اثرات",
        "Desert Climate" to "صحرائی آب و ہوا",
        "Mountain Climate" to "پہاڑی آب و ہوا",
        "Hottest Regions of Pakistan" to "پاکستان کے گرم ترین علاقے",
        "Coldest Regions of Pakistan" to "پاکستان کے سرد ترین علاقے",
        "Distribution of Rainfall in Pakistan" to "پاکستان میں بارشوں کی تقسیم"
    ),
    6 to listOf(
        "The Indus Plain" to "دریائے سندھ کا میدان",
        "The Upper Indus Plain" to "بالائی سندھ کا میدان",
        "The Lower Indus Plain" to "زیریں سندھ کا میدان",
        "The Potohar Plateau" to "پوٹھوہار کا سطح مرتفع",
        "The Balochistan Plateau" to "بلوچستان کا سطح مرتفع",
        "The Deosai Plateau" to "دیوسائی کا سطح مرتفع",
        "The Thar Desert" to "تھر کا صحرا",
        "The Cholistan Desert" to "چولستان کا صحرا",
        "The Thal Desert" to "تھل کا صحرا",
        "The Kharan Desert" to "خاران کا صحرا"
    ),
    7 to listOf(
        "Lake Saif-ul-Malook" to "جھیل سیف الملوک",
        "Attabad Lake" to "عطا آباد جھیل",
        "Manchar Lake" to "جھیل منچھر",
        "Keenjhar Lake" to "کینجھر جھیل",
        "Hanna Lake" to "ہنہ جھیل",
        "Rawal Lake" to "راول جھیل",
        "Sadpara Lake" to "سدپارہ جھیل",
        "Shangrila Lake" to "شنگریلا جھیل",
        "Naran and Kaghan" to "ناران اور کاغان",
        "Hunza" to "ہنزہ",
        "Skardu" to "اسکردو",
        "Swat Valley" to "وادی سوات"
    ),
    8 to listOf(
        "Forests of Pakistan" to "پاکستان کے جنگلات",
        "Mountain Forests" to "پہاڑی جنگلات",
        "Riverine Forests" to "دریائی جنگلات",
        "Desert Vegetation" to "صحرائی نباتات",
        "Coastal Mangroves" to "ساحلی مینگرووز",
        "Chinar Trees" to "چنار کے درخت",
        "Deodar Forests" to "دیودار کے جنگلات",
        "Importance of Forests" to "جنگلات کی اہمیت",
        "Deforestation and Related Problems" to "جنگلات کی کٹائی اور مسائل"
    ),
    9 to listOf(
        "Coal Reserves" to "کوئلے کے ذخائر",
        "Natural Gas" to "قدرتی گیس",
        "Oil Reserves" to "تیل کے ذخائر",
        "Salt Mines" to "نمک کی کانیں",
        "Copper and Gold Reserves" to "تانبے اور سونے کے ذخائر",
        "Chromite" to "کرومائٹ",
        "Marble" to "سنگ مرمر",
        "Limestone" to "چونا پتھر",
        "Gemstones" to "قیمتی پتھر",
        "Reko Diq Reserves" to "ریکوڈک کے ذخائر"
    ),
    10 to listOf(
        "Agriculture of Pakistan" to "پاکستان کی زراعت",
        "Wheat Production" to "گندم کی پیداوار",
        "Rice Production" to "چاول کی پیداوار",
        "Cotton Production" to "کپاس کی پیداوار",
        "Sugarcane Production" to "گنے کی پیداوار",
        "Maize Production" to "مکئی کی پیداوار",
        "Fruit Production" to "پھلوں کی پیداوار",
        "Irrigation System of Pakistan" to "پاکستان کا آبپاشی نظام",
        "Agricultural Lands" to "زرعی زمینیں",
        "Agricultural Problems" to "زرعی مسائل"
    ),
    11 to listOf(
        "The Arabian Sea" to "بحیرہ عرب",
        "Coastal Belt of Pakistan" to "پاکستان کی ساحلی پٹی",
        "Karachi Port" to "کراچی کی بندرگاہ",
        "Gwadar Port" to "گوادر بندرگاہ",
        "Port Qasim" to "پورٹ قاسم",
        "The Makran Coast" to "مکران کا ساحل",
        "The Indus Delta" to "دریائے سندھ کا ڈیلٹا",
        "Islands of Pakistan" to "جزائر پاکستان",
        "Marine Resources" to "سمندری وسائل"
    ),
    12 to listOf(
        "Population of Pakistan" to "پاکستان کی آبادی",
        "Population Distribution" to "آبادی کی تقسیم",
        "Population Density" to "آبادی کی کثافت",
        "Urban Population" to "شہری آبادی",
        "Rural Population" to "دیہی آبادی",
        "Major Cities and Their Importance" to "بڑے شہر اور ان کی اہمیت",
        "Migration" to "نقل مکانی",
        "Population Growth" to "آبادی میں اضافہ",
        "Human Resources" to "انسانی وسائل"
    ),
    13 to listOf(
        "Earthquakes in Pakistan" to "پاکستان میں زلزلے",
        "Floods" to "سیلاب",
        "Drought" to "خشک سالی",
        "Landslides" to "لینڈ سلائیڈنگ",
        "Melting of Glaciers" to "گلیشیئرز کا پگھلنا",
        "Climate Change" to "موسمیاتی تبدیلی",
        "Air Pollution" to "فضائی آلودگی",
        "Water Pollution" to "پانی کی آلودگی",
        "Soil Erosion" to "زمین کا کٹاؤ",
        "Desertification" to "صحرائی پھیلاؤ"
    ),
    14 to listOf(
        "Highest Point of Pakistan" to "پاکستان کا بلند ترین مقام",
        "Longest River of Pakistan" to "پاکستان کا سب سے طویل دریا",
        "Largest Desert of Pakistan" to "پاکستان کا سب سے بڑا صحرا",
        "Largest Lake of Pakistan" to "پاکستان کی سب سے بڑی جھیل",
        "Largest City of Pakistan" to "پاکستان کا سب سے بڑا شہر",
        "Highest Dam of Pakistan" to "پاکستان کا بلند ترین ڈیم",
        "Important Valleys of Pakistan" to "پاکستان کی اہم وادیاں",
        "Important Mountain Passes" to "اہم پہاڑی درے",
        "Important Border Crossings" to "اہم جغرافیائی سرحدی مقامات",
        "National Parks of Pakistan" to "پاکستان کے قومی پارکس"
    ),
    15 to listOf(
        "Political Map of Pakistan" to "پاکستان کا سیاسی نقشہ",
        "Physical Map of Pakistan" to "پاکستان کا طبعی نقشہ",
        "Map of Rivers of Pakistan" to "پاکستان کے دریاؤں کا نقشہ",
        "Map of Mountains of Pakistan" to "پاکستان کے پہاڑوں کا نقشہ",
        "Map of Deserts of Pakistan" to "پاکستان کے صحراؤں کا نقشہ",
        "Map of Dams of Pakistan" to "پاکستان کے ڈیموں کا نقشہ",
        "Map of Provinces of Pakistan" to "پاکستان کے صوبوں کا نقشہ",
        "Map of Major Cities of Pakistan" to "پاکستان کے اہم شہروں کا نقشہ",
        "Map of Borders of Pakistan" to "پاکستان کی سرحدوں کا نقشہ",
        "Map of Natural Resources of Pakistan" to "پاکستان کے قدرتی وسائل کا نقشہ"
    )
)

val allSections: List<Section> = sectionTitles.flatMap { (tid, list) ->
    list.mapIndexed { i, p -> Section(tid, i, p.first, p.second) }
}

fun sectionsOf(topicId: Int): List<Section> = allSections.filter { it.topicId == topicId }

/** Content map: key "topic.index" -> (English text to Urdu text). Later parts add more. */
val allContent: Map<String, Pair<String, String>> = contentPart1 + contentPart2 + contentPart3 + contentPart4


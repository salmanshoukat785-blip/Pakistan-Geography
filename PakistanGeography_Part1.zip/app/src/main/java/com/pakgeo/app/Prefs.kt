package com.pakgeo.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Saves language, theme mode and colour theme. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("pg_prefs", Context.MODE_PRIVATE)

    var lang by mutableStateOf(sp.getString("lang", "ur") ?: "ur")
        private set
    var themeMode by mutableStateOf(sp.getString("mode", "system") ?: "system")
        private set
    var colorKey by mutableStateOf(sp.getString("color", "green") ?: "green")
        private set

    fun setLang(v: String) { lang = v; sp.edit().putString("lang", v).apply() }
    fun setThemeMode(v: String) { themeMode = v; sp.edit().putString("mode", v).apply() }
    fun setColor(v: String) { colorKey = v; sp.edit().putString("color", v).apply() }
}

@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)

package com.pakgeo.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun PageScaffold(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = actions
            )
        },
        bottomBar = bottomBar,
        containerColor = MaterialTheme.colorScheme.background,
        content = content
    )
}

fun topicTitle(id: Int, lang: String): String {
    val t = topics.first { it.id == id }
    return if (lang == "ur") t.ur else t.en
}

@Composable
fun SectionRow(sec: Section, prefs: Prefs, showTopic: Boolean, onClick: () -> Unit) {
    val lang = LocalLang.current
    val read = sec.key in prefs.readSet
    val marked = sec.key in prefs.bookmarks
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(34.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "${sec.index + 1}", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (lang == "ur") sec.ur else sec.en,
                    fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (showTopic) {
                    Text(
                        topicTitle(sec.topicId, lang), fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
            if (marked) Text("⭐", fontSize = 16.sp)
            if (read) {
                Spacer(Modifier.width(6.dp))
                Text("✓", fontSize = 18.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun EmptyMessage(pad: PaddingValues, text: String) {
    Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text, fontSize = 16.sp, modifier = Modifier.padding(32.dp),
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
    }
}

// ---------- Book index ----------
@Composable
fun BookScreen(prefs: Prefs, nav: (String) -> Unit, onBack: () -> Unit) {
    val lang = LocalLang.current
    PageScaffold(tr("Book", "کتاب"), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    tr("Contents", "فہرست"), fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(topics) { t ->
                Card(
                    onClick = { nav("reader:${t.id}:0") },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.emoji, fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                tr("Chapter ${t.id}", "باب ${t.id}"), fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                if (lang == "ur") t.ur else t.en, fontSize = 15.sp,
                                fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            "${prefs.readCount(t.id)}/${sectionsOf(t.id).size}", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
}

// ---------- Topic (list of sections) ----------
@Composable
fun TopicScreen(prefs: Prefs, topicId: Int, nav: (String) -> Unit, onBack: () -> Unit) {
    val lang = LocalLang.current
    val secs = sectionsOf(topicId)
    PageScaffold(topicTitle(topicId, lang), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Button(
                    onClick = { nav("reader:$topicId:0") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(tr("Start reading", "پڑھنا شروع کریں")) }
            }
            items(secs) { sec ->
                SectionRow(sec, prefs, false) { nav("reader:$topicId:${sec.index}") }
            }
        }
    }
}

// ---------- Reader (swipe pages) ----------
@Composable
fun ReaderScreen(prefs: Prefs, topicId: Int, start: Int, onBack: () -> Unit) {
    val lang = LocalLang.current
    val secs = sectionsOf(topicId)
    val pager = rememberPagerState(initialPage = start.coerceIn(0, secs.size - 1)) { secs.size }
    val scope = rememberCoroutineScope()
    val cur = secs[pager.currentPage]

    LaunchedEffect(pager.currentPage) { prefs.markRead(secs[pager.currentPage].key) }

    PageScaffold(
        title = topicTitle(topicId, lang),
        onBack = onBack,
        actions = {
            IconButton(onClick = { prefs.toggleBookmark(cur.key) }) {
                Text(
                    if (cur.key in prefs.bookmarks) "★" else "☆", fontSize = 26.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        enabled = pager.currentPage > 0,
                        onClick = { scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }
                    ) { Text(tr("Previous", "پچھلا")) }
                    Text("${pager.currentPage + 1} / ${secs.size}", fontSize = 14.sp)
                    TextButton(
                        enabled = pager.currentPage < secs.size - 1,
                        onClick = { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }
                    ) { Text(tr("Next", "اگلا")) }
                }
            }
        }
    ) { pad ->
        HorizontalPager(state = pager, modifier = Modifier.padding(pad).fillMaxSize()) { page ->
            SectionPage(secs[page], lang)
        }
    }
}

@Composable
fun SectionPage(sec: Section, lang: String) {
    val body = allContent[sec.key]?.let { if (lang == "ur") it.second else it.first }
        ?: tr(
            "This section's content will be added in the next update.",
            "اس حصے کا مواد اگلی اپڈیٹ میں شامل کیا جائے گا۔"
        )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Text(
            if (lang == "ur") sec.ur else sec.en,
            fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.width(60.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.primary)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            body, fontSize = 17.sp, lineHeight = 30.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

// ---------- Search ----------
@Composable
fun SearchScreen(prefs: Prefs, nav: (String) -> Unit, onBack: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val term = q.trim()
    val results = remember(term) {
        if (term.length < 2) emptyList()
        else allSections.filter { s ->
            val body = allContent[s.key]
            s.en.contains(term, ignoreCase = true) ||
                s.ur.contains(term) ||
                (body != null && (body.first.contains(term, ignoreCase = true) || body.second.contains(term)))
        }
    }
    PageScaffold(tr("Search", "تلاش"), onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(14.dp)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(tr("Search topics...", "موضوعات تلاش کریں...")) }
            )
            Spacer(Modifier.height(12.dp))
            if (term.length >= 2 && results.isEmpty()) {
                Text(
                    tr("No results found", "کوئی نتیجہ نہیں ملا"),
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results) { sec ->
                    SectionRow(sec, prefs, true) { nav("reader:${sec.topicId}:${sec.index}") }
                }
            }
        }
    }
}

// ---------- Bookmarks ----------
@Composable
fun BookmarksScreen(prefs: Prefs, nav: (String) -> Unit, onBack: () -> Unit) {
    val list = allSections.filter { it.key in prefs.bookmarks }
    PageScaffold(tr("Bookmarks", "بک مارکس"), onBack) { pad ->
        if (list.isEmpty()) {
            EmptyMessage(
                pad,
                tr(
                    "No bookmarks yet. Tap the star while reading to save a section.",
                    "ابھی کوئی بک مارک نہیں۔ پڑھتے ہوئے ستارے پر ٹیپ کر کے حصہ محفوظ کریں۔"
                )
            )
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list) { sec ->
                    SectionRow(sec, prefs, true) { nav("reader:${sec.topicId}:${sec.index}") }
                }
            }
        }
    }
}

// ---------- Progress ----------
@Composable
fun ProgressScreen(prefs: Prefs, onBack: () -> Unit) {
    val lang = LocalLang.current
    val total = allSections.size
    val read = allSections.count { it.key in prefs.readSet }
    val frac = if (total == 0) 0f else read.toFloat() / total
    PageScaffold(tr("Progress", "پیش رفت"), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            "${(frac * 100).toInt()}%", fontSize = 40.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            tr("$read of $total sections read", "$total میں سے $read حصے پڑھے گئے"),
                            fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(8.dp))
                    }
                }
            }
            items(topics) { t ->
                val n = sectionsOf(t.id).size
                val r = prefs.readCount(t.id)
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "${t.emoji}  ${if (lang == "ur") t.ur else t.en}",
                            fontSize = 14.sp, modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text("$r/$n", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { if (n == 0) 0f else r.toFloat() / n },
                        modifier = Modifier.fillMaxWidth().height(6.dp)
                    )
                }
            }
        }
    }
}

package com.pakgeo.app

// Topic 14: Important places and general knowledge, Topic 15: Maps and practical geography
val contentPart7: Map<String, Pair<String, String>> = mapOf(
    // ================= TOPIC 14 =================
    c("14.0",
"""
The highest point of Pakistan is K2, at about 8,611 m, the second highest mountain in the world.

• Location: Karakoram range, Gilgit-Baltistan, on the border with China
• Pakistan has five of the world's fourteen 8,000-metre peaks: K2, Nanga Parbat, Gasherbrum I, Broad Peak and Gasherbrum II.
• It has well over 100 peaks higher than 7,000 m.
• Lowest point: sea level, on the Arabian Sea coast

Highest points of some regions:
• Khyber Pakhtunkhwa: Tirich Mir, 7,708 m
• Balochistan: Zarghun Ghar, about 3,580 m
• Sindh: Kirthar Range, about 2,260 m
• Punjab: Sakesar, 1,522 m
""",
"""
پاکستان کا بلند ترین مقام کے ٹو ہے، تقریباً 8,611 میٹر، جو دنیا کا دوسرا بلند ترین پہاڑ ہے۔

• محل وقوع: سلسلہ قراقرم، گلگت بلتستان، چین کی سرحد پر
• دنیا کی چودہ 8,000 میٹر چوٹیوں میں سے پانچ پاکستان میں ہیں: کے ٹو، نانگا پربت، گیشربرم اول، براڈ پیک اور گیشربرم دوم۔
• 7,000 میٹر سے بلند 100 سے زیادہ چوٹیاں یہاں ہیں۔
• پست ترین مقام: سطح سمندر، بحیرہ عرب کے ساحل پر

بعض خطوں کے بلند ترین مقامات:
• خیبر پختونخوا: ترچ میر، 7,708 میٹر
• بلوچستان: زرغون غر، تقریباً 3,580 میٹر
• سندھ: کوہ کیرتھر، تقریباً 2,260 میٹر
• پنجاب: سکیسر، 1,522 میٹر
"""),

    c("14.1",
"""
The longest river of Pakistan is the Indus, about 3,180 km long in total.

Rivers in order of total length:
1. Indus: about 3,180 km
2. Sutlej: about 1,450 km
3. Chenab: about 960 km
4. Jhelum: about 725 km
5. Ravi: about 720 km

• The Indus is also the river with the greatest flow and the most important for farming and drinking water.
• It begins in Tibet, enters Pakistan in Gilgit-Baltistan and falls into the Arabian Sea in Sindh.
• The Indus plain and the ancient Indus Valley civilisation grew along it.
""",
"""
پاکستان کا سب سے طویل دریا دریائے سندھ ہے، جس کی کل لمبائی تقریباً 3,180 کلومیٹر ہے۔

کل لمبائی کے لحاظ سے دریا:
1. سندھ: تقریباً 3,180 کلومیٹر
2. ستلج: تقریباً 1,450 کلومیٹر
3. چناب: تقریباً 960 کلومیٹر
4. جہلم: تقریباً 725 کلومیٹر
5. راوی: تقریباً 720 کلومیٹر

• دریائے سندھ سب سے زیادہ بہاؤ والا اور زراعت اور پینے کے پانی کے لیے سب سے اہم دریا بھی ہے۔
• یہ تبت سے شروع ہوتا ہے، گلگت بلتستان میں پاکستان میں داخل ہوتا ہے اور سندھ میں بحیرہ عرب میں گرتا ہے۔
• وادیٔ سندھ کا میدان اور قدیم وادیٔ سندھ کی تہذیب اسی کے کنارے پروان چڑھی۔
"""),

    c("14.2",
"""
Pakistan has several major deserts:

• Thar (Sindh): part of the Great Indian Desert, about 200,000 km² in total; about 20,000 km² lie in Pakistan
• Cholistan (Punjab): about 26,000 km²
• Thal (Punjab)
• Kharan (Balochistan)

Exam note: many textbooks and tests give the Thar as the largest desert, because the Thar as a whole is the biggest desert in the region. Measured only inside Pakistan, Cholistan is slightly larger. Follow your syllabus for exam answers.

The Thar is among the most thickly populated deserts in the world.
""",
"""
پاکستان میں کئی بڑے صحرا ہیں:

• تھر (سندھ): عظیم ہندوستانی صحرا کا حصہ، کل تقریباً 200,000 مربع کلومیٹر؛ تقریباً 20,000 مربع کلومیٹر پاکستان میں ہے
• چولستان (پنجاب): تقریباً 26,000 مربع کلومیٹر
• تھل (پنجاب)
• خاران (بلوچستان)

امتحانی نوٹ: بہت سی نصابی کتابیں اور ٹیسٹ تھر کو سب سے بڑا صحرا بتاتے ہیں، کیونکہ پورا تھر خطے کا سب سے بڑا صحرا ہے۔ صرف پاکستان کے اندر ناپیں تو چولستان کچھ بڑا ہے۔ امتحان کے جواب کے لیے اپنے نصاب کی پیروی کریں۔

تھر دنیا کے سب سے گنجان آباد صحراؤں میں سے ہے۔
"""),

    c("14.3",
"""
Important lakes of Pakistan:

• Largest natural freshwater lake: Manchar Lake (Sindh)
• Keenjhar Lake (Sindh): another very large freshwater lake and a source of water for Karachi
• Largest reservoirs: Tarbela Lake (about 250 km²) and Mangla Lake
• Highest-altitude famous lake: Saif-ul-Malook (about 3,224 m); some remote lakes such as Rush Lake in Nagar lie much higher.
• Attabad Lake: formed by a landslide in 2010
• Salt and seasonal lakes in Balochistan, such as Hamun-i-Mashkel

Lake sizes change with the seasons and water level.
""",
"""
پاکستان کی اہم جھیلیں:

• سب سے بڑی قدرتی میٹھے پانی کی جھیل: جھیل منچھر (سندھ)
• کینجھر جھیل (سندھ): ایک اور بہت بڑی میٹھے پانی کی جھیل اور کراچی کے لیے پانی کا ذریعہ
• سب سے بڑے آبی ذخائر: تربیلا جھیل (تقریباً 250 مربع کلومیٹر) اور منگلا جھیل
• سب سے بلند مشہور جھیل: سیف الملوک (تقریباً 3,224 میٹر)؛ نگر میں رش جھیل جیسی کچھ دور دراز جھیلیں اس سے کہیں بلند ہیں۔
• عطا آباد جھیل: 2010 میں لینڈ سلائیڈنگ سے بنی
• بلوچستان میں نمکین اور موسمی جھیلیں، جیسے ہامون مشکیل

جھیلوں کا حجم موسم اور پانی کی سطح کے ساتھ بدلتا ہے۔
"""),

    c("14.4",
"""
Karachi is the largest city of Pakistan.

• Population: over 20 million at the 2023 census (Karachi division)
• Capital of Sindh and Pakistan's first capital (1947–1959)
• Pakistan's main port, financial centre and largest industrial city
• Home of the Pakistan Stock Exchange and the head offices of many banks
• Lahore is the second largest city, with over 13 million people in its district.
• Islamabad is the federal capital.

City figures depend on whether city limits or whole districts are counted, so numbers vary between sources.
""",
"""
کراچی پاکستان کا سب سے بڑا شہر ہے۔

• آبادی: مردم شماری 2023 میں 2 کروڑ سے زیادہ (کراچی ڈویژن)
• سندھ کا دارالحکومت اور پاکستان کا پہلا دارالحکومت (1947 تا 1959)
• پاکستان کی اہم بندرگاہ، مالیاتی مرکز اور سب سے بڑا صنعتی شہر
• پاکستان اسٹاک ایکسچینج اور کئی بینکوں کے صدر دفاتر کا مقام
• لاہور دوسرا بڑا شہر ہے، جس کے ضلع کی آبادی 1.3 کروڑ سے زیادہ ہے۔
• اسلام آباد وفاقی دارالحکومت ہے۔

شہروں کے اعداد اس بات پر منحصر ہیں کہ شہر کی حدود شمار ہوں یا پورے اضلاع، اس لیے ذرائع میں اعداد مختلف ہو سکتے ہیں۔
"""),

    c("14.5",
"""
Pakistan's biggest dams:

• Tarbela (Indus): about 143 m high; the largest by volume and the world's largest earth-filled dam
• Mangla (Jhelum): about 147 m high, slightly taller than Tarbela
• Warsak (Kabul): about 76 m high

Under construction:
• Diamer-Bhasha (Indus): about 272 m high, to be the tallest dam in Pakistan
• Mohmand (Swat River): about 213 m high
• Dasu (Indus): a large hydropower project

Sources may give different heights, depending on how height is measured.
""",
"""
پاکستان کے سب سے بڑے ڈیم:

• تربیلا (سندھ): تقریباً 143 میٹر بلند؛ حجم کے لحاظ سے سب سے بڑا اور دنیا کا سب سے بڑا مٹی بھرا ڈیم
• منگلا (جہلم): تقریباً 147 میٹر بلند، تربیلا سے کچھ اونچا
• وارسک (کابل): تقریباً 76 میٹر بلند

زیر تعمیر:
• دیامر بھاشا (سندھ): تقریباً 272 میٹر بلند، پاکستان کا سب سے بلند ڈیم ہوگا
• مہمند (دریائے سوات): تقریباً 213 میٹر بلند
• داسو (سندھ): ایک بڑا پن بجلی منصوبہ

ذرائع بلندی کے مختلف اعداد دے سکتے ہیں، یہ اس پر منحصر ہے کہ بلندی کیسے ناپی گئی۔
"""),

    c("14.6",
"""
Important valleys of Pakistan:

• Hunza and Nagar (Gilgit-Baltistan): forts, orchards and high peaks
• Skardu and Shigar (Baltistan): gateway to K2
• Swat (KP): green hills, rivers and Buddhist heritage
• Kaghan and Naran (KP): lakes and alpine meadows
• Neelum (Azad Kashmir): forests and the Neelum River
• Chitral and the Kalash valleys (Bumburet, Rumbur, Birir)
• Astore and Deosai (Gilgit-Baltistan)
• Gojal (upper Hunza): Passu and the Khunjerab area
• Ziarat and Urak (Balochistan): juniper forest and orchards
• Peshawar and Quetta valleys: major cities in fertile basins
""",
"""
پاکستان کی اہم وادیاں:

• ہنزہ اور نگر (گلگت بلتستان): قلعے، باغات اور بلند چوٹیاں
• اسکردو اور شگر (بلتستان): کے ٹو کا دروازہ
• سوات (خیبر پختونخوا): سبز پہاڑیاں، دریا اور بدھ ورثہ
• کاغان اور ناران (خیبر پختونخوا): جھیلیں اور بلند چراگاہیں
• نیلم (آزاد کشمیر): جنگلات اور دریائے نیلم
• چترال اور کیلاش کی وادیاں (بمبوریت، رمبور، بریر)
• استور اور دیوسائی (گلگت بلتستان)
• گوجال (بالائی ہنزہ): پاسو اور خنجراب کا علاقہ
• زیارت اور اوڑک (بلوچستان): صنوبر کا جنگل اور باغات
• وادیٔ پشاور اور وادیٔ کوئٹہ: زرخیز طاسوں میں بڑے شہر
"""),

    c("14.7",
"""
Important mountain passes by region:

North (Karakoram and Himalaya):
• Khunjerab (about 4,693 m): the border with China
• Kilik and Mintaka: other high passes toward China
• Babusar (about 4,173 m): Kaghan to Chilas
• Shandur (about 3,700 m): Chitral to Gilgit-Baltistan

North-west:
• Khyber, Kurram, Tochi and Gomal: routes to Afghanistan
• Lowari (about 3,118 m): Dir to Chitral; a tunnel passes under it
• Malakand: the way into Swat

West (Balochistan):
• Bolan: Quetta to Sibi
• Khojak: Quetta to Chaman and Afghanistan

Heights are approximate.
""",
"""
خطے کے لحاظ سے اہم پہاڑی درے:

شمال (قراقرم اور ہمالیہ):
• خنجراب (تقریباً 4,693 میٹر): چین کی سرحد
• کلک اور منٹکا: چین کی طرف دیگر بلند درے
• بابوسر (تقریباً 4,173 میٹر): کاغان سے چلاس
• شندور (تقریباً 3,700 میٹر): چترال سے گلگت بلتستان

شمال مغرب:
• خیبر، کرم، توچی اور گومل: افغانستان کے راستے
• لواری (تقریباً 3,118 میٹر): دیر سے چترال؛ اس کے نیچے سرنگ ہے
• ملاکنڈ: سوات کا راستہ

مغرب (بلوچستان):
• بولان: کوئٹہ سے سبی
• خوجک: کوئٹہ سے چمن اور افغانستان

بلندیاں تقریبی ہیں۔
"""),

    c("14.8",
"""
Important border crossings of Pakistan:

With Afghanistan:
• Torkham (Khyber): the busiest crossing
• Chaman (Balochistan)
• Ghulam Khan, Angoor Adda and Kharlachi

With India:
• Wagah–Attari (near Lahore): the famous daily flag ceremony
• Khokhrapar–Munabao (Sindh): a railway link

With Iran:
• Taftan (Balochistan): the main road and rail crossing
• Gabd–Rimdan

With China:
• Khunjerab Pass, with the dry port at Sost

The opening of crossings changes with the situation, so check the latest rules.
""",
"""
پاکستان کی اہم سرحدی گزرگاہیں:

افغانستان کے ساتھ:
• طورخم (خیبر): سب سے مصروف گزرگاہ
• چمن (بلوچستان)
• غلام خان، انگور اڈہ اور خرلاچی

بھارت کے ساتھ:
• واہگہ اٹاری (لاہور کے قریب): روزانہ پرچم اتارنے کی مشہور تقریب
• کھوکھراپار مونا باؤ (سندھ): ریلوے رابطہ

ایران کے ساتھ:
• تفتان (بلوچستان): مرکزی سڑک اور ریل کی گزرگاہ
• گبد رمدان

چین کے ساتھ:
• درۂ خنجراب، سوست کی خشک بندرگاہ کے ساتھ

گزرگاہوں کا کھلنا حالات کے مطابق بدلتا ہے، اس لیے تازہ قواعد دیکھ لیں۔
"""),

    c("14.9",
"""
National parks protect wildlife and natural areas. Pakistan has dozens of protected areas, including these national parks:

• Central Karakoram (Gilgit-Baltistan): the largest, about 10,000 km²
• Khunjerab (Gilgit-Baltistan): snow leopard and Marco Polo sheep
• Deosai (Gilgit-Baltistan): Himalayan brown bear
• Hingol (Balochistan): the largest in the province, on the Makran coast
• Kirthar (Sindh): ibex and urial
• Lal Suhanra (Punjab): blackbuck in the Cholistan area
• Margalla Hills (Islamabad)
• Ayubia (KP) and Chitral Gol (KP, markhor)
• Machiara (Azad Kashmir)
• Hazarganji–Chiltan (Balochistan): the Chiltan markhor
""",
"""
قومی پارک جنگلی حیات اور قدرتی علاقوں کی حفاظت کرتے ہیں۔ پاکستان میں درجنوں محفوظ علاقے ہیں، جن میں یہ قومی پارک شامل ہیں:

• سینٹرل قراقرم (گلگت بلتستان): سب سے بڑا، تقریباً 10,000 مربع کلومیٹر
• خنجراب (گلگت بلتستان): برفانی چیتا اور مارکو پولو بھیڑ
• دیوسائی (گلگت بلتستان): ہمالیائی بھورا ریچھ
• ہنگول (بلوچستان): صوبے کا سب سے بڑا، ساحل مکران پر
• کیرتھر (سندھ): آئبیکس اور اڑیال
• لال سوہانرا (پنجاب): چولستان کے علاقے میں کالا ہرن
• مارگلہ ہلز (اسلام آباد)
• ایوبیہ (خیبر پختونخوا) اور چترال گول (خیبر پختونخوا، مارخور)
• مچھیارا (آزاد کشمیر)
• ہزارگنجی چلتن (بلوچستان): چلتن کا مارخور
"""),

    // ================= TOPIC 15 =================
    c("15.0",
"""
A political map shows boundaries made by people: countries, provinces, districts and capitals.

What to mark on Pakistan's political map:
• Provinces: Punjab, Sindh, Khyber Pakhtunkhwa and Balochistan
• Other units: Gilgit-Baltistan, Azad Jammu & Kashmir and Islamabad Capital Territory
• Capital: Islamabad; provincial capitals: Lahore, Karachi, Peshawar, Quetta
• Neighbours: Afghanistan, China, India and Iran, and the Arabian Sea
• International boundaries and the Line of Control

Reading tips: each province has its own colour; capitals are marked with a star or a dot; the legend explains the symbols.

Location guide: Balochistan is in the west, Punjab in the centre and east, Sindh in the south-east, and Khyber Pakhtunkhwa in the north-west.
""",
"""
سیاسی نقشہ انسانوں کی بنائی ہوئی حدود دکھاتا ہے: ممالک، صوبے، اضلاع اور دارالحکومت۔

پاکستان کے سیاسی نقشے پر کیا نشان زد کریں:
• صوبے: پنجاب، سندھ، خیبر پختونخوا اور بلوچستان
• دیگر اکائیاں: گلگت بلتستان، آزاد جموں و کشمیر اور وفاقی دارالحکومت اسلام آباد
• دارالحکومت: اسلام آباد؛ صوبائی دارالحکومت: لاہور، کراچی، پشاور، کوئٹہ
• ہمسایے: افغانستان، چین، بھارت اور ایران، اور بحیرہ عرب
• بین الاقوامی سرحدیں اور لائن آف کنٹرول

پڑھنے کے اشارے: ہر صوبے کا اپنا رنگ ہوتا ہے؛ دارالحکومت ستارے یا نقطے سے دکھائے جاتے ہیں؛ علامات کی فہرست علامتوں کی وضاحت کرتی ہے۔

مقام کی رہنمائی: بلوچستان مغرب میں، پنجاب وسط اور مشرق میں، سندھ جنوب مشرق میں، اور خیبر پختونخوا شمال مغرب میں ہے۔
"""),

    c("15.1",
"""
A physical map shows natural features: mountains, plateaus, plains, deserts, rivers, lakes and the coast.

Common colours:
• Green: low plains
• Yellow and brown: plateaus, hills and mountains (darker means higher)
• White: snow and glaciers
• Blue: rivers, lakes and the sea

Pakistan's physical regions:
1. Northern mountains: K2, Nanga Parbat, Rakaposhi
2. Western highlands: Sulaiman, Kirthar, Balochistan Plateau
3. Potohar Plateau and Salt Range
4. Indus plain
5. Deserts: Thar, Cholistan, Thal, Kharan
6. Coastal belt

Tip: elevation is shown with contour lines and spot heights.
""",
"""
طبعی نقشہ قدرتی خصوصیات دکھاتا ہے: پہاڑ، سطح مرتفع، میدان، صحرا، دریا، جھیلیں اور ساحل۔

عام رنگ:
• سبز: نشیبی میدان
• پیلا اور بھورا: سطح مرتفع، پہاڑیاں اور پہاڑ (گہرا رنگ زیادہ بلندی)
• سفید: برف اور گلیشیئر
• نیلا: دریا، جھیلیں اور سمندر

پاکستان کے طبعی خطے:
1. شمالی پہاڑ: کے ٹو، نانگا پربت، راکاپوشی
2. مغربی بلند علاقے: سلیمان، کیرتھر، بلوچستان کا سطح مرتفع
3. سطح مرتفع پوٹھوہار اور سالٹ رینج
4. سندھ کا میدان
5. صحرا: تھر، چولستان، تھل، خاران
6. ساحلی پٹی

اشارہ: بلندی کو کنٹور لائنوں اور بلندی کے نشانات سے ظاہر کیا جاتا ہے۔
"""),

    c("15.2",
"""
The rivers map shows the Indus river system.

Main rivers to mark:
• Indus: from the north (Gilgit-Baltistan) to the Arabian Sea at Keti Bandar
• Right-bank rivers: Kabul, Swat, Gomal
• Left-bank rivers: Jhelum, Chenab, Ravi and Sutlej
• Panjnad: formed by the five Punjab rivers, joins the Indus near Mithankot

Important meeting points:
• Kabul meets the Indus near Attock
• Jhelum meets the Chenab at Trimmu
• Ravi meets the Chenab near Ahmadpur Sial
• Sutlej meets the Chenab near Uch Sharif

Also mark: Tarbela, Mangla and the Sukkur and Kotri barrages, and the Hub, Hingol and Dasht rivers of Balochistan.

Tip: most rivers flow from the north-east to the south-west.
""",
"""
دریاؤں کا نقشہ دریائے سندھ کا نظام دکھاتا ہے۔

نشان زد کرنے کے اہم دریا:
• سندھ: شمال (گلگت بلتستان) سے کیٹی بندر پر بحیرہ عرب تک
• دائیں کنارے کے دریا: کابل، سوات، گومل
• بائیں کنارے کے دریا: جہلم، چناب، راوی اور ستلج
• پنجند: پنجاب کے پانچوں دریاؤں سے بنتا ہے، مٹھن کوٹ کے قریب سندھ میں ملتا ہے

اہم ملاپ کے مقامات:
• کابل اٹک کے قریب سندھ سے ملتا ہے
• جہلم تریموں میں چناب سے ملتا ہے
• راوی احمد پور سیال کے قریب چناب سے ملتا ہے
• ستلج اُچ شریف کے قریب چناب سے ملتا ہے

یہ بھی نشان زد کریں: تربیلا، منگلا، اور سکھر اور کوٹری بیراج، اور بلوچستان کے حب، ہنگول اور دشت دریا۔

اشارہ: زیادہ تر دریا شمال مشرق سے جنوب مغرب کی طرف بہتے ہیں۔
"""),

    c("15.3",
"""
The mountains map shows the great ranges of the north and west.

Ranges to mark:
• Karakoram (north-east): K2, Broad Peak, Gasherbrum, Rakaposhi
• Himalaya (north-east): Nanga Parbat
• Hindu Kush (north-west): Tirich Mir
• Sulaiman (west): Takht-e-Sulaiman
• Kirthar (south-west, Sindh–Balochistan border)
• Salt Range and Margalla Hills (north Punjab and Islamabad)

Passes to mark: Khunjerab, Khyber, Bolan, Lowari, Babusar.

Tip: the mountains form an arc across the north and west of Pakistan, and the Indus plain lies to the south-east of them.
""",
"""
پہاڑوں کا نقشہ شمال اور مغرب کے عظیم سلسلے دکھاتا ہے۔

نشان زد کرنے کے سلسلے:
• قراقرم (شمال مشرق): کے ٹو، براڈ پیک، گیشربرم، راکاپوشی
• ہمالیہ (شمال مشرق): نانگا پربت
• ہندوکش (شمال مغرب): ترچ میر
• سلیمان (مغرب): تختِ سلیمان
• کیرتھر (جنوب مغرب، سندھ بلوچستان سرحد)
• سالٹ رینج اور مارگلہ ہلز (شمالی پنجاب اور اسلام آباد)

نشان زد کرنے کے درے: خنجراب، خیبر، بولان، لواری، بابوسر۔

اشارہ: پہاڑ پاکستان کے شمال اور مغرب میں ایک کمان بناتے ہیں، اور سندھ کا میدان ان کے جنوب مشرق میں ہے۔
"""),

    c("15.4",
"""
The deserts map shows the dry regions of Pakistan.

Deserts to mark:
• Thar and Nara (south-east Sindh): Tharparkar and Umerkot
• Cholistan (south Punjab): near Bahawalpur
• Thal (Punjab): between the Jhelum and Indus rivers
• Kharan (west Balochistan)
• Chagai area (north-west Balochistan)

Also mark: Derawar Fort (Cholistan), Mithi (Thar) and Thar Coal (Islamkot).

Tip: Pakistan's deserts lie mainly in the south-east and west, where rainfall is low.
""",
"""
صحراؤں کا نقشہ پاکستان کے خشک علاقے دکھاتا ہے۔

نشان زد کرنے کے صحرا:
• تھر اور نارا (جنوب مشرقی سندھ): تھرپارکر اور عمرکوٹ
• چولستان (جنوبی پنجاب): بہاولپور کے قریب
• تھل (پنجاب): دریائے جہلم اور سندھ کے درمیان
• خاران (مغربی بلوچستان)
• چاغی کا علاقہ (شمال مغربی بلوچستان)

یہ بھی نشان زد کریں: قلعہ ڈیراور (چولستان)، مٹھی (تھر) اور تھر کول (اسلام کوٹ)۔

اشارہ: پاکستان کے صحرا زیادہ تر جنوب مشرق اور مغرب میں ہیں، جہاں بارش کم ہوتی ہے۔
"""),

    c("15.5",
"""
The dams map shows where water is stored.

Dams to mark:
• Tarbela (Indus, KP)
• Mangla (Jhelum, Azad Kashmir)
• Warsak (Kabul River, near Peshawar)
• Chashma (Indus barrage and reservoir, Punjab)
• Hub Dam (Balochistan, near Karachi)
• Khanpur, Rawal and Simly (near Islamabad and Rawalpindi)
• Gomal Zam (South Waziristan)

Under construction: Diamer-Bhasha, Mohmand and Dasu.

Barrages to add: Sukkur, Guddu, Kotri, Taunsa and Marala.

Tip: use one symbol for dams and a different one for barrages, and label each with its river.
""",
"""
ڈیموں کا نقشہ دکھاتا ہے کہ پانی کہاں ذخیرہ ہوتا ہے۔

نشان زد کرنے کے ڈیم:
• تربیلا (سندھ، خیبر پختونخوا)
• منگلا (جہلم، آزاد کشمیر)
• وارسک (دریائے کابل، پشاور کے قریب)
• چشمہ (دریائے سندھ پر بیراج اور آبی ذخیرہ، پنجاب)
• حب ڈیم (بلوچستان، کراچی کے قریب)
• خانپور، راول اور سملی (اسلام آباد اور راولپنڈی کے قریب)
• گومل زام (جنوبی وزیرستان)

زیر تعمیر: دیامر بھاشا، مہمند اور داسو۔

شامل کرنے کے بیراج: سکھر، گدو، کوٹری، تونسہ اور مرالہ۔

اشارہ: ڈیموں کے لیے ایک علامت اور بیراجوں کے لیے دوسری علامت استعمال کریں، اور ہر ایک پر اس کے دریا کا نام لکھیں۔
"""),

    c("15.6",
"""
The provinces map shows the main administrative divisions.

Approximate shares of the country's area:
• Balochistan: about 44% (west and south-west)
• Punjab: about 26% (centre and east)
• Sindh: about 18% (south-east)
• Khyber Pakhtunkhwa: about 13% (north-west)
• Gilgit-Baltistan, Azad Kashmir and Islamabad: the remainder of the area

Capitals: Quetta, Lahore, Karachi and Peshawar, with Islamabad as the federal capital.

Tip: Punjab is the "heart" of the country, Sindh follows the lower Indus, and Balochistan is the large dry region in the west.
""",
"""
صوبوں کا نقشہ اہم انتظامی تقسیم دکھاتا ہے۔

ملک کے رقبے میں تقریبی حصے:
• بلوچستان: تقریباً 44 فیصد (مغرب اور جنوب مغرب)
• پنجاب: تقریباً 26 فیصد (وسط اور مشرق)
• سندھ: تقریباً 18 فیصد (جنوب مشرق)
• خیبر پختونخوا: تقریباً 13 فیصد (شمال مغرب)
• گلگت بلتستان، آزاد کشمیر اور اسلام آباد: رقبے کا باقی حصہ

دارالحکومت: کوئٹہ، لاہور، کراچی اور پشاور، اور وفاقی دارالحکومت اسلام آباد۔

اشارہ: پنجاب ملک کا "دل" ہے، سندھ زیریں دریائے سندھ کے ساتھ ہے، اور بلوچستان مغرب کا بڑا خشک علاقہ ہے۔
"""),

    c("15.7",
"""
The major cities map shows where people and economic activity are concentrated.

Cities to mark:
• South: Karachi, Hyderabad, Sukkur, Gwadar
• Punjab: Lahore, Faisalabad, Multan, Gujranwala, Rawalpindi, Bahawalpur
• Federal capital: Islamabad
• North-west: Peshawar, Mardan
• West: Quetta
• North: Gilgit, Skardu, Muzaffarabad (Azad Kashmir)

Main routes: the N-5 (Grand Trunk Road) from Karachi to Torkham via Lahore, and the M-2 motorway between Lahore and Islamabad.

Tip: most cities lie along the Indus and its tributaries and on the main road and rail routes.
""",
"""
اہم شہروں کا نقشہ دکھاتا ہے کہ لوگ اور معاشی سرگرمیاں کہاں مرتکز ہیں۔

نشان زد کرنے کے شہر:
• جنوب: کراچی، حیدرآباد، سکھر، گوادر
• پنجاب: لاہور، فیصل آباد، ملتان، گوجرانوالہ، راولپنڈی، بہاولپور
• وفاقی دارالحکومت: اسلام آباد
• شمال مغرب: پشاور، مردان
• مغرب: کوئٹہ
• شمال: گلگت، اسکردو، مظفرآباد (آزاد کشمیر)

اہم راستے: این 5 (جی ٹی روڈ) جو کراچی سے لاہور ہوتی ہوئی طورخم تک جاتی ہے، اور لاہور اور اسلام آباد کے درمیان ایم 2 موٹروے۔

اشارہ: زیادہ تر شہر دریائے سندھ اور اس کی شاخوں کے ساتھ اور اہم سڑکوں اور ریل کے راستوں پر ہیں۔
"""),

    c("15.8",
"""
The borders map shows Pakistan's land and sea boundaries.

• Afghanistan (about 2,430 km): the Durand Line
• India (about 2,912 km): the Radcliffe Line, the Line of Control and the Working Boundary
• Iran (about 909 km)
• China (about 585 km): set by the 1963 boundary agreement
• Arabian Sea coast (about 1,046 km)

Also mark:
• The Wakhan Corridor, a narrow strip of Afghanistan that separates Pakistan from Tajikistan
• The Sir Creek area between Sindh and Gujarat, where the boundary is under discussion
• Kashmir is a disputed region, and maps may show its boundaries differently.

Tip: Pakistan's longest land border is with India, then Afghanistan.
""",
"""
سرحدوں کا نقشہ پاکستان کی زمینی اور سمندری سرحدیں دکھاتا ہے۔

• افغانستان (تقریباً 2,430 کلومیٹر): ڈیورنڈ لائن
• بھارت (تقریباً 2,912 کلومیٹر): ریڈکلف لائن، لائن آف کنٹرول اور ورکنگ باؤنڈری
• ایران (تقریباً 909 کلومیٹر)
• چین (تقریباً 585 کلومیٹر): 1963 کے سرحدی معاہدے سے طے
• بحیرہ عرب کا ساحل (تقریباً 1,046 کلومیٹر)

یہ بھی نشان زد کریں:
• واخان پٹی، افغانستان کی ایک تنگ پٹی جو پاکستان کو تاجکستان سے الگ کرتی ہے
• سندھ اور گجرات کے درمیان سر کریک کا علاقہ، جہاں سرحد پر بات چیت جاری ہے
• کشمیر ایک متنازع علاقہ ہے، اور نقشے اس کی حدود مختلف طریقے سے دکھا سکتے ہیں۔

اشارہ: پاکستان کی سب سے لمبی زمینی سرحد بھارت کے ساتھ ہے، پھر افغانستان کے ساتھ۔
"""),

    c("15.9",
"""
The natural resources map shows where Pakistan's resources are found.

Minerals and energy:
• Coal: Thar, Lakhra and Quetta
• Natural gas: Sui, Mari and Kandhkot
• Oil: Potohar and Badin
• Salt: Khewra and the Salt Range
• Copper and gold: Saindak and Reko Diq (Chagai)
• Chromite: Muslim Bagh and Khuzdar
• Marble: Buner and Mohmand
• Gemstones: Swat and Skardu
• Limestone: Salt Range, Kohat and Lasbela

Other resources:
• Water and hydropower: Tarbela, Mangla and the Indus
• Farmland: wheat and cotton in Punjab and Sindh
• Forests: northern mountains; mangroves on the coast
• Fish: the Arabian Sea

Tip: use a different symbol or colour for each type of resource, and explain them in the legend.
""",
"""
قدرتی وسائل کا نقشہ دکھاتا ہے کہ پاکستان کے وسائل کہاں ہیں۔

معدنیات اور توانائی:
• کوئلہ: تھر، لاکھڑا اور کوئٹہ
• قدرتی گیس: سوئی، ماری اور کندھکوٹ
• تیل: پوٹھوہار اور بدین
• نمک: کھیوڑہ اور سالٹ رینج
• تانبا اور سونا: سینڈک اور ریکوڈک (چاغی)
• کرومائٹ: مسلم باغ اور خضدار
• سنگ مرمر: بونیر اور مہمند
• قیمتی پتھر: سوات اور اسکردو
• چونا پتھر: سالٹ رینج، کوہاٹ اور لسبیلہ

دیگر وسائل:
• پانی اور پن بجلی: تربیلا، منگلا اور دریائے سندھ
• زرعی زمین: پنجاب اور سندھ میں گندم اور کپاس
• جنگلات: شمالی پہاڑ؛ ساحل پر مینگرو
• مچھلی: بحیرہ عرب

اشارہ: ہر قسم کے وسیلے کے لیے الگ علامت یا رنگ استعمال کریں، اور علامات کی فہرست میں اس کی وضاحت کریں۔
""")
)

package com.pakgeo.app

// Topic 6: Plains, plateaus and deserts, Topic 7: Lakes and natural sites
val contentPart4: Map<String, Pair<String, String>> = mapOf(
    // ================= TOPIC 6 =================
    c("6.0",
"""
The Indus Plain is the largest and most important plain of Pakistan. It was formed over thousands of years by the silt (alluvium) carried by the Indus and its tributaries.

• Length: about 1,600 km, from the northern foothills to the Arabian Sea
• Soil: deep, fertile alluvium
• Most of Pakistan's people and farmland are found here.
• It is divided into the Upper Indus Plain (Punjab) and the Lower Indus Plain (Sindh).
• Canals from the river system irrigate it.
• Main crops: wheat, rice, cotton and sugarcane
• Its flat land makes roads, railways and cities easy to build.
""",
"""
وادیٔ سندھ کا میدان پاکستان کا سب سے بڑا اور اہم میدان ہے۔ یہ ہزاروں سال میں دریائے سندھ اور اس کی شاخوں کی لائی ہوئی گاد (مٹی) سے بنا۔

• لمبائی: تقریباً 1,600 کلومیٹر، شمالی دامن سے بحیرہ عرب تک
• مٹی: گہری، زرخیز گاد والی
• پاکستان کی زیادہ تر آبادی اور زرعی زمین یہیں ہے۔
• یہ بالائی سندھ کے میدان (پنجاب) اور زیریں سندھ کے میدان (سندھ) میں تقسیم ہے۔
• دریائی نظام کی نہریں اسے سیراب کرتی ہیں۔
• اہم فصلیں: گندم، چاول، کپاس اور گنا
• ہموار زمین کی وجہ سے سڑکیں، ریل اور شہر بنانا آسان ہے۔
"""),

    c("6.1",
"""
The Upper Indus Plain lies in Punjab, from the northern foothills down to about Mithankot, where the Panjnad joins the Indus.

• It is crossed by the Indus, Jhelum, Chenab, Ravi and Sutlej.
• The land between two rivers is called a "doab" (for example Sindh Sagar, Chaj, Rechna and Bari Doabs).
• It is the best-irrigated and most densely populated part of Pakistan.
• Crops: wheat, rice (including basmati), cotton, sugarcane, maize, mangoes and citrus fruit
• Cities: Lahore, Faisalabad, Multan, Gujranwala, Sargodha
• Climate: very hot summers and cool winters, with moderate rain
""",
"""
بالائی سندھ کا میدان پنجاب میں ہے، شمالی دامن سے تقریباً مٹھن کوٹ تک، جہاں پنجند دریائے سندھ سے ملتا ہے۔

• اس میں سے سندھ، جہلم، چناب، راوی اور ستلج گزرتے ہیں۔
• دو دریاؤں کے درمیان کی زمین "دوآب" کہلاتی ہے (مثلاً سندھ ساگر، چج، رچنا اور باری دوآب)۔
• یہ پاکستان کا سب سے اچھا سیراب ہونے والا اور سب سے گنجان آباد حصہ ہے۔
• فصلیں: گندم، چاول (باسمتی سمیت)، کپاس، گنا، مکئی، آم اور مالٹے
• شہر: لاہور، فیصل آباد، ملتان، گوجرانوالہ، سرگودھا
• آب و ہوا: بہت گرم گرمیاں اور ٹھنڈی سردیاں، معتدل بارش
"""),

    c("6.2",
"""
The Lower Indus Plain lies in Sindh, from Mithankot to the Arabian Sea.

• It is very flat, so the Indus flows slowly and often changes its course.
• Floods have built a wide floodplain, and the river ends in the Indus Delta.
• Rainfall is very low (often under 200 mm), so farming depends on irrigation from the Guddu, Sukkur and Kotri barrages.
• Crops: rice, cotton, sugarcane, wheat, bananas, mangoes and dates (Khairpur)
• Cities: Sukkur, Larkana, Hyderabad; Karachi lies just beyond the plain on the coast.
• Problems: waterlogging, salinity and flooding
""",
"""
زیریں سندھ کا میدان سندھ میں ہے، مٹھن کوٹ سے بحیرہ عرب تک۔

• یہ بہت ہموار ہے، اس لیے دریائے سندھ آہستہ بہتا ہے اور اکثر اپنا راستہ بدلتا ہے۔
• سیلابوں نے ایک وسیع سیلابی میدان بنایا ہے، اور دریا ڈیلٹا پر ختم ہوتا ہے۔
• بارش بہت کم ہوتی ہے (اکثر 200 ملی میٹر سے کم)، اس لیے زراعت گدو، سکھر اور کوٹری بیراج کی آبپاشی پر منحصر ہے۔
• فصلیں: چاول، کپاس، گنا، گندم، کیلا، آم اور کھجور (خیرپور)
• شہر: سکھر، لاڑکانہ، حیدرآباد؛ کراچی میدان کے بالکل پار ساحل پر ہے۔
• مسائل: زمین میں پانی جمع ہونا، کھاری پن اور سیلاب
"""),

    c("6.3",
"""
The Potohar Plateau lies in northern Punjab and around Islamabad, between the Indus River in the west and the Jhelum River in the east.

• Height: about 300–600 m above sea level
• Boundaries: the Salt Range in the south and the Margalla and Murree hills in the north
• Rivers: Soan, Haro and Korang, which have cut deep gullies (ravines)
• Farming depends on rain ("barani" land): wheat, groundnut, millet and gram.
• Minerals: oil, coal, limestone and salt
• Cities: Rawalpindi, Islamabad, Jhelum, Chakwal, Attock
• Taxila, an ancient city, lies on the plateau.
""",
"""
سطح مرتفع پوٹھوہار شمالی پنجاب اور اسلام آباد کے گرد، مغرب میں دریائے سندھ اور مشرق میں دریائے جہلم کے درمیان واقع ہے۔

• بلندی: سطح سمندر سے تقریباً 300 سے 600 میٹر
• حدود: جنوب میں سالٹ رینج اور شمال میں مارگلہ اور مری کی پہاڑیاں
• دریا: سواں، ہرو اور کورنگ، جنہوں نے گہرے نالے (کھائیاں) کاٹ دی ہیں
• زراعت بارش پر منحصر ہے ("بارانی" زمین): گندم، مونگ پھلی، باجرہ اور چنا
• معدنیات: تیل، کوئلہ، چونا پتھر اور نمک
• شہر: راولپنڈی، اسلام آباد، جہلم، چکوال، اٹک
• قدیم شہر ٹیکسلا اسی سطح مرتفع پر ہے۔
"""),

    c("6.4",
"""
The Balochistan Plateau covers most of Balochistan and is a high, dry and rugged region.

• Height: mostly about 600–1,500 m; Quetta is about 1,680 m.
• It is crossed by hill ranges such as the Chagai Hills, Toba Kakar and the Makran ranges.
• Basins and plains: Quetta, Zhob, Kachhi and Kharan
• Rivers are few and mostly seasonal; people also use "karez", underground water channels.
• Rainfall is low and uneven.
• Highland orchards grow apples, grapes, pomegranates and almonds.
• Livestock, especially sheep and goats, is important.
• Resources: natural gas, coal, chromite, copper and gold
""",
"""
بلوچستان کا سطح مرتفع زیادہ تر بلوچستان پر پھیلا ہوا ہے اور ایک بلند، خشک اور دشوار گزار خطہ ہے۔

• بلندی: زیادہ تر تقریباً 600 سے 1,500 میٹر؛ کوئٹہ تقریباً 1,680 میٹر بلند ہے۔
• اس میں چاغی ہلز، توبہ کاکڑ اور مکران کے سلسلوں جیسے پہاڑی سلسلے ہیں۔
• طاس اور میدان: کوئٹہ، ژوب، کچھی اور خاران
• دریا کم ہیں اور زیادہ تر موسمی؛ لوگ "کاریز" یعنی زیر زمین پانی کی نالیاں بھی استعمال کرتے ہیں۔
• بارش کم اور غیر یقینی ہوتی ہے۔
• بلند علاقوں کے باغات میں سیب، انگور، انار اور بادام اگتے ہیں۔
• مویشی، خاص طور پر بھیڑ بکریاں، اہم ہیں۔
• وسائل: قدرتی گیس، کوئلہ، کرومائٹ، تانبا اور سونا
"""),

    c("6.5",
"""
The Deosai Plateau is one of the highest plateaus in the world. It lies in Gilgit-Baltistan, between Skardu and Astore.

• Average height: about 4,100 m
• Name: "Deosai" means "Land of Giants" in local tradition.
• Deosai National Park (created in 1993) covers about 3,000 km².
• It protects the Himalayan brown bear, and also marmots, ibex and many birds.
• Sheosar Lake lies at about 4,140 m.
• Snow covers it for around eight months; the road is open mainly from June to September.
• In July and August the plateau is covered with wildflowers.
""",
"""
سطح مرتفع دیوسائی دنیا کے بلند ترین سطح مرتفع علاقوں میں سے ہے۔ یہ گلگت بلتستان میں اسکردو اور استور کے درمیان واقع ہے۔

• اوسط بلندی: تقریباً 4,100 میٹر
• نام: مقامی روایت میں "دیوسائی" کا مطلب "دیوؤں کی سرزمین" ہے۔
• دیوسائی نیشنل پارک (1993 میں بنا) تقریباً 3,000 مربع کلومیٹر پر پھیلا ہے۔
• یہ ہمالیائی بھورے ریچھ، نیز مارموٹ، آئبیکس اور بہت سے پرندوں کی حفاظت کرتا ہے۔
• شیوسر جھیل تقریباً 4,140 میٹر کی بلندی پر ہے۔
• برف تقریباً آٹھ ماہ تک اسے ڈھانپے رکھتی ہے؛ سڑک زیادہ تر جون سے ستمبر تک کھلی رہتی ہے۔
• جولائی اور اگست میں سطح مرتفع جنگلی پھولوں سے بھر جاتا ہے۔
"""),

    c("6.6",
"""
The Thar Desert lies in south-eastern Sindh (Tharparkar and Umerkot districts) and continues into India's Rajasthan.

• Area in Pakistan: about 20,000 km²
• Rainfall: roughly 100–250 mm, mostly in the monsoon, and uncertain
• Landscape: sand dunes, scrub and low hills; the Karoonjhar hills are at Nagarparkar.
• It is one of the most thickly populated deserts in the world.
• People keep goats, sheep, camels and cattle, and grow millet and guar after rain.
• Thar Coal, at Islamkot, is one of Pakistan's largest coal reserves.
• Mithi is the main town of Tharparkar.
• Drought can be a serious problem here.
""",
"""
صحرائے تھر جنوب مشرقی سندھ (تھرپارکر اور عمرکوٹ کے اضلاع) میں ہے اور بھارت کے راجستھان تک جاتا ہے۔

• پاکستان میں رقبہ: تقریباً 20,000 مربع کلومیٹر
• بارش: تقریباً 100 سے 250 ملی میٹر، زیادہ تر مون سون میں، اور غیر یقینی
• منظر: ریت کے ٹیلے، جھاڑیاں اور نیچی پہاڑیاں؛ ننگرپارکر میں کارونجھر کی پہاڑیاں ہیں۔
• یہ دنیا کے سب سے گنجان آباد صحراؤں میں سے ایک ہے۔
• لوگ بکریاں، بھیڑیں، اونٹ اور مویشی پالتے ہیں اور بارش کے بعد باجرہ اور گوار اگاتے ہیں۔
• اسلام کوٹ کا تھر کوئلہ پاکستان کے بڑے کوئلے کے ذخائر میں سے ایک ہے۔
• مٹھی تھرپارکر کا مرکزی شہر ہے۔
• یہاں خشک سالی ایک سنگین مسئلہ ہو سکتی ہے۔
"""),

    c("6.7",
"""
The Cholistan Desert lies in southern Punjab, in the Bahawalpur region, next to the Indian border.

• Area: about 26,000 km²
• Local name: "Rohi"
• It lies along the dry bed of the ancient Hakra (Ghaggar) river.
• Rainfall: less than about 180 mm a year
• Water is stored in natural ponds called "tobas".
• Derawar Fort, near Ahmadpur East, stands in the desert.
• Lal Suhanra National Park is nearby.
• People raise camels, cattle and goats; the Cholistani cattle breed is famous.
• Canals from the Sutlej have turned parts of the desert into farmland.
""",
"""
صحرائے چولستان جنوبی پنجاب میں، بہاولپور کے علاقے میں، بھارتی سرحد کے ساتھ واقع ہے۔

• رقبہ: تقریباً 26,000 مربع کلومیٹر
• مقامی نام: "روہی"
• یہ قدیم دریائے ہاکڑہ (گھگر) کے خشک پاٹ کے ساتھ ہے۔
• بارش: سالانہ تقریباً 180 ملی میٹر سے کم
• پانی "ٹوبے" کہلانے والے قدرتی تالابوں میں جمع کیا جاتا ہے۔
• احمد پور شرقیہ کے قریب قلعہ ڈیراور صحرا میں کھڑا ہے۔
• لال سوہانرا نیشنل پارک قریب ہی ہے۔
• لوگ اونٹ، مویشی اور بکریاں پالتے ہیں؛ چولستانی نسل کے مویشی مشہور ہیں۔
• ستلج کی نہروں نے صحرا کے کچھ حصوں کو زرعی زمین بنا دیا ہے۔
"""),

    c("6.8",
"""
The Thal Desert lies in Punjab, in the Sindh Sagar Doab between the Jhelum and Indus rivers.

• Districts: Bhakkar, Layyah, Khushab, Mianwali, Jhang and Muzaffargarh
• Landscape: sandy plains with low dunes
• Rainfall is low, but the Thal Canal has made much of the area green.
• Chickpea (gram) is its most famous crop, along with groundnut and wheat.
• Bhakkar is well known for gram and mangoes.
• Camels and cattle are raised here.
""",
"""
صحرائے تھل پنجاب میں، دریائے جہلم اور سندھ کے درمیان سندھ ساگر دوآب میں واقع ہے۔

• اضلاع: بھکر، لیہ، خوشاب، میانوالی، جھنگ اور مظفرگڑھ
• منظر: ریتیلے میدان جن میں نیچے ٹیلے ہیں
• بارش کم ہے، لیکن تھل کینال نے علاقے کے بڑے حصے کو سرسبز بنا دیا ہے۔
• چنا اس کی سب سے مشہور فصل ہے، ساتھ مونگ پھلی اور گندم۔
• بھکر چنے اور آموں کے لیے مشہور ہے۔
• یہاں اونٹ اور مویشی پالے جاتے ہیں۔
"""),

    c("6.9",
"""
The Kharan Desert lies in the west of Balochistan, in Kharan district, surrounded by hills.

• Landscape: a wide basin of red sand dunes and barren land, with salt flats in places
• Climate: extremely hot summers (up to about 50°C), cold winters and very little rain (often under 100 mm)
• The Chagai Hills lie to the north, and the Ras Koh hills to the north-east.
• Pakistan's 1998 nuclear tests took place in the Ras Koh hills (Chagai) and in the Kharan desert.
• Towns: Kharan, Noshki and Dalbandin nearby
• People are mostly herders of camels, goats and sheep.
• Water comes from wells, karez and seasonal streams.
""",
"""
صحرائے خاران بلوچستان کے مغرب میں، ضلع خاران میں، پہاڑیوں سے گھرا ہوا ہے۔

• منظر: سرخ ریت کے ٹیلوں اور بنجر زمین کا وسیع طاس، کئی جگہ نمکین میدانوں کے ساتھ
• آب و ہوا: انتہائی گرم گرمیاں (تقریباً 50 ڈگری تک)، سرد سردیاں اور بہت کم بارش (اکثر 100 ملی میٹر سے کم)
• شمال میں چاغی ہلز اور شمال مشرق میں راس کوہ کی پہاڑیاں ہیں۔
• پاکستان کے 1998 کے ایٹمی تجربے راس کوہ کی پہاڑیوں (چاغی) اور صحرائے خاران میں ہوئے۔
• شہر: خاران، اور قریب نوشکی اور دالبندین
• لوگ زیادہ تر اونٹ، بکریاں اور بھیڑیں پالنے والے ہیں۔
• پانی کنوؤں، کاریز اور موسمی نالوں سے ملتا ہے۔
"""),

    // ================= TOPIC 7 =================
    c("7.0",
"""
Lake Saif-ul-Malook is one of the most famous mountain lakes of Pakistan. It lies in the Kaghan Valley, near Naran, in Khyber Pakhtunkhwa.

• Height: about 3,224 m above sea level
• Distance: about 10 km from Naran, reached by jeep
• It is fed by melting snow and glaciers.
• The snowy peak Malika Parbat (about 5,290 m) is reflected in its water.
• A folk tale tells of Prince Saif-ul-Malook and a fairy, Badri Jamala.
• Best season: roughly June to September; in winter it is covered by snow and ice.
""",
"""
جھیل سیف الملوک پاکستان کی مشہور ترین پہاڑی جھیلوں میں سے ایک ہے۔ یہ خیبر پختونخوا میں ناران کے قریب وادی کاغان میں واقع ہے۔

• بلندی: سطح سمندر سے تقریباً 3,224 میٹر
• فاصلہ: ناران سے تقریباً 10 کلومیٹر، جیپ کے ذریعے پہنچا جاتا ہے
• اسے پگھلتی برف اور گلیشیئر پانی دیتے ہیں۔
• برفیلی چوٹی ملکہ پربت (تقریباً 5,290 میٹر) کا عکس اس کے پانی میں نظر آتا ہے۔
• ایک لوک کہانی میں شہزادہ سیف الملوک اور پری بدری جمالہ کا ذکر ہے۔
• بہترین موسم: تقریباً جون سے ستمبر؛ سردیوں میں یہ برف سے ڈھک جاتی ہے۔
"""),

    c("7.1",
"""
Attabad Lake lies in the Gojal valley of Hunza, Gilgit-Baltistan.

• How it formed: on 4 January 2010 a huge landslide at Attabad village blocked the Hunza River.
• The landslide killed about 20 people and the rising water flooded villages and cut the Karakoram Highway.
• Length: about 21 km; very deep in places
• Its turquoise-blue water has made it a popular tourist spot with boating.
• New tunnels were later built so that the Karakoram Highway could pass the lake.
""",
"""
عطا آباد جھیل گلگت بلتستان میں ہنزہ کی وادی گوجال میں واقع ہے۔

• بننے کا طریقہ: 4 جنوری 2010 کو عطا آباد گاؤں میں ایک بڑی لینڈ سلائیڈنگ نے دریائے ہنزہ کا راستہ بند کر دیا۔
• اس حادثے میں تقریباً 20 افراد جاں بحق ہوئے اور بڑھتے پانی نے گاؤں ڈبو دیے اور قراقرم ہائی وے منقطع کر دی۔
• لمبائی: تقریباً 21 کلومیٹر؛ کئی جگہ بہت گہری
• اس کا فیروزی نیلا پانی اسے کشتی رانی کے ساتھ ایک مقبول سیاحتی مقام بناتا ہے۔
• بعد میں نئی سرنگیں بنائی گئیں تاکہ قراقرم ہائی وے جھیل کے پاس سے گزر سکے۔
"""),

    c("7.2",
"""
Manchar Lake lies in Sindh, in Jamshoro district near Sehwan, west of the Indus. It is considered the largest freshwater lake of Pakistan and one of the largest in Asia.

• Size: it changes with the seasons, from roughly 350 km² to over 500 km² in flood.
• It is fed by the Indus floods and by drains and streams.
• The Mohana community has traditionally lived on boats on the lake and fished.
• Fish, birds and wildlife depend on it; migratory birds visit in winter.
• Pollution from salty farm and industrial drainage has harmed its water and fish.
""",
"""
جھیل منچھر سندھ میں، ضلع جامشورو میں سہون کے قریب، دریائے سندھ کے مغرب میں واقع ہے۔ اسے پاکستان کی سب سے بڑی میٹھے پانی کی جھیل اور ایشیا کی بڑی جھیلوں میں سے ایک سمجھا جاتا ہے۔

• حجم: موسموں کے ساتھ بدلتا ہے، تقریباً 350 مربع کلومیٹر سے سیلاب میں 500 مربع کلومیٹر سے زیادہ تک
• اسے دریائے سندھ کا سیلاب اور نالے اور برساتی ندیاں پانی دیتی ہیں۔
• موہانہ برادری روایتی طور پر جھیل میں کشتیوں پر رہتی اور مچھلی پکڑتی آئی ہے۔
• مچھلی، پرندے اور جنگلی حیات اس پر منحصر ہیں؛ سردیوں میں مہاجر پرندے آتے ہیں۔
• کھاری زرعی اور صنعتی نکاسی کی آلودگی نے اس کے پانی اور مچھلی کو نقصان پہنچایا ہے۔
"""),

    c("7.3",
"""
Keenjhar Lake (also called Kalri Lake) is in Thatta district, Sindh. It is one of the largest freshwater lakes of Pakistan.

• It is a main source of drinking water for Karachi and Thatta.
• It is fed by the Kalri Baghar Feeder canal from the Indus.
• Distance: about 120 km from Karachi, so it is a popular picnic spot.
• The tomb of Noori Jam Tamachi stands in the lake; their love story is a famous Sindhi legend.
• It is a Ramsar wetland and a winter home for migratory birds.
""",
"""
کینجھر جھیل (جسے کلری جھیل بھی کہتے ہیں) سندھ کے ضلع ٹھٹھہ میں ہے۔ یہ پاکستان کی بڑی میٹھے پانی کی جھیلوں میں سے ہے۔

• یہ کراچی اور ٹھٹھہ کے پینے کے پانی کا ایک بڑا ذریعہ ہے۔
• اسے دریائے سندھ سے آنے والی کلری بگھار فیڈر نہر پانی دیتی ہے۔
• فاصلہ: کراچی سے تقریباً 120 کلومیٹر، اس لیے یہ سیر کا مقبول مقام ہے۔
• نوری جام تماچی کا مقبرہ جھیل میں ہے؛ ان کی محبت کی کہانی ایک مشہور سندھی داستان ہے۔
• یہ رامسر آبی علاقہ ہے اور مہاجر پرندوں کا سرمائی مسکن ہے۔
"""),

    c("7.4",
"""
Hanna Lake is a scenic lake about 10 km from Quetta, Balochistan.

• Built: in 1894, during British rule, as a reservoir
• Height: about 2,000 m above sea level
• Water: fed by rain and snowmelt from the nearby hills
• Next to it lies the Urak Valley, famous for fruit orchards.
• It is a popular picnic spot for the people of Quetta.
• In dry years its water level falls sharply.
""",
"""
ہنہ جھیل کوئٹہ، بلوچستان سے تقریباً 10 کلومیٹر دور ایک خوبصورت جھیل ہے۔

• تعمیر: 1894 میں، برطانوی دور میں، ایک آبی ذخیرے کے طور پر
• بلندی: سطح سمندر سے تقریباً 2,000 میٹر
• پانی: قریبی پہاڑوں کی بارش اور پگھلتی برف سے بھرتی ہے
• اس کے ساتھ وادیٔ اوڑک ہے جو پھلوں کے باغات کے لیے مشہور ہے۔
• یہ کوئٹہ کے لوگوں کی سیر کا مقبول مقام ہے۔
• خشک سالوں میں اس کے پانی کی سطح بہت گر جاتی ہے۔
"""),

    c("7.5",
"""
Rawal Lake is an artificial lake in Islamabad, at the foot of the Margalla Hills.

• River: it stores water of the Korang River behind Rawal Dam.
• Built: 1962
• Area: about 8.8 km²
• Supplies water to Rawalpindi and parts of Islamabad
• Lake View Park and boating make it a favourite recreation spot.
• It is also a home for water birds.
""",
"""
راول جھیل اسلام آباد میں مارگلہ کی پہاڑیوں کے دامن میں ایک مصنوعی جھیل ہے۔

• دریا: یہ راول ڈیم کے پیچھے دریائے کورنگ کا پانی ذخیرہ کرتی ہے۔
• تعمیر: 1962
• رقبہ: تقریباً 8.8 مربع کلومیٹر
• راولپنڈی اور اسلام آباد کے کچھ حصوں کو پانی فراہم کرتی ہے
• لیک ویو پارک اور کشتی رانی اسے تفریح کا پسندیدہ مقام بناتے ہیں۔
• یہ آبی پرندوں کا مسکن بھی ہے۔
"""),

    c("7.6",
"""
Sadpara (Satpara) Lake lies near Skardu in Gilgit-Baltistan.

• Height: about 2,636 m above sea level
• Water: fed by the Satpara stream, which flows down from the Deosai Plateau
• Satpara Dam, built at the lake, supplies drinking water to Skardu and produces a small amount of electricity.
• It is surrounded by barren mountains and is a famous viewpoint.
• Its water is clear blue.
""",
"""
سدپارہ جھیل گلگت بلتستان میں اسکردو کے قریب واقع ہے۔

• بلندی: سطح سمندر سے تقریباً 2,636 میٹر
• پانی: دیوسائی کے سطح مرتفع سے آنے والی ندی ست پارہ اسے بھرتی ہے
• جھیل پر بنا ست پارہ ڈیم اسکردو کو پینے کا پانی دیتا ہے اور تھوڑی بجلی بھی بناتا ہے۔
• یہ بنجر پہاڑوں سے گھری ہے اور ایک مشہور نظارہ گاہ ہے۔
• اس کا پانی صاف نیلا ہے۔
"""),

    c("7.7",
"""
Shangrila Resort, also known as Lower Kachura Lake, is a beautiful spot near Skardu in Gilgit-Baltistan.

• Height: about 2,500 m above sea level
• The resort was built around the lake in the 1980s.
• It is famous for its red-roofed buildings and an unusual restaurant built like an aeroplane.
• Upper Kachura Lake lies a short distance away.
• The name comes from "Shangri-La", an imagined paradise on Earth.
• Best season: spring to autumn.
""",
"""
شنگریلا ریزورٹ، جسے لوئر کاچورا جھیل بھی کہتے ہیں، گلگت بلتستان میں اسکردو کے قریب ایک خوبصورت مقام ہے۔

• بلندی: سطح سمندر سے تقریباً 2,500 میٹر
• ریزورٹ 1980 کی دہائی میں جھیل کے گرد بنایا گیا۔
• یہ سرخ چھتوں والی عمارتوں اور ہوائی جہاز کی شکل کے ایک انوکھے ریستوران کے لیے مشہور ہے۔
• اپر کاچورا جھیل تھوڑے فاصلے پر ہے۔
• نام "شنگریلا" سے آیا ہے، جو زمین پر ایک خیالی جنت ہے۔
• بہترین موسم: بہار سے خزاں تک۔
"""),

    c("7.8",
"""
Kaghan Valley lies in Mansehra district, Khyber Pakhtunkhwa. Naran is its main tourist town.

• Length: about 155 km, along the Kunhar River
• Naran: about 2,400 m above sea level
• Lakes: Saif-ul-Malook, Dudipatsar and Ansoo (Tear Drop) lake
• Other places: Balakot (the gateway), Shogran, Siri, Paye and Lalazar
• Babusar Pass (about 4,173 m) links the valley with Chilas.
• Season: roughly May to October; heavy snow closes the upper valley in winter.
• Trout fishing in the Kunhar River is popular.
""",
"""
وادیٔ کاغان خیبر پختونخوا کے ضلع مانسہرہ میں ہے۔ ناران اس کا اہم سیاحتی شہر ہے۔

• لمبائی: تقریباً 155 کلومیٹر، دریائے کنہار کے ساتھ ساتھ
• ناران: سطح سمندر سے تقریباً 2,400 میٹر
• جھیلیں: سیف الملوک، دودی پت سر اور آنسو جھیل
• دیگر مقامات: بالاکوٹ (دروازہ)، شوگران، سری، پائے اور لالازار
• درۂ بابوسر (تقریباً 4,173 میٹر) وادی کو چلاس سے ملاتا ہے۔
• موسم: تقریباً مئی سے اکتوبر؛ سردیوں میں شدید برف باری بالائی وادی بند کر دیتی ہے۔
• دریائے کنہار میں ٹراؤٹ مچھلی کا شکار مقبول ہے۔
"""),

    c("7.9",
"""
Hunza is a famous valley in Gilgit-Baltistan, along the Karakoram Highway. Its main town is Karimabad.

• Forts: Baltit Fort and Altit Fort, hundreds of years old
• Peaks: Rakaposhi, Ultar Sar, Lady Finger and the Passu Cones
• Passu Glacier and the Hussaini suspension bridge are well-known sights.
• Orchards: apricots and cherries; blossom in April and golden colours in autumn
• People speak Burushaski, Wakhi and Shina, and the literacy rate is high.
• Khunjerab National Park and the Khunjerab Pass are at its northern end.
""",
"""
ہنزہ گلگت بلتستان میں قراقرم ہائی وے کے ساتھ ایک مشہور وادی ہے۔ اس کا مرکزی شہر کریم آباد ہے۔

• قلعے: قلعہ بلتت اور قلعہ التت، سینکڑوں سال پرانے
• چوٹیاں: راکاپوشی، التر سر، لیڈی فنگر اور پاسو کونز
• پاسو گلیشیئر اور حسینی معلق پل مشہور مناظر ہیں۔
• باغات: خوبانی اور چیری؛ اپریل میں پھول اور خزاں میں سنہری رنگ
• لوگ بروشسکی، واخی اور شینا بولتے ہیں، اور شرح خواندگی بلند ہے۔
• خنجراب نیشنل پارک اور درۂ خنجراب اس کے شمالی سرے پر ہیں۔
"""),

    c("7.10",
"""
Skardu is the main town of Baltistan in Gilgit-Baltistan and the gateway to the world's great peaks.

• Height: about 2,230 m above sea level
• Location: where the Indus and Shigar rivers meet, in a wide valley
• Katpana Desert, a cold desert with sand dunes, lies near the town.
• Skardu Fort (Kharpocho) overlooks the valley.
• Lakes nearby: Sadpara, Upper and Lower Kachura (Shangrila)
• Treks to K2, Baltoro Glacier and Concordia start from here, via Askole.
• Deosai Plateau lies to the south.
""",
"""
اسکردو گلگت بلتستان میں بلتستان کا مرکزی شہر ہے اور دنیا کی عظیم چوٹیوں کا دروازہ ہے۔

• بلندی: سطح سمندر سے تقریباً 2,230 میٹر
• مقام: جہاں دریائے سندھ اور شگر ملتے ہیں، ایک وسیع وادی میں
• کٹپانہ صحرا، ریت کے ٹیلوں والا ایک سرد صحرا، شہر کے قریب ہے۔
• اسکردو فورٹ (کھرپوچو) وادی پر نظر رکھتا ہے۔
• قریبی جھیلیں: سدپارہ، اپر اور لوئر کاچورا (شنگریلا)
• کے ٹو، بالتورو گلیشیئر اور کنکورڈیا کے ٹریک یہیں سے، اسکولے کے راستے، شروع ہوتے ہیں۔
• دیوسائی کا سطح مرتفع جنوب میں ہے۔
"""),

    c("7.11",
"""
Swat is a beautiful valley in Khyber Pakhtunkhwa, often called the "Switzerland of the East".

• River: the Swat River flows through the valley.
• Towns: Mingora (the largest), Madyan, Bahrain and Kalam (about 2,000 m)
• Places: Malam Jabba (a ski resort), Mahodand Lake and Ushu Forest
• History: Swat was a centre of Gandhara Buddhist culture; ruins such as Butkara Stupa and the Jahanabad Buddha remain.
• Products: apples, peaches, walnuts and emeralds
• Season: spring and summer for green hills, winter for snow.
""",
"""
سوات خیبر پختونخوا کی ایک خوبصورت وادی ہے، جسے اکثر "مشرق کا سوئٹزرلینڈ" کہا جاتا ہے۔

• دریا: دریائے سوات وادی سے بہتا ہے۔
• شہر: مینگورہ (سب سے بڑا)، مدین، بحرین اور کالام (تقریباً 2,000 میٹر)
• مقامات: ملم جبہ (اسکیئنگ کا مقام)، مہوڈنڈ جھیل اور اوشو جنگل
• تاریخ: سوات گندھارا بدھ تہذیب کا مرکز تھا؛ بُت کڑہ اسٹوپا اور جہان آباد کا بدھا جیسے آثار باقی ہیں۔
• پیداوار: سیب، آڑو، اخروٹ اور زمرد
• موسم: ہری بھری پہاڑیوں کے لیے بہار اور گرمیاں، برف کے لیے سردیاں۔
""")
)

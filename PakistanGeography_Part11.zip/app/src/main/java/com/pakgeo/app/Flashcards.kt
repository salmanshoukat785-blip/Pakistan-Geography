@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.pakgeo.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FlashcardsScreen(prefs: Prefs, onBack: () -> Unit) {
    val lang = LocalLang.current
    var topic by remember { mutableStateOf(0) }       // 0 = all topics
    var hideKnown by remember { mutableStateOf(false) }
    var round by remember { mutableStateOf(0) }
    var idx by remember { mutableStateOf(0) }
    var flipped by remember { mutableStateOf(false) }

    val deck = remember(topic, hideKnown, round) {
        allQuestions.filter { (topic == 0 || it.topic == topic) && (!hideKnown || it.id !in prefs.knownCards) }.shuffled()
    }

    LaunchedEffect(deck) {
        idx = 0
        flipped = false
    }

    fun move(step: Int) {
        if (deck.isEmpty()) return
        idx = (idx + step + deck.size) % deck.size
        flipped = false
    }

    PageScaffold(tr("Flashcards", "فلیش کارڈز"), onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = topic == 0, onClick = { topic = 0 }, label = { Text(tr("All", "سب")) })
                topics.forEach { t ->
                    FilterChip(
                        selected = topic == t.id,
                        onClick = { topic = t.id },
                        label = { Text("${t.emoji} ${if (lang == "ur") t.ur else t.en}", fontSize = 12.sp) }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(
                    selected = hideKnown,
                    onClick = { hideKnown = !hideKnown },
                    label = { Text(tr("Hide known cards", "جانے ہوئے کارڈ چھپائیں")) }
                )
                OutlinedButton(onClick = { round += 1 }) { Text(tr("Shuffle", "پھینٹیں")) }
            }
            Text(
                tr("Known: ${prefs.knownCards.size} of ${allQuestions.size}", "جانے ہوئے: ${allQuestions.size} میں سے ${prefs.knownCards.size}"),
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )

            val card = deck.getOrNull(idx)
            if (card == null) {
                Text(
                    tr("No cards here. Turn off \"Hide known cards\" or pick another topic.", "یہاں کوئی کارڈ نہیں۔ \"جانے ہوئے کارڈ چھپائیں\" بند کریں یا دوسرا موضوع چنیں۔"),
                    fontSize = 15.sp, color = MaterialTheme.colorScheme.onBackground
                )
            } else {
                Text("${idx + 1} / ${deck.size}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                Card(
                    onClick = { flipped = !flipped },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (flipped) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(3.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            topicTitle(card.topic, lang), fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (!flipped) {
                            Text(
                                card.text(lang), fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                                lineHeight = 30.sp, textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                tr("Tap to see the answer", "جواب دیکھنے کے لیے ٹیپ کریں"),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        } else {
                            Text(
                                card.correctText(lang), fontSize = 24.sp, fontWeight = FontWeight.Bold,
                                lineHeight = 34.sp, textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (card.exp(lang).isNotEmpty()) {
                                Text(
                                    card.exp(lang), fontSize = 15.sp, lineHeight = 24.sp,
                                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { move(-1) }, modifier = Modifier.weight(1f)) { Text(tr("Previous", "پچھلا")) }
                    OutlinedButton(
                        onClick = {
                            if (card.id in prefs.knownCards) prefs.toggleKnown(card.id)
                            move(1)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(tr("Again", "دوبارہ")) }
                    Button(
                        onClick = {
                            if (card.id !in prefs.knownCards) prefs.toggleKnown(card.id)
                            move(1)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(tr("I know it", "مجھے آتا ہے")) }
                }
            }
        }
    }
}

package com.pakgeo.app

// Topic 8: Forests, Topic 9: Minerals, Topic 10: Agriculture
val contentPart5: Map<String, Pair<String, String>> = mapOf(
    // ================= TOPIC 8 =================
    c("8.0",
"""
Forests cover only a small part of Pakistan, about 5% of the land or even less, which is low for a country of its size.

Main types of forest:
• Coniferous (mountain) forests in the north
• Scrub and juniper forests, such as Ziarat in Balochistan
• Chilgoza pine forests in the Sulaiman range
• Riverine forests along the Indus and its rivers
• Irrigated plantations in Punjab and Sindh
• Mangrove forests on the coast

Most forest lies in Khyber Pakhtunkhwa, Gilgit-Baltistan and Azad Kashmir.

Efforts to increase forest cover include the Billion Tree Tsunami in Khyber Pakhtunkhwa (2014–2017) and the national Ten Billion Tree Tsunami programme (from 2018).
""",
"""
پاکستان کے رقبے کا بہت کم حصہ جنگلات پر مشتمل ہے، تقریباً 5 فیصد یا اس سے بھی کم، جو اتنے بڑے ملک کے لیے کم ہے۔

جنگلات کی بڑی اقسام:
• شمال میں مخروطی (پہاڑی) جنگلات
• جھاڑیوں اور صنوبر کے جنگلات، جیسے بلوچستان میں زیارت
• کوہ سلیمان میں چلغوزے کے جنگلات
• دریائے سندھ اور اس کے دریاؤں کے ساتھ دریائی جنگلات
• پنجاب اور سندھ میں آبپاش شجرکاری
• ساحل پر مینگرو کے جنگلات

زیادہ تر جنگلات خیبر پختونخوا، گلگت بلتستان اور آزاد کشمیر میں ہیں۔

جنگلات بڑھانے کی کوششوں میں خیبر پختونخوا میں بلین ٹری سونامی (2014 تا 2017) اور قومی ٹین بلین ٹری سونامی پروگرام (2018 سے) شامل ہیں۔
"""),

    c("8.1",
"""
Mountain forests grow in the wet, cool north and change with height.

• Lower slopes (about 900–1,800 m): chir pine
• Middle slopes (about 1,500–3,000 m): blue pine (kail), deodar, fir and spruce
• Dry inner valleys (Chitral, Gilgit): chilgoza, deodar and juniper
• Highest areas (above about 3,500 m): alpine shrubs and meadows
• Found at Murree, the Galiyat, Swat, Kaghan, Azad Kashmir and Chitral
• They give timber, fuel and fodder, and protect water sources and soil.
• They shelter wildlife such as the markhor, snow leopard and musk deer.
""",
"""
پہاڑی جنگلات ٹھنڈے اور بارانی شمال میں اگتے ہیں اور بلندی کے ساتھ بدلتے ہیں۔

• نچلی ڈھلوانیں (تقریباً 900 سے 1,800 میٹر): چیڑ کا درخت
• درمیانی ڈھلوانیں (تقریباً 1,500 سے 3,000 میٹر): کائل، دیودار، فر اور سپروس
• خشک اندرونی وادیاں (چترال، گلگت): چلغوزہ، دیودار اور صنوبر
• بلند ترین علاقے (تقریباً 3,500 میٹر سے اوپر): بلند پہاڑی جھاڑیاں اور چراگاہیں
• مری، گلیات، سوات، کاغان، آزاد کشمیر اور چترال میں پائے جاتے ہیں
• یہ لکڑی، ایندھن اور چارہ دیتے ہیں، اور پانی کے ذرائع اور مٹی کی حفاظت کرتے ہیں۔
• یہ مارخور، برفانی چیتے اور کستوری ہرن جیسے جنگلی جانوروں کو پناہ دیتے ہیں۔
"""),

    c("8.2",
"""
Riverine forests grow on the flood plains along the Indus and its tributaries in Punjab and Sindh. They depend on river floods.

• Common trees: kikar (babul), shisham (tahli), bahan and tamarisk (jhau)
• In Sindh they are known as "kacha" forests.
• They give fuelwood, timber and grazing land, and are a home for birds and animals.
• They protect river banks from erosion.
• Many have been cleared for farming, or have dried out because dams and barrages reduce the floods.
""",
"""
دریائی جنگلات پنجاب اور سندھ میں دریائے سندھ اور اس کی شاخوں کے سیلابی میدانوں میں اگتے ہیں۔ یہ دریا کے سیلاب پر منحصر ہیں۔

• عام درخت: کیکر (ببول)، شیشم (ٹاہلی)، بہان اور پہاڑی جھاؤ
• سندھ میں انہیں "کچے" کے جنگلات کہا جاتا ہے۔
• یہ ایندھن، لکڑی اور چراگاہیں دیتے ہیں، اور پرندوں اور جانوروں کا مسکن ہیں۔
• یہ دریا کے کناروں کو کٹاؤ سے بچاتے ہیں۔
• بہت سے کھیتی کے لیے کاٹ دیے گئے، یا اس لیے خشک ہو گئے کہ ڈیم اور بیراج سیلاب کم کر دیتے ہیں۔
"""),

    c("8.3",
"""
Desert plants have special features to survive with little water: deep roots, small or thorny leaves and waxy skins.

Common desert plants:
• Khejri (Prosopis cineraria): the "desert tree", used for fodder and fuel
• Kikar (acacia)
• Phog (Calligonum) and Akk (Calotropis)
• Camel thorn and sarkanda grass
• Date palm near water

They feed camels, goats and sheep, give fuel and fencing, and hold the sand so that dunes move less.

Found in Thar, Cholistan, Thal and Kharan.
""",
"""
صحرائی پودوں میں کم پانی میں زندہ رہنے کی خاص صلاحیتیں ہوتی ہیں: گہری جڑیں، چھوٹے یا کانٹے دار پتے اور موم دار چھال۔

عام صحرائی پودے:
• کھیجڑی (پروسوپس): "صحرا کا درخت"، چارے اور ایندھن کے کام آتا ہے
• کیکر (ببول)
• پھوگ اور آک
• اونٹ کٹارا اور سرکنڈا گھاس
• پانی کے قریب کھجور کا درخت

یہ اونٹ، بکریوں اور بھیڑوں کو خوراک دیتے ہیں، ایندھن اور باڑ فراہم کرتے ہیں، اور ریت کو تھام کر ٹیلوں کی حرکت کم کرتے ہیں۔

یہ تھر، چولستان، تھل اور خاران میں پائے جاتے ہیں۔
"""),

    c("8.4",
"""
Mangroves are salt-tolerant trees that grow along the coast where the sea meets rivers.

• Main areas: the Indus Delta (the largest), and also Sonmiani, Kalmat Khor and Jiwani in Balochistan
• The most common species is the grey mangrove (Avicennia marina).
• They protect the coast from storms, cyclones and erosion.
• They are nurseries for fish, shrimp and crabs, so coastal fishing depends on them.
• They give fuel and fodder and store carbon.
• Threats: less fresh water from the Indus, cutting for fuel, pollution and grazing.
• Planting campaigns have helped to restore some areas.
""",
"""
مینگرو نمک برداشت کرنے والے درخت ہیں جو ساحل پر، جہاں دریا اور سمندر ملتے ہیں، اگتے ہیں۔

• اہم علاقے: دریائے سندھ کا ڈیلٹا (سب سے بڑا)، اور بلوچستان میں سونمیانی، کلمت خور اور جیوانی
• سب سے عام قسم گرے مینگرو (ایویسینیا مارینا) ہے۔
• یہ ساحل کو طوفانوں، سمندری آندھیوں اور کٹاؤ سے بچاتے ہیں۔
• یہ مچھلی، جھینگے اور کیکڑوں کی نرسری ہیں، اس لیے ساحلی ماہی گیری ان پر منحصر ہے۔
• یہ ایندھن اور چارہ دیتے ہیں اور کاربن ذخیرہ کرتے ہیں۔
• خطرات: دریائے سندھ سے میٹھا پانی کم آنا، ایندھن کے لیے کٹائی، آلودگی اور چرائی
• شجرکاری مہموں نے کچھ علاقے بحال کرنے میں مدد دی ہے۔
"""),

    c("8.5",
"""
The Chinar (Platanus orientalis) is a large, long-lived tree famous for its broad leaves shaped like a hand.

• It grows in the cooler northern valleys of Pakistan: Gilgit-Baltistan, Azad Kashmir and parts of Khyber Pakhtunkhwa.
• It is often found beside streams and in village squares.
• Height: it can grow to about 30 m, with a very thick trunk, and live for hundreds of years.
• In autumn (October–November) its leaves turn red, orange and gold.
• It gives dense shade and its wood is used for furniture.
• Chinar trees have been planted in gardens since Mughal times and are a symbol of Kashmir.
""",
"""
چنار (پلاٹینس اورینٹیلس) ایک بڑا اور طویل عمر درخت ہے جو ہاتھ کی شکل کے چوڑے پتوں کی وجہ سے مشہور ہے۔

• یہ پاکستان کی ٹھنڈی شمالی وادیوں میں اگتا ہے: گلگت بلتستان، آزاد کشمیر اور خیبر پختونخوا کے کچھ حصے۔
• یہ اکثر ندیوں کے کنارے اور گاؤں کے چوراہوں میں ملتا ہے۔
• اونچائی: یہ تقریباً 30 میٹر تک بڑھ سکتا ہے، بہت موٹے تنے کے ساتھ، اور سینکڑوں سال زندہ رہ سکتا ہے۔
• خزاں (اکتوبر تا نومبر) میں اس کے پتے سرخ، نارنجی اور سنہری ہو جاتے ہیں۔
• یہ گھنا سایہ دیتا ہے اور اس کی لکڑی فرنیچر میں استعمال ہوتی ہے۔
• مغل دور سے باغات میں چنار لگائے جاتے رہے ہیں اور یہ کشمیر کی علامت ہے۔
"""),

    c("8.6",
"""
The Deodar (Cedrus deodara) is the national tree of Pakistan. Its name comes from the Sanskrit "devadaru", meaning "wood of the gods".

• Height: it can grow to 50 m or more.
• It grows at about 1,500–3,200 m in Swat, Kaghan, Chitral, Gilgit, Murree and Kashmir.
• Its wood is strong, scented and long-lasting, and has been used for houses, bridges, boats and furniture.
• Over-cutting and illegal logging have reduced the forests, so cutting is restricted.
• The forests protect watersheds and prevent landslides.
""",
"""
دیودار (سیڈرس دیودارا) پاکستان کا قومی درخت ہے۔ اس کا نام سنسکرت لفظ "دیوداروا" سے آیا ہے، جس کا مطلب "دیوتاؤں کی لکڑی" ہے۔

• اونچائی: یہ 50 میٹر یا اس سے زیادہ تک بڑھ سکتا ہے۔
• یہ سوات، کاغان، چترال، گلگت، مری اور کشمیر میں تقریباً 1,500 سے 3,200 میٹر کی بلندی پر اگتا ہے۔
• اس کی لکڑی مضبوط، خوشبودار اور دیرپا ہے، اور گھروں، پلوں، کشتیوں اور فرنیچر میں استعمال ہوتی رہی ہے۔
• ضرورت سے زیادہ کٹائی اور غیر قانونی کٹائی نے جنگلات کم کر دیے، اس لیے کٹائی پر پابندیاں ہیں۔
• یہ جنگلات آبی علاقوں کی حفاظت کرتے ہیں اور لینڈ سلائیڈنگ روکتے ہیں۔
"""),

    c("8.7",
"""
Forests are very important for Pakistan:

• Water: they hold rain and snow, feed springs and protect dams from silt.
• Soil: tree roots stop erosion and landslides.
• Floods: they slow down runoff.
• Timber, fuelwood and fodder
• Wildlife: they are the home of many animals and birds.
• Climate: they take in carbon dioxide and cool the air.
• Livelihoods: honey, medicinal plants, nuts and tourism provide income.
• Coastal mangroves protect against storms and support fisheries.
• They help to stop deserts from spreading.
""",
"""
جنگلات پاکستان کے لیے بہت اہم ہیں:

• پانی: یہ بارش اور برف کو روکتے ہیں، چشموں کو پانی دیتے ہیں اور ڈیموں کو گاد سے بچاتے ہیں۔
• مٹی: درختوں کی جڑیں کٹاؤ اور لینڈ سلائیڈنگ روکتی ہیں۔
• سیلاب: یہ بہتے پانی کی رفتار کم کرتے ہیں۔
• لکڑی، ایندھن اور چارہ
• جنگلی حیات: یہ بہت سے جانوروں اور پرندوں کا گھر ہیں۔
• آب و ہوا: یہ کاربن ڈائی آکسائیڈ جذب کرتے اور ہوا کو ٹھنڈا کرتے ہیں۔
• روزگار: شہد، جڑی بوٹیاں، خشک میوہ اور سیاحت سے آمدنی ہوتی ہے۔
• ساحلی مینگرو طوفانوں سے بچاتے ہیں اور ماہی گیری کو سہارا دیتے ہیں۔
• یہ صحراؤں کو پھیلنے سے روکنے میں مدد دیتے ہیں۔
"""),

    c("8.8",
"""
Deforestation means the loss of forests.

Causes:
• Illegal logging for timber
• Cutting trees for fuelwood and cooking
• Clearing forest for farms, houses and roads
• Over-grazing by livestock
• Forest fires, such as the 2022 fire in the chilgoza forests of Balochistan

Effects:
• Soil erosion, floods and landslides
• Silting of dams
• Loss of wildlife
• Less rain, more heat and desertification

Solutions: tree-planting drives, community forest management, cheaper alternative fuels, stronger laws against illegal logging, and the National Forest Policy (2015).
""",
"""
جنگلات کی کٹائی سے مراد جنگلات کا ختم ہونا ہے۔

اسباب:
• لکڑی کے لیے غیر قانونی کٹائی
• ایندھن اور کھانا پکانے کے لیے درخت کاٹنا
• کھیتوں، گھروں اور سڑکوں کے لیے جنگل صاف کرنا
• مویشیوں کی ضرورت سے زیادہ چرائی
• جنگل کی آگ، جیسے 2022 میں بلوچستان کے چلغوزے کے جنگلات میں لگنے والی آگ

اثرات:
• مٹی کا کٹاؤ، سیلاب اور لینڈ سلائیڈنگ
• ڈیموں میں گاد بھرنا
• جنگلی حیات کا نقصان
• بارش میں کمی، گرمی میں اضافہ اور صحرا کا پھیلاؤ

حل: شجرکاری مہمات، کمیونٹی کے ذریعے جنگل کا انتظام، سستا متبادل ایندھن، غیر قانونی کٹائی کے خلاف سخت قوانین، اور قومی جنگلات پالیسی (2015)۔
"""),

    // ================= TOPIC 9 =================
    c("9.0",
"""
Pakistan has very large coal resources, mostly of low-grade coal called lignite.

• Thar (Sindh): about 175 billion tonnes, one of the world's largest lignite deposits
• Other Sindh fields: Lakhra, Sonda–Thatta and Badin
• Punjab: Salt Range fields (Dandot, Pidh)
• Balochistan: Quetta, Khost, Harnai and Degari
• Khyber Pakhtunkhwa: Hangu, Darra Adam Khel and Cherat
• Uses: power plants, brick kilns, cement and industry
• Thar coal now supplies power plants such as the Engro plant at Block II (started 2019).
""",
"""
پاکستان میں کوئلے کے بہت بڑے ذخائر ہیں، زیادہ تر کم درجے کے کوئلے یعنی لگنائٹ کی صورت میں۔

• تھر (سندھ): تقریباً 175 ارب ٹن، دنیا کے بڑے لگنائٹ ذخائر میں سے ایک
• سندھ کے دیگر کوئلہ میدان: لاکھڑا، سونڈا ٹھٹھہ اور بدین
• پنجاب: سالٹ رینج کے میدان (ڈنڈوٹ، پڈھ)
• بلوچستان: کوئٹہ، خوست، ہرنائی اور ڈیگاری
• خیبر پختونخوا: ہنگو، درہ آدم خیل اور چراٹ
• استعمال: بجلی گھر، اینٹوں کے بھٹے، سیمنٹ اور صنعت
• تھر کا کوئلہ اب اینگرو پلانٹ جیسے بجلی گھروں کو دیتا ہے (بلاک 2، 2019 میں شروع)۔
"""),

    c("9.1",
"""
Natural gas is Pakistan's most important fuel for homes, power plants and fertiliser factories.

• First big discovery: Sui in Balochistan, in 1952; production began in 1955.
• Other fields: Mari (Daharki), Kandhkot, Qadirpur, Uch, Pirkoh and Loti
• Sindh and Balochistan produce most of the gas.
• It is used for cooking and heating, electricity, fertiliser and CNG.
• Local reserves are falling, so Pakistan imports liquefied natural gas (LNG) from Qatar; the first cargo arrived in 2015 at Port Qasim.
• Gas is carried to cities through pipelines.
""",
"""
قدرتی گیس پاکستان میں گھروں، بجلی گھروں اور کھاد کے کارخانوں کے لیے سب سے اہم ایندھن ہے۔

• پہلی بڑی دریافت: بلوچستان میں سوئی، 1952 میں؛ پیداوار 1955 میں شروع ہوئی۔
• دیگر میدان: ماری (ڈہرکی)، کندھکوٹ، قادر پور، اچ، پیر کوہ اور لوٹی
• زیادہ تر گیس سندھ اور بلوچستان سے نکلتی ہے۔
• یہ کھانا پکانے اور گرم رکھنے، بجلی، کھاد اور سی این جی میں استعمال ہوتی ہے۔
• مقامی ذخائر کم ہو رہے ہیں، اس لیے پاکستان قطر سے مائع قدرتی گیس (ایل این جی) درآمد کرتا ہے؛ پہلی کھیپ 2015 میں پورٹ قاسم پہنچی۔
• گیس پائپ لائنوں کے ذریعے شہروں تک پہنچتی ہے۔
"""),

    c("9.2",
"""
Pakistan produces only a small part of the oil it needs, so most crude oil and fuel is imported.

• Early discovery: oil was found at Khaur near Attock around 1915.
• Potohar fields: Dhurnal, Balkassar, Joya Mair and Toot
• Southern Sindh (Badin and nearby fields) now gives a large share of the production.
• Refineries: Attock (Rawalpindi), PARCO (Mahmood Kot), National Refinery and Pakistan Refinery (Karachi), and others
• Exploration in the Arabian Sea and in Balochistan continues.
• Uses: transport, power generation, industry and the petrochemical sector
""",
"""
پاکستان اپنی ضرورت کے تیل کا صرف تھوڑا حصہ خود پیدا کرتا ہے، اس لیے زیادہ تر خام تیل اور ایندھن درآمد ہوتا ہے۔

• ابتدائی دریافت: اٹک کے قریب کھوڑ میں تقریباً 1915 میں تیل ملا۔
• پوٹھوہار کے میدان: ڈھرنال، بلکسر، جویا مئیر اور توت
• جنوبی سندھ (بدین اور قریبی میدان) اب پیداوار کا بڑا حصہ دیتے ہیں۔
• ریفائنریاں: اٹک (راولپنڈی)، پارکو (محمود کوٹ)، نیشنل ریفائنری اور پاکستان ریفائنری (کراچی)، اور دیگر
• بحیرہ عرب اور بلوچستان میں تلاش جاری ہے۔
• استعمال: نقل و حمل، بجلی کی پیداوار، صنعت اور پیٹروکیمیکل شعبہ
"""),

    c("9.3",
"""
Pakistan has huge deposits of rock salt, mainly in the Salt Range of Punjab and in Khyber Pakhtunkhwa.

• Khewra Salt Mine (Jhelum district): one of the largest salt mines in the world; organised mining began in the 1870s.
• Other mines: Warcha (Khushab), Kalabagh (Mianwali), and Bahadur Khel and Jatta (Karak and Kohat)
• The pink "Himalayan salt" from Khewra is exported across the world.
• Khewra has a mosque built of salt bricks and is a popular tourist site.
• Salt is used in food, chemicals, soda ash and for de-icing.
""",
"""
پاکستان میں چٹانی نمک کے بہت بڑے ذخائر ہیں، خاص طور پر پنجاب کی سالٹ رینج اور خیبر پختونخوا میں۔

• کھیوڑہ کی نمک کی کان (ضلع جہلم): دنیا کی بڑی نمک کی کانوں میں سے ایک؛ باقاعدہ کان کنی 1870 کی دہائی میں شروع ہوئی۔
• دیگر کانیں: وارچھا (خوشاب)، کالاباغ (میانوالی)، اور بہادر خیل اور جٹہ (کرک اور کوہاٹ)
• کھیوڑہ کا گلابی "ہمالیائی نمک" دنیا بھر میں برآمد ہوتا ہے۔
• کھیوڑہ میں نمک کی اینٹوں سے بنی مسجد ہے اور یہ مقبول سیاحتی مقام ہے۔
• نمک خوراک، کیمیکل، سوڈا ایش اور برف پگھلانے میں استعمال ہوتا ہے۔
"""),

    c("9.4",
"""
Large copper and gold deposits lie in the Chagai district of Balochistan.

• Saindak: a copper-gold-silver mine operating since 2002, run by a Chinese company under lease
• Reko Diq: one of the largest undeveloped copper-gold deposits in the world
• Dalbandin and other areas of Chagai also have mineral potential.
• Small-scale gold washing takes place in the Indus sands near Attock, and in rivers of Gilgit-Baltistan.
• Copper is used in wires, electronics, pipes and machinery.
""",
"""
تانبے اور سونے کے بڑے ذخائر بلوچستان کے ضلع چاغی میں ہیں۔

• سینڈک: تانبے، سونے اور چاندی کی کان جو 2002 سے چل رہی ہے، اور ایک چینی کمپنی لیز پر چلا رہی ہے
• ریکوڈک: دنیا کے بڑے غیر استعمال شدہ تانبے اور سونے کے ذخائر میں سے ایک
• دالبندین اور چاغی کے دیگر علاقوں میں بھی معدنی امکانات ہیں۔
• اٹک کے قریب دریائے سندھ کی ریت اور گلگت بلتستان کے دریاؤں میں چھوٹے پیمانے پر سونا چھانا جاتا ہے۔
• تانبا تاروں، الیکٹرانکس، پائپوں اور مشینری میں استعمال ہوتا ہے۔
"""),

    c("9.5",
"""
Chromite is the ore of chromium, a metal used to make stainless steel and in chemicals and leather tanning.

• Main areas: Muslim Bagh (Zhob) and Khuzdar in Balochistan
• Also found in Malakand and Dir (Khyber Pakhtunkhwa), and in Waziristan
• Pakistan has exported chromite, mainly to China.
• Value is added if it is processed in the country instead of being sent out as raw ore.
""",
"""
کرومائٹ کرومیم کی کچ دھات ہے، جو سٹینلیس اسٹیل بنانے، کیمیکلز اور چمڑا رنگنے میں استعمال ہوتی ہے۔

• اہم علاقے: بلوچستان میں مسلم باغ (ژوب) اور خضدار
• ملاکنڈ اور دیر (خیبر پختونخوا) اور وزیرستان میں بھی پائی جاتی ہے
• پاکستان نے کرومائٹ برآمد کی ہے، زیادہ تر چین کو۔
• اگر اسے خام حالت میں بھیجنے کے بجائے ملک کے اندر پروسیس کیا جائے تو قدر میں اضافہ ہوتا ہے۔
"""),

    c("9.6",
"""
Pakistan has many kinds of marble and onyx.

• Khyber Pakhtunkhwa: Buner, Mohmand (Ghalanai), Swat, Chitral and Mansehra
• Balochistan: Zhob, Loralai and Chagai, famous for onyx
• Punjab: Chiniot
• Uses: floors, tiles, buildings, mosques, kitchen tops and handicrafts
• Marble is exported, but much is lost as waste in mining and cutting, and old methods reduce quality.
• Marble cities and modern machinery are being introduced to improve the industry.
""",
"""
پاکستان میں سنگ مرمر اور عقیق (اونکس) کی کئی اقسام ہیں۔

• خیبر پختونخوا: بونیر، مہمند (غلنئی)، سوات، چترال اور مانسہرہ
• بلوچستان: ژوب، لورالائی اور چاغی، جو اونکس کے لیے مشہور ہے
• پنجاب: چنیوٹ
• استعمال: فرش، ٹائلیں، عمارتیں، مساجد، کچن ٹاپ اور دستکاری
• سنگ مرمر برآمد ہوتا ہے، لیکن کان کنی اور کٹائی میں بہت سا ضائع ہو جاتا ہے، اور پرانے طریقوں سے معیار کم ہوتا ہے۔
• صنعت بہتر بنانے کے لیے ماربل سٹی اور جدید مشینری متعارف کرائی جا رہی ہے۔
"""),

    c("9.7",
"""
Limestone is found widely in Pakistan and is the main raw material for cement.

• Main areas: the Salt Range and Potohar, Kohat, Hazara, Nizampur, Lasbela and Hub (Balochistan), and the Kohistan hills of Sindh
• Uses: cement, lime, glass, steel-making, sugar refining and building stone
• Pakistan's cement industry is large and exports cement.
• Quarrying in places such as the Margalla Hills has caused environmental concern.
""",
"""
چونا پتھر پاکستان میں بڑے پیمانے پر ملتا ہے اور سیمنٹ کا بنیادی خام مال ہے۔

• اہم علاقے: سالٹ رینج اور پوٹھوہار، کوہاٹ، ہزارہ، نظام پور، لسبیلہ اور حب (بلوچستان)، اور سندھ کی کوہستان پہاڑیاں
• استعمال: سیمنٹ، چونا، شیشہ، فولاد سازی، چینی صفائی اور تعمیراتی پتھر
• پاکستان کی سیمنٹ صنعت بڑی ہے اور سیمنٹ برآمد کرتی ہے۔
• مارگلہ ہلز جیسی جگہوں پر کان کنی نے ماحولیاتی تشویش پیدا کی ہے۔
"""),

    c("9.8",
"""
Northern Pakistan is rich in precious and semi-precious stones.

• Emerald: Swat (Mingora and Shamozai)
• Ruby: Hunza and Nangimali (Azad Kashmir)
• Peridot: Sapat mine in Kohistan
• Topaz: Katlang (Mardan) and Skardu, famous for pink topaz
• Aquamarine and tourmaline: Skardu, Shigar and Chitral
• Others: garnet, quartz and lapis-like stones
• Most mining is small-scale. Cutting and polishing is done locally, and Peshawar is a centre of the gem trade.
""",
"""
شمالی پاکستان قیمتی اور نیم قیمتی پتھروں سے مالا مال ہے۔

• زمرد: سوات (مینگورہ اور شموزئی)
• یاقوت: ہنزہ اور نانگی مالی (آزاد کشمیر)
• زبرجد (پیری ڈوٹ): کوہستان میں سپات کی کان
• پکھراج (ٹوپاز): کاٹلنگ (مردان) اور اسکردو، گلابی پکھراج کے لیے مشہور
• ایکوامرین اور ٹورمالین: اسکردو، شگر اور چترال
• دیگر: عقیق، کوارٹز اور لاجورد جیسے پتھر
• زیادہ تر کان کنی چھوٹے پیمانے پر ہوتی ہے۔ کٹائی اور پالش مقامی طور پر ہوتی ہے، اور پشاور جواہرات کی تجارت کا مرکز ہے۔
"""),

    c("9.9",
"""
Reko Diq is a very large copper and gold deposit in Chagai district, Balochistan. The name means "sandy peak" in Balochi.

• Discovered: in 1993
• Type: a porphyry deposit, one of the biggest undeveloped copper-gold deposits in the world
• History: a foreign-led project was stopped in 2011, which led to an international legal case; the dispute was settled in 2022 and the project restarted.
• Ownership under the new arrangement: Barrick Gold holds a half share, and the rest is held by the Balochistan government and Pakistani state-owned companies (check latest reports for changes).
• It is expected to produce copper and gold for decades and to create jobs.
• Concerns include the local benefit, water use and the environment.
""",
"""
ریکوڈک بلوچستان کے ضلع چاغی میں تانبے اور سونے کا بہت بڑا ذخیرہ ہے۔ بلوچی زبان میں نام کا مطلب "ریتیلی چوٹی" ہے۔

• دریافت: 1993 میں
• قسم: پورفری ذخیرہ، دنیا کے سب سے بڑے غیر استعمال شدہ تانبے اور سونے کے ذخائر میں سے ایک
• تاریخ: غیر ملکی قیادت میں چلنے والا منصوبہ 2011 میں روک دیا گیا، جس سے بین الاقوامی قانونی مقدمہ بنا؛ تنازع 2022 میں طے ہوا اور منصوبہ دوبارہ شروع ہوا۔
• نئے انتظام کے تحت ملکیت: بیرک گولڈ کے پاس آدھا حصہ ہے، اور باقی بلوچستان حکومت اور پاکستانی سرکاری کمپنیوں کے پاس ہے (تبدیلی کے لیے تازہ رپورٹیں دیکھیں)۔
• توقع ہے کہ یہ دہائیوں تک تانبا اور سونا پیدا کرے گا اور روزگار دے گا۔
• خدشات میں مقامی فائدہ، پانی کا استعمال اور ماحول شامل ہیں۔
"""),

    // ================= TOPIC 10 =================
    c("10.0",
"""
Agriculture is the backbone of Pakistan's economy.

• It provides around a quarter of the national income (GDP) and employs about 37% of workers.
• It is the main source of raw material for industries such as textiles and sugar.
• Livestock is a very large part of it; Pakistan is among the world's top milk producers.
• Most farmland is irrigated by canals and tubewells.

Crop seasons:
• Rabi (sown in October–December, harvested in March–May): wheat, gram, barley, mustard
• Kharif (sown in April–July, harvested in October–December): rice, cotton, sugarcane, maize, millet

Main crops: wheat, rice, cotton, sugarcane and maize.
""",
"""
زراعت پاکستان کی معیشت کی ریڑھ کی ہڈی ہے۔

• یہ قومی آمدنی (جی ڈی پی) کا تقریباً چوتھائی حصہ دیتی ہے اور تقریباً 37 فیصد کارکنوں کو روزگار دیتی ہے۔
• یہ ٹیکسٹائل اور چینی جیسی صنعتوں کے لیے خام مال کا بنیادی ذریعہ ہے۔
• مویشی اس کا بہت بڑا حصہ ہیں؛ پاکستان دنیا کے سب سے زیادہ دودھ پیدا کرنے والے ممالک میں شامل ہے۔
• زیادہ تر کھیتی نہروں اور ٹیوب ویلوں سے سیراب ہوتی ہے۔

فصلوں کے موسم:
• ربیع (اکتوبر تا دسمبر بوائی، مارچ تا مئی کٹائی): گندم، چنا، جَو، سرسوں
• خریف (اپریل تا جولائی بوائی، اکتوبر تا دسمبر کٹائی): چاول، کپاس، گنا، مکئی، باجرہ

اہم فصلیں: گندم، چاول، کپاس، گنا اور مکئی۔
"""),

    c("10.1",
"""
Wheat is the staple food crop of Pakistan.

• Season: Rabi; sown in October–December and harvested in April–May
• Conditions: cool weather during growth, warm during ripening, and moderate water
• Soil: loamy plains; the Indus plain is ideal
• Provinces: Punjab grows around three-quarters of the crop, then Sindh and Khyber Pakhtunkhwa.
• Production: about 26–31 million tonnes in recent years, among the top ten producers in the world
• Uses: flour for roti, bread and biscuits; the straw is fodder.

The government sets a support price to protect farmers.
""",
"""
گندم پاکستان کی بنیادی غذائی فصل ہے۔

• موسم: ربیع؛ اکتوبر تا دسمبر بوئی جاتی ہے اور اپریل مئی میں کاٹی جاتی ہے
• حالات: بڑھوتری میں ٹھنڈا موسم، پکنے میں گرم موسم، اور معتدل پانی
• مٹی: دوماٹ میدان؛ وادیٔ سندھ مثالی ہے
• صوبے: پنجاب تقریباً تین چوتھائی فصل اگاتا ہے، پھر سندھ اور خیبر پختونخوا
• پیداوار: حالیہ برسوں میں تقریباً 2.6 سے 3.1 کروڑ ٹن، دنیا کے پہلے دس پیدا کنندگان میں سے
• استعمال: روٹی، ڈبل روٹی اور بسکٹ کا آٹا؛ بھوسہ چارے کے کام آتا ہے۔

حکومت کسانوں کے تحفظ کے لیے امدادی قیمت مقرر کرتی ہے۔
"""),

    c("10.2",
"""
Rice is Pakistan's second most important food crop and a major export.

• Season: Kharif; seedlings are transplanted in June–July and harvested in October–November
• Conditions: hot, humid weather and plenty of water
• Basmati: grown in the "Kallar tract" of Punjab (Gujranwala, Sheikhupura, Hafizabad, Narowal), famous for its aroma and long grains
• Coarse (IRRI) rice: mainly in Sindh (Larkana, Dadu) and in Balochistan (Jaffarabad, Nasirabad)
• Pakistan is one of the world's largest rice exporters.
• The straw is burned or used as fodder; burning adds to smog.
""",
"""
چاول پاکستان کی دوسری اہم ترین غذائی فصل اور بڑی برآمد ہے۔

• موسم: خریف؛ پنیری جون جولائی میں منتقل کی جاتی ہے اور اکتوبر نومبر میں کاٹی جاتی ہے
• حالات: گرم مرطوب موسم اور بہت سا پانی
• باسمتی: پنجاب کے "کلر کے علاقے" (گوجرانوالہ، شیخوپورہ، حافظ آباد، نارووال) میں اگتا ہے، خوشبو اور لمبے دانوں کے لیے مشہور
• موٹا (اری) چاول: زیادہ تر سندھ (لاڑکانہ، دادو) اور بلوچستان (جعفرآباد، نصیرآباد) میں
• پاکستان دنیا کے بڑے چاول برآمد کنندگان میں سے ہے۔
• پرالی جلائی جاتی ہے یا چارے میں استعمال ہوتی ہے؛ جلانے سے سموگ بڑھتی ہے۔
"""),

    c("10.3",
"""
Cotton is Pakistan's most important cash crop, often called "white gold".

• Season: Kharif; sown in April–June and picked in September–December
• Conditions: hot weather, about 200 frost-free days, and moderate water
• Areas: Punjab (Multan, Bahawalpur, Rahim Yar Khan, Dera Ghazi Khan) and Sindh (Sanghar, Nawabshah, Khairpur)
• Uses: cotton fibre for the textile industry (Pakistan's largest export sector), cotton seed for oil and animal feed
• Pakistan is among the world's top cotton producers.
• Problems: pests such as pink bollworm, leaf curl virus, heat, floods and falling area under cotton.
""",
"""
کپاس پاکستان کی سب سے اہم نقد آور فصل ہے، جسے اکثر "سفید سونا" کہا جاتا ہے۔

• موسم: خریف؛ اپریل تا جون بوئی جاتی ہے اور ستمبر تا دسمبر چنی جاتی ہے
• حالات: گرم موسم، تقریباً 200 پالا فری دن، اور معتدل پانی
• علاقے: پنجاب (ملتان، بہاولپور، رحیم یار خان، ڈیرہ غازی خان) اور سندھ (سانگھڑ، نواب شاہ، خیرپور)
• استعمال: ٹیکسٹائل صنعت کے لیے روئی (پاکستان کا سب سے بڑا برآمدی شعبہ)، اور بنولہ تیل اور جانوروں کے چارے کے لیے
• پاکستان دنیا کے سب سے بڑے کپاس پیدا کرنے والے ممالک میں شامل ہے۔
• مسائل: گلابی سنڈی جیسے کیڑے، پتہ مروڑ وائرس، گرمی، سیلاب اور کپاس کے زیر کاشت رقبے میں کمی۔
"""),

    c("10.4",
"""
Sugarcane is a major cash crop used to make sugar and gur (jaggery).

• Season: planted in February–March (spring) or September–October (autumn); harvested from November to March
• Conditions: hot, humid weather and plenty of water
• Areas: Punjab (the largest share), Sindh and Khyber Pakhtunkhwa (Mardan)
• Production: roughly 80–90 million tonnes a year; Pakistan is among the top five producers.
• Sugar mills crush the cane from November to March.
• By-products: bagasse (fuel for power), molasses (used for ethanol and feed)
• Problems: high water use, late payments to farmers and delays in mill crushing.
""",
"""
گنا ایک بڑی نقد آور فصل ہے جس سے چینی اور گڑ بنتا ہے۔

• موسم: فروری مارچ (بہاریہ) یا ستمبر اکتوبر (خزاں) میں لگایا جاتا ہے؛ نومبر سے مارچ تک کاٹا جاتا ہے
• حالات: گرم مرطوب موسم اور بہت سا پانی
• علاقے: پنجاب (سب سے بڑا حصہ)، سندھ اور خیبر پختونخوا (مردان)
• پیداوار: سالانہ تقریباً 8 سے 9 کروڑ ٹن؛ پاکستان پہلے پانچ پیدا کنندگان میں شامل ہے۔
• شوگر ملیں نومبر سے مارچ تک گنا پیستی ہیں۔
• ضمنی مصنوعات: کھوئی (بجلی کے لیے ایندھن)، شیرہ (ایتھانول اور چارے میں استعمال)
• مسائل: زیادہ پانی کا استعمال، کسانوں کو ادائیگیوں میں تاخیر اور ملوں میں پسائی کی دیر۔
"""),

    c("10.5",
"""
Maize (corn) is the third most important cereal of Pakistan after wheat and rice.

• Seasons: grown as a Kharif crop and also as a spring crop
• Areas: Khyber Pakhtunkhwa (Mardan, Swat, Charsadda) and Punjab (Sahiwal, Okara, Sheikhupura)
• Production: about 9–10 million tonnes in recent years
• Uses: "makai ki roti", poultry and cattle feed, starch, corn oil and cornflakes
• Hybrid seed has raised yields, and demand from the poultry industry keeps growing.
""",
"""
مکئی گندم اور چاول کے بعد پاکستان کا تیسرا اہم اناج ہے۔

• موسم: خریف کی فصل کے طور پر اور بہاریہ فصل کے طور پر بھی اگائی جاتی ہے
• علاقے: خیبر پختونخوا (مردان، سوات، چارسدہ) اور پنجاب (ساہیوال، اوکاڑہ، شیخوپورہ)
• پیداوار: حالیہ برسوں میں تقریباً 90 سے 100 لاکھ ٹن
• استعمال: "مکئی کی روٹی"، مرغیوں اور مویشیوں کا چارہ، نشاستہ، مکئی کا تیل اور کارن فلیکس
• ہائبرڈ بیج نے پیداوار بڑھائی ہے، اور پولٹری صنعت کی طلب بڑھتی جا رہی ہے۔
"""),

    c("10.6",
"""
Pakistan grows many fruits, and several are exported.

• Mango: Sindh (Mirpurkhas) and Punjab (Multan); famous varieties are Sindhri, Chaunsa and Anwar Ratol. Pakistan is among the top mango producers.
• Citrus: kinnow from Sargodha is the best known.
• Apple: Balochistan (Ziarat, Kalat, Quetta) and Swat
• Dates: Khairpur, Turbat and Panjgur; Pakistan is among the main date producers.
• Apricot and cherry: Hunza and Gilgit-Baltistan
• Grapes and pomegranate: Quetta and Zhob
• Banana and guava: Sindh and Punjab
• Peaches: Swat
""",
"""
پاکستان میں بہت سے پھل اگتے ہیں، اور کئی برآمد ہوتے ہیں۔

• آم: سندھ (میرپور خاص) اور پنجاب (ملتان)؛ مشہور اقسام سندھڑی، چونسہ اور انور رٹول ہیں۔ پاکستان آم پیدا کرنے والے بڑے ممالک میں شامل ہے۔
• مالٹا: سرگودھا کا کنو سب سے مشہور ہے۔
• سیب: بلوچستان (زیارت، قلات، کوئٹہ) اور سوات
• کھجور: خیرپور، تربت اور پنجگور؛ پاکستان کھجور پیدا کرنے والے اہم ممالک میں سے ہے۔
• خوبانی اور چیری: ہنزہ اور گلگت بلتستان
• انگور اور انار: کوئٹہ اور ژوب
• کیلا اور امرود: سندھ اور پنجاب
• آڑو: سوات
"""),

    c("10.7",
"""
Most of Pakistan is dry, so farming depends on irrigation.

Types of irrigation:
• Canal irrigation: the main method, covering most irrigated land
• Tubewells: pump groundwater, especially in Punjab
• Wells and Persian wheels
• Karez (underground channels) in Balochistan
• Barani (rain-fed) farming in Potohar and highland areas
• Flood irrigation along rivers

Issues: much water is lost in unlined canals, and flood irrigation wastes water.

Better practices: lining canals, laser land levelling, drip and sprinkler irrigation, and crops that need less water.
""",
"""
پاکستان کا زیادہ تر حصہ خشک ہے، اس لیے زراعت کا انحصار آبپاشی پر ہے۔

آبپاشی کی اقسام:
• نہری آبپاشی: بنیادی طریقہ، جو زیادہ تر سیراب زمین کو سیراب کرتا ہے
• ٹیوب ویل: زیر زمین پانی نکالتے ہیں، خاص طور پر پنجاب میں
• کنویں اور رہٹ
• بلوچستان میں کاریز (زیر زمین نالیاں)
• پوٹھوہار اور بلند علاقوں میں بارانی کھیتی
• دریاؤں کے ساتھ سیلابی آبپاشی

مسائل: کچی نہروں میں بہت سا پانی ضائع ہوتا ہے، اور سیلابی آبپاشی پانی ضائع کرتی ہے۔

بہتر طریقے: نہروں کی پختگی، لیزر لینڈ لیولنگ، ڈرپ اور سپرنکلر آبپاشی، اور کم پانی والی فصلیں۔
"""),

    c("10.8",
"""
Land use in Pakistan (approximate):

• Total area: about 79.6 million hectares
• Cultivated land: roughly a quarter to 28%, about 22–23 million hectares
• Forest: about 5%
• The rest is mountains, deserts, rangeland and unusable land.

Main soils:
• Alluvial soil in the Indus plain: the most fertile
• Loess soil in Potohar
• Sandy desert soil in Thar and Cholistan
• Thin mountain soils in the north

Most farms are small; the majority are under five hectares.

Pakistan has ten agro-ecological zones, such as the Indus Delta, the northern and southern irrigated plains, the sandy desert, rain-fed areas and the dry western plateau.
""",
"""
پاکستان میں زمین کا استعمال (تقریبی):

• کل رقبہ: تقریباً 7.96 کروڑ ہیکٹر
• زیر کاشت زمین: تقریباً چوتھائی سے 28 فیصد، یعنی 2.2 سے 2.3 کروڑ ہیکٹر
• جنگلات: تقریباً 5 فیصد
• باقی پہاڑ، صحرا، چراگاہیں اور ناقابل استعمال زمین ہے۔

اہم مٹیاں:
• وادیٔ سندھ میں دریائی گاد کی مٹی: سب سے زرخیز
• پوٹھوہار میں لوئس مٹی
• تھر اور چولستان میں ریتیلی صحرائی مٹی
• شمال میں پتلی پہاڑی مٹی

زیادہ تر کھیت چھوٹے ہیں؛ اکثریت پانچ ہیکٹر سے کم ہے۔

پاکستان میں دس زرعی ماحولیاتی علاقے ہیں، جیسے دریائے سندھ کا ڈیلٹا، شمالی اور جنوبی سیراب میدان، ریتیلا صحرا، بارانی علاقے اور خشک مغربی سطح مرتفع۔
"""),

    c("10.9",
"""
Pakistan's agriculture faces many problems:

• Water shortage and waste, and falling groundwater
• Waterlogging and salinity damaging land
• Small, divided landholdings
• Old farming methods and weak use of machinery
• Costly seed, fertiliser and electricity
• Pests, diseases and poor seed quality
• Climate change: heatwaves, irregular rain and floods, such as in 2022
• Poor storage and marketing; much produce is lost after harvest
• Middlemen, lack of credit and unstable prices

Solutions: new dams, efficient irrigation, certified seed, mechanisation, easy credit, research and extension services, cold storage and crop insurance.
""",
"""
پاکستان کی زراعت کو بہت سے مسائل کا سامنا ہے:

• پانی کی کمی اور ضیاع، اور زیر زمین پانی کی سطح میں کمی
• زمین میں پانی جمع ہونا اور کھاری پن جو زمین کو نقصان پہنچاتا ہے
• چھوٹی اور بٹی ہوئی ملکیتیں
• پرانے طریقے اور مشینری کا کم استعمال
• مہنگا بیج، کھاد اور بجلی
• کیڑے، بیماریاں اور بیج کا ناقص معیار
• موسمیاتی تبدیلی: ہیٹ ویو، بے قاعدہ بارش اور سیلاب، جیسے 2022 میں
• ناقص ذخیرہ اور مارکیٹنگ؛ کٹائی کے بعد بہت سی پیداوار ضائع ہو جاتی ہے
• آڑھتی، قرضوں کی کمی اور غیر مستحکم قیمتیں

حل: نئے ڈیم، مؤثر آبپاشی، تصدیق شدہ بیج، مشینی کاشت، آسان قرضے، تحقیق اور توسیعی خدمات، کولڈ اسٹوریج اور فصلوں کا بیمہ۔
""")
)

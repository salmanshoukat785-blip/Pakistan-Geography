@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pakgeo.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PakGeoApp(prefs: Prefs) {
    val stack = remember { mutableStateListOf("splash") }
    val route = stack.last()
    val dir = if (prefs.lang == "ur") LayoutDirection.Rtl else LayoutDirection.Ltr
    val go: (String) -> Unit = { stack.add(it) }
    val replace: (String) -> Unit = {
        if (stack.size > 1) stack.removeAt(stack.size - 1)
        stack.add(it)
    }
    val home: () -> Unit = {
        stack.clear()
        stack.add("dashboard")
    }
    val back: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.size - 1) }

    BackHandler(enabled = route != "splash" && stack.size > 1) { back() }

    CompositionLocalProvider(
        LocalLang provides prefs.lang,
        LocalLayoutDirection provides dir
    ) {
        PakTheme(prefs.themeMode, prefs.colorKey) {
            val parts = route.split(":")
            when (parts[0]) {
                "splash" -> SplashScreen {
                    stack.clear()
                    stack.add("dashboard")
                }
                "settings" -> SettingsScreen(prefs, back)
                "book" -> BookScreen(prefs, go, back)
                "search" -> SearchScreen(prefs, go, back)
                "bookmarks" -> BookmarksScreen(prefs, go, back)
                "progress" -> ProgressScreen(prefs, back)
                "setup" -> QuizSetupScreen(parts[1], go, back)
                "daily" -> DailyScreen(prefs, go, back)
                "play" -> PlayScreen(prefs, replace, back)
                "result" -> ResultScreen(prefs, home, back)
                "review" -> ReviewScreen(prefs, go, back)
                "scores" -> ScoresScreen(prefs, back)
                "export" -> ExportScreen(back)
                "facts" -> QuickFactsScreen(go, back)
                "fact" -> QuickListScreen(parts[1], back)
                "flash" -> FlashcardsScreen(prefs, back)
                "topic" -> TopicScreen(prefs, parts[1].toInt(), go, back)
                "reader" -> ReaderScreen(prefs, parts[1].toInt(), parts[2].toInt(), back)
                else -> DashboardScreen(prefs, go)
            }
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.6f) }
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, tween(900)) }
        launch { alpha.animateTo(1f, tween(900)) }
        delay(2000)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xFF01411C)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = null,
                modifier = Modifier.size(180.dp).scale(scale.value)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Pakistan Geography",
                color = Color.White.copy(alpha = alpha.value),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "پاکستان جغرافیہ",
                color = Color.White.copy(alpha = alpha.value * 0.85f),
                fontSize = 22.sp
            )
        }
    }
}

@Composable
fun DashboardScreen(prefs: Prefs, nav: (String) -> Unit) {
    val context = LocalContext.current
    val soon = tr("Coming in the next part", "یہ اگلے حصے میں آئے گا")
    val grad = Brush.linearGradient(
        listOf(AppColor.from(prefs.colorKey).light, AppColor.from(prefs.colorKey).light.copy(alpha = 0.75f))
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item(span = { GridItemSpan(maxLineSpan) }) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(grad)
                    .statusBarsPadding()
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                tr("Pakistan Geography", "پاکستان جغرافیہ"),
                                color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold
                            )
                            Text(
                                tr("15 topics • Learn • Test • Score", "15 موضوعات • سیکھیں • آزمائیں • اسکور"),
                                color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp
                            )
                        }
                        IconButton(onClick = { nav("settings") }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                    }
                }
            }
        }

        // Quick actions
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("📝", tr("Quiz", "کوئز"), Modifier.weight(1f)) { nav("setup:quiz") }
                QuickAction("🎯", tr("Self Test", "سیلف ٹیسٹ"), Modifier.weight(1f)) { nav("setup:self") }
                QuickAction("🔥", tr("Daily", "روزانہ"), Modifier.weight(1f)) { nav("daily") }
                QuickAction("📖", tr("Book", "کتاب"), Modifier.weight(1f)) { nav("book") }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("🔍", tr("Search", "تلاش"), Modifier.weight(1f)) { nav("search") }
                QuickAction("⭐", tr("Bookmarks", "بک مارکس"), Modifier.weight(1f)) { nav("bookmarks") }
                QuickAction("📊", tr("Progress", "پیش رفت"), Modifier.weight(1f)) { nav("progress") }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("🏆", tr("Scores", "اسکور"), Modifier.weight(1f)) { nav("scores") }
                QuickAction("❌", tr("Mistakes", "غلطیاں"), Modifier.weight(1f)) { nav("review") }
                QuickAction("📄", tr("Past Papers", "پرچے"), Modifier.weight(1f)) { nav("setup:paper") }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("💡", tr("Quick Facts", "فوری معلومات"), Modifier.weight(1f)) { nav("facts") }
                QuickAction("📥", tr("Save PDF", "PDF"), Modifier.weight(1f)) { nav("export") }
                QuickAction("🃏", tr("Flashcards", "فلیش کارڈز"), Modifier.weight(1f)) { nav("flash") }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                tr("Topics", "موضوعات"),
                fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Topic cards
        items(topics.size) { i ->
            val t = topics[i]
            TopicCard(t, grad, prefs.readCount(t.id), sectionsOf(t.id).size) { nav("topic:${t.id}") }
        }
    }
}

@Composable
fun QuickAction(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun TopicCard(t: Topic, grad: Brush, read: Int, total: Int, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(3.dp),
        modifier = Modifier.fillMaxWidth().height(138.dp)
    ) {
        Box(Modifier.fillMaxSize().background(grad).padding(14.dp)) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(t.emoji, fontSize = 28.sp)
                    Box(
                        Modifier.size(26.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${t.id}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Column {
                    Text(
                        tr(t.en, t.ur),
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 20.sp
                    )
                    Text(
                        "$read / $total",
                        color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}

package com.pakgeo.app

// Topic 4: Rivers and water resources, Topic 5: Climate
val contentPart3: Map<String, Pair<String, String>> = mapOf(
    // ================= TOPIC 4 =================
    c("4.0",
"""
The Indus is the longest and most important river of Pakistan, often called its lifeline.

• Length: about 3,180 km
• Source: near Lake Mansarovar in Tibet
• Path: it enters Pakistan in Gilgit-Baltistan, flows through Khyber Pakhtunkhwa, Punjab and Sindh, and falls into the Arabian Sea near Keti Bandar.
• Tributaries from the left: Jhelum, Chenab, Ravi and Sutlej (they join as the Panjnad near Mithankot).
• Tributaries from the right: Kabul (joins near Attock), Gilgit, Shyok, Gomal and others.
• Structures: Tarbela Dam, and the Chashma, Taunsa, Guddu, Sukkur and Kotri barrages
• The rare Indus river dolphin lives in its waters.

Most of Pakistan's farming depends on the Indus system.
""",
"""
دریائے سندھ پاکستان کا سب سے طویل اور اہم دریا ہے، جسے اکثر ملک کی شہ رگ کہا جاتا ہے۔

• لمبائی: تقریباً 3,180 کلومیٹر
• منبع: تبت میں جھیل مانسرور کے قریب
• راستہ: یہ گلگت بلتستان میں پاکستان میں داخل ہوتا ہے، خیبر پختونخوا، پنجاب اور سندھ سے گزرتا ہے اور کیٹی بندر کے قریب بحیرہ عرب میں گرتا ہے۔
• بائیں جانب کی شاخیں: جہلم، چناب، راوی اور ستلج (جو مٹھن کوٹ کے قریب پنجند بن کر ملتے ہیں)۔
• دائیں جانب کی شاخیں: کابل (اٹک کے قریب ملتا ہے)، گلگت، شیوک، گومل اور دیگر۔
• ڈھانچے: تربیلا ڈیم، اور چشمہ، تونسہ، گدو، سکھر اور کوٹری کے بیراج
• نایاب سندھ ڈولفن اسی کے پانی میں رہتی ہے۔

پاکستان کی زیادہ تر زراعت دریائے سندھ کے نظام پر منحصر ہے۔
"""),

    c("4.1",
"""
The Jhelum is one of the five rivers of the Punjab.

• Length: about 725 km
• Source: Verinag spring in the Pir Panjal range, Kashmir
• Path: it flows through the Kashmir valley and Wular Lake, enters Pakistan near Muzaffarabad (Azad Kashmir), passes Mangla, and flows through the city of Jhelum.
• The Neelum (Kishanganga) joins it at Muzaffarabad.
• It meets the Chenab at Trimmu, near Jhang.
• Mangla Dam is built on it.
• Under the Indus Waters Treaty (1960), Pakistan has the main right to its water.
""",
"""
جہلم پنجاب کے پانچ دریاؤں میں سے ایک ہے۔

• لمبائی: تقریباً 725 کلومیٹر
• منبع: کشمیر میں پیر پنجال سلسلے کا ویری ناگ چشمہ
• راستہ: یہ وادی کشمیر اور وولر جھیل سے بہتا ہے، مظفرآباد (آزاد کشمیر) کے قریب پاکستان میں داخل ہوتا ہے، منگلا سے گزرتا ہے اور شہر جہلم کے پاس سے بہتا ہے۔
• نیلم (کشن گنگا) مظفرآباد میں اس سے ملتا ہے۔
• یہ جھنگ کے قریب تریموں کے مقام پر چناب سے ملتا ہے۔
• منگلا ڈیم اسی پر بنا ہے۔
• سندھ طاس معاہدہ (1960) کے تحت اس کے پانی پر پاکستان کا بنیادی حق ہے۔
"""),

    c("4.2",
"""
The Chenab is the largest of the Punjab's rivers by water flow.

• Length: about 960 km
• Source: formed by the Chandra and Bhaga rivers in Himachal Pradesh, India
• It enters Pakistan near Sialkot, at the Marala Headworks.
• Headworks on it: Marala, Khanki, Qadirabad and Trimmu
• It meets the Jhelum at Trimmu and the Ravi near Ahmadpur Sial.
• Joined by the Sutlej near Uch Sharif, it forms the Panjnad, which then joins the Indus.
• It irrigates a large part of central Punjab through the Lower Chenab Canal.
""",
"""
چناب بہاؤ کے لحاظ سے پنجاب کے دریاؤں میں سب سے بڑا ہے۔

• لمبائی: تقریباً 960 کلومیٹر
• منبع: بھارتی ہماچل پردیش میں دریائے چندرا اور بھاگا کے ملنے سے بنتا ہے
• یہ سیالکوٹ کے قریب ہیڈ مرالہ سے پاکستان میں داخل ہوتا ہے۔
• اس پر ہیڈ ورکس: مرالہ، خانکی، قادرآباد اور تریموں
• یہ تریموں میں جہلم سے اور احمد پور سیال کے قریب راوی سے ملتا ہے۔
• اُچ شریف کے قریب ستلج کے ملنے سے پنجند بنتا ہے، جو پھر دریائے سندھ میں شامل ہو جاتا ہے۔
• یہ لوئر چناب کینال کے ذریعے وسطی پنجاب کے بڑے حصے کو سیراب کرتا ہے۔
"""),

    c("4.3",
"""
The Ravi is a smaller river of the Punjab, and Lahore stands on its bank.

• Length: about 720 km
• Source: Himachal Pradesh, India, near the Rohtang Pass
• It enters Pakistan near Narowal and flows past Lahore.
• It joins the Chenab near Ahmadpur Sial.
• Under the Indus Waters Treaty (1960) the Ravi was allotted to India, so it carries little water in Pakistan except in the monsoon.
• Water from the Chenab is sent into the Ravi through link canals such as the Marala–Ravi Link.
""",
"""
راوی پنجاب کا ایک چھوٹا دریا ہے، اور لاہور اس کے کنارے آباد ہے۔

• لمبائی: تقریباً 720 کلومیٹر
• منبع: بھارت میں ہماچل پردیش، درۂ روہتانگ کے قریب
• یہ نارووال کے قریب پاکستان میں داخل ہوتا ہے اور لاہور کے پاس سے گزرتا ہے۔
• یہ احمد پور سیال کے قریب چناب میں مل جاتا ہے۔
• سندھ طاس معاہدہ (1960) کے تحت راوی بھارت کو دیا گیا، اس لیے پاکستان میں مون سون کے سوا اس میں پانی کم ہوتا ہے۔
• چناب کا پانی مرالہ راوی لنک جیسی رابطہ نہروں کے ذریعے راوی میں ڈالا جاتا ہے۔
"""),

    c("4.4",
"""
The Sutlej is the longest of the five rivers of the Punjab.

• Length: about 1,450 km
• Source: near Lake Rakshastal in Tibet
• It flows through India's Himachal Pradesh and Punjab and enters Pakistan near Kasur.
• It passes Bahawalnagar and Bahawalpur.
• Headworks: Sulemanki and Islam
• It joins the Chenab near Uch Sharif to form the Panjnad.
• Like the Ravi, it was allotted to India under the Indus Waters Treaty (1960), so its flow in Pakistan is small outside the monsoon.
""",
"""
ستلج پنجاب کے پانچ دریاؤں میں سب سے طویل ہے۔

• لمبائی: تقریباً 1,450 کلومیٹر
• منبع: تبت میں جھیل راکشستال کے قریب
• یہ بھارت کے ہماچل پردیش اور پنجاب سے گزر کر قصور کے قریب پاکستان میں داخل ہوتا ہے۔
• یہ بہاولنگر اور بہاولپور کے پاس سے گزرتا ہے۔
• ہیڈ ورکس: سلیمانکی اور اسلام
• یہ اُچ شریف کے قریب چناب سے مل کر پنجند بناتا ہے۔
• راوی کی طرح اسے بھی سندھ طاس معاہدہ (1960) کے تحت بھارت کو دیا گیا، اس لیے مون سون کے علاوہ پاکستان میں اس کا بہاؤ کم ہوتا ہے۔
"""),

    c("4.5",
"""
The Kabul River is the main western tributary of the Indus.

• Length: about 700 km
• Source: the Unai Pass in the Hindu Kush, Afghanistan
• It passes Kabul and Jalalabad and enters Pakistan near the Khyber area.
• It flows through the Peshawar valley and Nowshera.
• Tributaries: Swat, Panjkora and the Chitral (Kunar) river
• It joins the Indus near Attock.
• Warsak Dam is built on it near Peshawar.
• It carries more water in summer, when snow melts.
""",
"""
دریائے کابل دریائے سندھ کی اہم مغربی شاخ ہے۔

• لمبائی: تقریباً 700 کلومیٹر
• منبع: افغانستان میں ہندوکش کا درۂ اونائی
• یہ کابل اور جلال آباد سے گزر کر خیبر کے علاقے کے قریب پاکستان میں داخل ہوتا ہے۔
• یہ وادی پشاور اور نوشہرہ سے بہتا ہے۔
• شاخیں: سوات، پنجکوڑہ اور دریائے چترال (کنڑ)
• یہ اٹک کے قریب دریائے سندھ میں مل جاتا ہے۔
• وارسک ڈیم پشاور کے قریب اسی پر بنا ہے۔
• گرمیوں میں، جب برف پگھلتی ہے، اس میں پانی زیادہ ہوتا ہے۔
"""),

    c("4.6",
"""
The Swat River flows through the beautiful Swat Valley in Khyber Pakhtunkhwa.

• Length: about 240 km
• Source: formed near Kalam by the Ushu and Utror streams, fed by glaciers
• It flows through Madyan, Bahrain and Mingora, then through the Malakand area into the Peshawar valley.
• It joins the Kabul River near Charsadda.
• It is famous for its clear water and trout fishing.
• It irrigates the Swat and Peshawar valleys through the Upper and Lower Swat canals.
• Flood in 2010 caused heavy damage along its banks.
""",
"""
دریائے سوات خیبر پختونخوا کی خوبصورت وادی سوات سے بہتا ہے۔

• لمبائی: تقریباً 240 کلومیٹر
• منبع: کالام کے قریب گلیشیئروں سے بھرنے والے اوشو اور اتروڑ نالوں کے ملنے سے بنتا ہے
• یہ مدین، بحرین اور مینگورہ سے گزر کر ملاکنڈ کے علاقے سے وادی پشاور میں داخل ہوتا ہے۔
• یہ چارسدہ کے قریب دریائے کابل میں مل جاتا ہے۔
• یہ اپنے صاف پانی اور ٹراؤٹ مچھلی کے شکار کے لیے مشہور ہے۔
• یہ اپر اور لوئر سوات نہروں کے ذریعے سوات اور پشاور کی وادیوں کو سیراب کرتا ہے۔
• 2010 کے سیلاب نے اس کے کناروں پر شدید تباہی مچائی۔
"""),

    c("4.7",
"""
The Gomal is a river of the western highlands.

• It rises in the highlands of Afghanistan and flows into Pakistan through South Waziristan.
• It passes the Gomal Pass, an old trade route between Afghanistan and the Indus plain.
• It flows toward Dera Ismail Khan and joins the Indus in that region.
• It is largely a seasonal, flood-fed river that is dry for part of the year.
• Gomal Zam Dam, completed in 2013, stores its water for irrigation and electricity.
• The dam helps irrigate the dry lands of Tank and Dera Ismail Khan.
""",
"""
گومل مغربی بلند علاقوں کا دریا ہے۔

• یہ افغانستان کے بلند علاقوں سے نکلتا ہے اور جنوبی وزیرستان کے راستے پاکستان میں آتا ہے۔
• یہ درۂ گومل سے گزرتا ہے، جو افغانستان اور سندھ کے میدان کے درمیان پرانا تجارتی راستہ ہے۔
• یہ ڈیرہ اسماعیل خان کی طرف بہتا ہے اور اسی علاقے میں دریائے سندھ سے مل جاتا ہے۔
• یہ زیادہ تر موسمی، سیلابی پانی پر چلنے والا دریا ہے جو سال کے کچھ حصے میں خشک رہتا ہے۔
• گومل زام ڈیم، جو 2013 میں مکمل ہوا، اس کا پانی آبپاشی اور بجلی کے لیے ذخیرہ کرتا ہے۔
• یہ ڈیم ٹانک اور ڈیرہ اسماعیل خان کی خشک زمینوں کو سیراب کرنے میں مدد دیتا ہے۔
"""),

    c("4.8",
"""
Dams store river water for irrigation, electricity, flood control and drinking water.

• Tarbela (Indus): the largest dam of Pakistan and the world's largest earth-filled dam
• Mangla (Jhelum): the second major storage dam
• Warsak (Kabul): near Peshawar
• Chashma: a barrage and reservoir on the Indus
• Hub Dam (Hub River): water for Karachi
• Khanpur (Haro River), Rawal and Simly: water for Islamabad and Rawalpindi
• Gomal Zam (Gomal River)
• Under construction: Diamer-Bhasha, Mohmand and Dasu

Pakistan can store only a small part of its river flow, reportedly around 30 days of supply, so building more storage is a national priority.
""",
"""
ڈیم دریا کا پانی آبپاشی، بجلی، سیلاب پر قابو اور پینے کے پانی کے لیے ذخیرہ کرتے ہیں۔

• تربیلا (سندھ): پاکستان کا سب سے بڑا ڈیم اور دنیا کا سب سے بڑا مٹی بھرا ڈیم
• منگلا (جہلم): دوسرا بڑا ذخیرہ کرنے والا ڈیم
• وارسک (کابل): پشاور کے قریب
• چشمہ: دریائے سندھ پر بیراج اور آبی ذخیرہ
• حب ڈیم (دریائے حب): کراچی کے لیے پانی
• خانپور (دریائے ہرو)، راول اور سملی: اسلام آباد اور راولپنڈی کے لیے پانی
• گومل زام (دریائے گومل)
• زیر تعمیر: دیامر بھاشا، مہمند اور داسو

پاکستان اپنے دریاؤں کے بہاؤ کا صرف تھوڑا حصہ، بتایا جاتا ہے کہ تقریباً 30 دن کی ضرورت کے برابر، ذخیرہ کر سکتا ہے، اس لیے مزید ذخیرے بنانا قومی ترجیح ہے۔
"""),

    c("4.9",
"""
Tarbela Dam is the largest dam in Pakistan.

• River: the Indus
• Location: near Tarbela, Haripur district, Khyber Pakhtunkhwa
• Built: construction began in 1968 and it was completed in 1976
• Height: about 143 m
• It is the world's largest earth-filled dam by structural volume.
• Its lake covers about 250 km².
• Electricity: about 4,888 MW after the fourth extension (2018)
• It supplies water to the Indus plain and is also used for flood control.

Silt from the river slowly reduces its storage capacity.
""",
"""
تربیلا ڈیم پاکستان کا سب سے بڑا ڈیم ہے۔

• دریا: سندھ
• مقام: ضلع ہری پور، خیبر پختونخوا میں تربیلا کے قریب
• تعمیر: کام 1968 میں شروع ہوا اور 1976 میں مکمل ہوا
• اونچائی: تقریباً 143 میٹر
• یہ ساخت کے حجم کے لحاظ سے دنیا کا سب سے بڑا مٹی بھرا ڈیم ہے۔
• اس کی جھیل تقریباً 250 مربع کلومیٹر پر پھیلی ہے۔
• بجلی: چوتھی توسیع (2018) کے بعد تقریباً 4,888 میگاواٹ
• یہ سندھ کے میدان کو پانی دیتا ہے اور سیلاب پر قابو کے لیے بھی استعمال ہوتا ہے۔

دریا کی گاد اس کی ذخیرہ کرنے کی صلاحیت کو آہستہ آہستہ کم کر رہی ہے۔
"""),

    c("4.10",
"""
Mangla Dam is the second largest dam of Pakistan.

• River: the Jhelum
• Location: near Mirpur, Azad Jammu & Kashmir
• Completed: 1967, as part of the Indus Basin Project
• Height: about 147 m (an earth-filled dam)
• Electricity: about 1,000 MW
• Raised in 2009 to increase its water storage.
• It stores water for irrigation in Punjab and supplies electricity to the national grid.
• Mangla Lake is a popular place for boating and fishing.
""",
"""
منگلا ڈیم پاکستان کا دوسرا بڑا ڈیم ہے۔

• دریا: جہلم
• مقام: میرپور، آزاد جموں و کشمیر کے قریب
• تکمیل: 1967، منصوبۂ سندھ طاس کے حصے کے طور پر
• اونچائی: تقریباً 147 میٹر (مٹی بھرا ڈیم)
• بجلی: تقریباً 1,000 میگاواٹ
• 2009 میں اس کی اونچائی بڑھائی گئی تاکہ پانی کا ذخیرہ زیادہ ہو۔
• یہ پنجاب میں آبپاشی کے لیے پانی ذخیرہ کرتا ہے اور قومی گرڈ کو بجلی دیتا ہے۔
• منگلا جھیل کشتی رانی اور مچھلی کے شکار کے لیے مقبول ہے۔
"""),

    c("4.11",
"""
Warsak Dam is built on the Kabul River, about 30 km north-west of Peshawar.

• Completed: 1960, with Canadian help under the Colombo Plan
• Type: concrete gravity dam, about 76 m high
• Electricity: about 243 MW
• It irrigates the Peshawar valley and nearby districts.
• It was the first major dam built on the Kabul River in Pakistan.
• Warsak Lake is a local picnic spot.
""",
"""
وارسک ڈیم دریائے کابل پر، پشاور سے تقریباً 30 کلومیٹر شمال مغرب میں بنا ہے۔

• تکمیل: 1960، کولمبو پلان کے تحت کینیڈا کی مدد سے
• قسم: کنکریٹ کا کشش ثقل ڈیم، تقریباً 76 میٹر بلند
• بجلی: تقریباً 243 میگاواٹ
• یہ وادی پشاور اور قریبی اضلاع کو سیراب کرتا ہے۔
• یہ پاکستان میں دریائے کابل پر بننے والا پہلا بڑا ڈیم تھا۔
• وارسک جھیل مقامی لوگوں کی سیر کی جگہ ہے۔
"""),

    c("4.12",
"""
A barrage is a structure with gates across a river. It raises the water level so that water can be sent into canals.

Important barrages and headworks:
• On the Indus: Jinnah, Chashma, Taunsa, Guddu, Sukkur and Kotri
• On the Chenab: Marala, Khanki, Qadirabad and Trimmu
• On the Jhelum: Rasul
• On the Panjnad: Panjnad Headworks
• On the Sutlej: Islam and Sulemanki

Sukkur Barrage, built in 1932, feeds seven large canals and is one of the biggest irrigation works in the world. Kotri Barrage is the last barrage before the sea.
""",
"""
بیراج دریا کے آر پار گیٹوں والا ڈھانچہ ہے۔ یہ پانی کی سطح بلند کرتا ہے تاکہ پانی نہروں میں بھیجا جا سکے۔

اہم بیراج اور ہیڈ ورکس:
• دریائے سندھ پر: جناح، چشمہ، تونسہ، گدو، سکھر اور کوٹری
• چناب پر: مرالہ، خانکی، قادرآباد اور تریموں
• جہلم پر: رسول
• پنجند پر: ہیڈ پنجند
• ستلج پر: اسلام اور سلیمانکی

سکھر بیراج، جو 1932 میں بنا، سات بڑی نہروں کو پانی دیتا ہے اور دنیا کے بڑے آبپاشی منصوبوں میں سے ہے۔ کوٹری بیراج سمندر سے پہلے آخری بیراج ہے۔
"""),

    c("4.13",
"""
Pakistan has one of the largest canal irrigation systems in the world, with tens of thousands of kilometres of canals.

Types of canals:
• Perennial canals: carry water all year from barrages.
• Inundation canals: carry water only when the rivers are in flood.
• Link canals: move water between rivers.

Link canals built after the Indus Waters Treaty include Marala–Ravi, Rasul–Qadirabad, Chashma–Jhelum and Taunsa–Panjnad.

Well-known canals: Upper Bari Doab Canal, Lower Chenab Canal, Pat Feeder, Rohri Canal and Ghotki Feeder.
""",
"""
پاکستان میں دنیا کے بڑے نہری آبپاشی نظاموں میں سے ایک ہے، جس میں ہزاروں کلومیٹر نہریں ہیں۔

نہروں کی اقسام:
• بارہ ماہی نہریں: بیراجوں سے سارا سال پانی لاتی ہیں۔
• سیلابی نہریں: صرف دریاؤں میں سیلاب کے وقت پانی لاتی ہیں۔
• رابطہ نہریں: دریاؤں کے درمیان پانی منتقل کرتی ہیں۔

سندھ طاس معاہدے کے بعد بنائی گئی رابطہ نہروں میں مرالہ راوی، رسول قادرآباد، چشمہ جہلم اور تونسہ پنجند شامل ہیں۔

مشہور نہریں: اپر باری دوآب کینال، لوئر چناب کینال، پٹ فیڈر، روہڑی کینال اور گھوٹکی فیڈر۔
"""),

    c("4.14",
"""
Pakistan's water comes mainly from the Indus river system, fed by snow, glaciers and monsoon rain.

The Indus Basin Irrigation System includes about:
• 3 major reservoirs: Tarbela, Mangla and Chashma
• 19 barrages and headworks
• 12 link canals
• Tens of thousands of kilometres of canals and many watercourses

Indus Waters Treaty (1960): the eastern rivers (Ravi, Beas and Sutlej) went to India, and the western rivers (Indus, Jhelum and Chenab) went to Pakistan.

About 90% of water is used for agriculture. Tubewells add groundwater.

Problems: waterlogging and salinity, water lost from canals, low storage, and falling water per person as the population grows.
""",
"""
پاکستان کا پانی بنیادی طور پر دریائے سندھ کے نظام سے آتا ہے، جسے برف، گلیشیئر اور مون سون کی بارش پانی دیتی ہے۔

سندھ طاس آبپاشی نظام میں تقریباً شامل ہیں:
• 3 بڑے آبی ذخائر: تربیلا، منگلا اور چشمہ
• 19 بیراج اور ہیڈ ورکس
• 12 رابطہ نہریں
• ہزاروں کلومیٹر نہریں اور بہت سے کھال

سندھ طاس معاہدہ (1960): مشرقی دریا (راوی، بیاس اور ستلج) بھارت کو اور مغربی دریا (سندھ، جہلم اور چناب) پاکستان کو ملے۔

تقریباً 90 فیصد پانی زراعت میں استعمال ہوتا ہے۔ ٹیوب ویل زیر زمین پانی کا اضافہ کرتے ہیں۔

مسائل: زمین میں پانی جمع ہونا اور کھاری پن، نہروں سے پانی کا ضیاع، کم ذخیرہ، اور آبادی بڑھنے سے فی کس پانی میں کمی۔
"""),

    // ================= TOPIC 5 =================
    c("5.0",
"""
Pakistan has four main seasons. Summer is the hot, dry season before the monsoon, roughly April to June.

• Plains: temperatures often reach 40–47°C, and parts of Sindh and Balochistan go above 50°C.
• Hot dry winds called "loo" blow across Punjab and Sindh.
• Dust storms are common before the monsoon.
• May and June are the hottest months.
• Mountain regions stay cool and pleasant, so many people travel north.
• Snow melts in summer and fills the rivers.
• Demand for water and electricity rises sharply.

Pakistan's seasons: summer (April–June), monsoon (July–September), post-monsoon (October–November) and winter (December–March).
""",
"""
پاکستان میں چار بڑے موسم ہوتے ہیں۔ گرمی مون سون سے پہلے کا گرم خشک موسم ہے، تقریباً اپریل سے جون۔

• میدان: درجہ حرارت اکثر 40 سے 47 ڈگری سینٹی گریڈ تک پہنچ جاتا ہے، اور سندھ اور بلوچستان کے کچھ حصوں میں 50 ڈگری سے بھی اوپر چلا جاتا ہے۔
• "لو" کہلانے والی گرم خشک ہوائیں پنجاب اور سندھ میں چلتی ہیں۔
• مون سون سے پہلے آندھیاں اور گرد کے طوفان عام ہیں۔
• مئی اور جون سب سے گرم مہینے ہیں۔
• پہاڑی علاقے ٹھنڈے اور خوشگوار رہتے ہیں، اسی لیے بہت سے لوگ شمال کا رخ کرتے ہیں۔
• گرمیوں میں برف پگھل کر دریاؤں کو بھر دیتی ہے۔
• پانی اور بجلی کی طلب تیزی سے بڑھ جاتی ہے۔

پاکستان کے موسم: گرمی (اپریل تا جون)، مون سون (جولائی تا ستمبر)، مون سون کے بعد (اکتوبر تا نومبر) اور سردی (دسمبر تا مارچ)۔
"""),

    c("5.1",
"""
Winter lasts roughly from December to March.

• Plains: cool to cold, with daytime temperatures of about 15–22°C and cold nights.
• Dense fog is common in Punjab and northern Sindh in December and January.
• Northern mountains: heavy snow and temperatures below freezing.
• Quetta and the Balochistan highlands: very cold, often below 0°C at night.
• Murree, Swat, Gilgit, Skardu and Chitral receive snowfall.
• Karachi stays mild because of the sea.
• Winter rain and snow come mainly from western disturbances and are important for wheat.
""",
"""
سردی کا موسم تقریباً دسمبر سے مارچ تک رہتا ہے۔

• میدان: ٹھنڈا سے سرد، دن کا درجہ حرارت تقریباً 15 سے 22 ڈگری اور راتیں ٹھنڈی
• دسمبر اور جنوری میں پنجاب اور شمالی سندھ میں گہری دھند عام ہوتی ہے۔
• شمالی پہاڑ: شدید برف باری اور نقطۂ انجماد سے کم درجہ حرارت
• کوئٹہ اور بلوچستان کے بلند علاقے: بہت سرد، رات کو اکثر صفر ڈگری سے نیچے
• مری، سوات، گلگت، اسکردو اور چترال میں برف باری ہوتی ہے۔
• کراچی سمندر کی وجہ سے معتدل رہتا ہے۔
• سردیوں کی بارش اور برف باری زیادہ تر مغربی ہواؤں سے ہوتی ہے اور گندم کے لیے اہم ہے۔
"""),

    c("5.2",
"""
The monsoon brings most of Pakistan's rain, roughly from July to September.

• It is caused by moist winds from the Arabian Sea and Bay of Bengal.
• Rain is heaviest in the north-east: Kashmir, Murree, Islamabad and Rawalpindi.
• It becomes lighter toward the south-west, so Sindh and Balochistan get little.
• It fills rivers and supports Kharif crops such as rice and cotton.
• Heavy monsoon rain can cause floods, as in 2010 and 2022, which affected millions of people.
• Urban flooding and landslides in the mountains are also common.
• Monsoon behaviour is changing with climate change, with more extreme spells.
""",
"""
مون سون پاکستان کی زیادہ تر بارش لاتا ہے، تقریباً جولائی سے ستمبر تک۔

• اس کا سبب بحیرہ عرب اور خلیج بنگال سے آنے والی نم ہوائیں ہیں۔
• بارش شمال مشرق میں سب سے زیادہ ہوتی ہے: کشمیر، مری، اسلام آباد اور راولپنڈی۔
• جنوب مغرب کی طرف یہ کم ہوتی جاتی ہے، اس لیے سندھ اور بلوچستان میں کم بارش ہوتی ہے۔
• یہ دریاؤں کو بھرتی ہے اور چاول اور کپاس جیسی خریف فصلوں میں مدد دیتی ہے۔
• شدید مون سون بارشیں سیلاب لا سکتی ہیں، جیسے 2010 اور 2022 میں، جن سے لاکھوں لوگ متاثر ہوئے۔
• شہری سیلاب اور پہاڑوں میں لینڈ سلائیڈنگ بھی عام ہیں۔
• موسمیاتی تبدیلی کے ساتھ مون سون کا انداز بدل رہا ہے اور شدید دورے بڑھ رہے ہیں۔
"""),

    c("5.3",
"""
Western disturbances are low-pressure weather systems that travel from the Mediterranean and Caspian regions toward Pakistan.

• Season: mainly December to March
• They bring winter rain to the plains and snow to the mountains.
• Areas affected: Chitral, Swat, Gilgit-Baltistan, Potohar, Quetta and northern Punjab
• The rain helps the Rabi crops, especially wheat.
• Snow that falls in the mountains melts later and feeds the rivers.
• They can also bring cold waves, hailstorms, floods and avalanches.
• Weak winters with few disturbances can lead to drought.
""",
"""
مغربی ہوائیں (ویسٹرن ڈسٹربنس) کم دباؤ کے موسمی نظام ہیں جو بحیرہ روم اور بحیرہ کیسپین کے علاقوں سے پاکستان کی طرف آتے ہیں۔

• موسم: زیادہ تر دسمبر سے مارچ
• یہ میدانوں میں سردیوں کی بارش اور پہاڑوں میں برف لاتے ہیں۔
• متاثرہ علاقے: چترال، سوات، گلگت بلتستان، پوٹھوہار، کوئٹہ اور شمالی پنجاب
• یہ بارش ربیع کی فصلوں، خاص طور پر گندم، کو فائدہ دیتی ہے۔
• پہاڑوں پر پڑنے والی برف بعد میں پگھل کر دریاؤں کو بھرتی ہے۔
• یہ سرد لہریں، اولے، سیلاب اور برفانی تودے بھی لا سکتے ہیں۔
• کم ویسٹرن ڈسٹربنس والی کمزور سردیاں خشک سالی کا سبب بن سکتی ہیں۔
"""),

    c("5.4",
"""
Desert climate is found in the Thar, Cholistan, Thal and Kharan deserts and in much of southern Balochistan.

• Rainfall: very low, often less than 250 mm a year, and uncertain
• Days are very hot (up to 45–50°C in summer) and nights are much cooler.
• The difference between day and night temperatures is large.
• Winds blow dust and sand, forming dunes.
• Evaporation is high and the air is dry.
• Plants are sparse and drought-resistant, such as khejri, kikar and thorny shrubs.
• Water comes from wells, tanks (called "tobas") and rain.
""",
"""
صحرائی آب و ہوا تھر، چولستان، تھل اور خاران کے صحراؤں اور جنوبی بلوچستان کے بڑے حصے میں پائی جاتی ہے۔

• بارش: بہت کم، اکثر سالانہ 250 ملی میٹر سے کم، اور غیر یقینی
• دن بہت گرم (گرمیوں میں 45 سے 50 ڈگری تک) اور راتیں کہیں زیادہ ٹھنڈی ہوتی ہیں۔
• دن اور رات کے درجہ حرارت میں بڑا فرق ہوتا ہے۔
• ہوائیں گرد اور ریت اڑاتی ہیں اور ٹیلے بناتی ہیں۔
• بخارات زیادہ بنتے ہیں اور ہوا خشک ہوتی ہے۔
• پودے کم اور خشک سالی برداشت کرنے والے ہوتے ہیں، جیسے کھیجڑی، کیکر اور کانٹے دار جھاڑیاں۔
• پانی کنوؤں، ٹوبوں اور بارش سے ملتا ہے۔
"""),

    c("5.5",
"""
In the mountains the climate changes with height. Temperature drops about 6.5°C for every 1,000 m you climb.

• Above roughly 4,500–5,000 m there is permanent snow and ice.
• Summers in valleys are mild and winters are very cold, with heavy snow.
• Hill stations such as Murree, Nathia Gali, Ziarat and Kalam are cool in summer.
• Rainfall depends on the slope: the Himalayan foothills (Murree, Kaghan) are wet, while inner valleys such as Gilgit and Hunza are dry because high ranges block the rain.
• Quetta, at about 1,680 m, has cold winters and warm dry summers.
• Mountain snow and glaciers are Pakistan's main natural water storage.
""",
"""
پہاڑوں میں آب و ہوا بلندی کے ساتھ بدلتی ہے۔ ہر 1,000 میٹر اوپر جانے پر درجہ حرارت تقریباً 6.5 ڈگری کم ہو جاتا ہے۔

• تقریباً 4,500 سے 5,000 میٹر سے اوپر مستقل برف رہتی ہے۔
• وادیوں میں گرمیاں معتدل اور سردیاں بہت سرد اور برفیلی ہوتی ہیں۔
• مری، نتھیا گلی، زیارت اور کالام جیسے پہاڑی مقامات گرمیوں میں ٹھنڈے رہتے ہیں۔
• بارش ڈھلوان پر منحصر ہے: ہمالیہ کے دامن (مری، کاغان) میں زیادہ بارش ہوتی ہے، جبکہ گلگت اور ہنزہ جیسی اندرونی وادیاں خشک ہیں کیونکہ بلند سلسلے بارش روک لیتے ہیں۔
• کوئٹہ، تقریباً 1,680 میٹر بلند، میں سردیاں سرد اور گرمیاں گرم خشک ہوتی ہیں۔
• پہاڑوں کی برف اور گلیشیئر پاکستان کا بنیادی قدرتی آبی ذخیرہ ہیں۔
"""),

    c("5.6",
"""
The hottest parts of Pakistan lie in the south and the lower Indus plain.

• Jacobabad (Sindh): among the hottest cities on Earth
• Sibi (Balochistan), Dadu, Larkana and Mohenjo-daro area (Sindh)
• Turbat (Balochistan): a reading of about 53.7°C was reported in May 2017.
• Multan, Bahawalpur and Dera Ghazi Khan (Punjab)
• Summer temperatures commonly pass 45°C in these places.

Heatwaves are becoming more frequent and put health, crops and electricity supply under pressure.
""",
"""
پاکستان کے گرم ترین علاقے جنوب اور زیریں وادیٔ سندھ میں ہیں۔

• جیکب آباد (سندھ): دنیا کے گرم ترین شہروں میں سے ایک
• سبی (بلوچستان)، دادو، لاڑکانہ اور موہنجو داڑو کا علاقہ (سندھ)
• تربت (بلوچستان): مئی 2017 میں تقریباً 53.7 ڈگری کا درجہ حرارت رپورٹ ہوا۔
• ملتان، بہاولپور اور ڈیرہ غازی خان (پنجاب)
• ان جگہوں پر گرمیوں میں درجہ حرارت عموماً 45 ڈگری سے اوپر جاتا ہے۔

ہیٹ ویو اب زیادہ بار آ رہی ہے اور صحت، فصلوں اور بجلی کی فراہمی پر دباؤ ڈالتی ہے۔
"""),

    c("5.7",
"""
The coldest parts of Pakistan are in the high north and the western highlands.

• Gilgit-Baltistan: Skardu, Astore and Deosai often fall to −10°C or lower in winter, and the high valleys can be much colder.
• Karakoram glaciers such as Siachen: extremely cold, with temperatures far below −30°C.
• Chitral and the Hindu Kush valleys
• Balochistan highlands: Quetta, Ziarat, Kalat and Zhob have freezing winter nights.
• Murree and the Galiyat get heavy snow, but are less cold.

Cold waves can block roads and passes in winter.
""",
"""
پاکستان کے سرد ترین علاقے بلند شمال اور مغربی بلند علاقوں میں ہیں۔

• گلگت بلتستان: اسکردو، استور اور دیوسائی میں سردیوں میں درجہ حرارت اکثر منفی 10 ڈگری یا اس سے کم ہو جاتا ہے، اور بلند وادیوں میں اس سے بھی زیادہ سردی ہوتی ہے۔
• سیاچن جیسے قراقرم کے گلیشیئر: انتہائی سرد، درجہ حرارت منفی 30 ڈگری سے بہت نیچے
• چترال اور ہندوکش کی وادیاں
• بلوچستان کے بلند علاقے: کوئٹہ، زیارت، قلات اور ژوب میں سردیوں کی راتیں نقطۂ انجماد سے نیچے ہوتی ہیں۔
• مری اور گلیات میں شدید برف باری ہوتی ہے، مگر سردی نسبتاً کم ہوتی ہے۔

سرد لہریں سردیوں میں سڑکیں اور درے بند کر سکتی ہیں۔
"""),

    c("5.8",
"""
Rainfall in Pakistan is very uneven. Most of the country is arid or semi-arid.

Approximate annual rainfall:
• Murree and Kashmir foothills: about 1,500–1,800 mm (the wettest)
• Islamabad and Rawalpindi: about 1,000–1,200 mm
• Lahore: about 600–700 mm
• Quetta: about 250 mm
• Karachi: about 200 mm
• Gilgit: about 130 mm
• Jacobabad and the Thar and Kharan deserts: about 100 mm or less (the driest)

Pattern: rain decreases from north-east to south-west. Most rain falls in the monsoon (July–September); winter rain comes from western disturbances.
""",
"""
پاکستان میں بارش بہت غیر مساوی ہے۔ ملک کا زیادہ تر حصہ خشک یا نیم خشک ہے۔

تقریبی سالانہ بارش:
• مری اور کشمیر کے دامن: تقریباً 1,500 سے 1,800 ملی میٹر (سب سے زیادہ)
• اسلام آباد اور راولپنڈی: تقریباً 1,000 سے 1,200 ملی میٹر
• لاہور: تقریباً 600 سے 700 ملی میٹر
• کوئٹہ: تقریباً 250 ملی میٹر
• کراچی: تقریباً 200 ملی میٹر
• گلگت: تقریباً 130 ملی میٹر
• جیکب آباد اور تھر اور خاران کے صحرا: تقریباً 100 ملی میٹر یا اس سے کم (سب سے خشک)

انداز: بارش شمال مشرق سے جنوب مغرب کی طرف کم ہوتی جاتی ہے۔ زیادہ تر بارش مون سون (جولائی تا ستمبر) میں ہوتی ہے؛ سردیوں کی بارش مغربی ہواؤں سے آتی ہے۔
""")
)

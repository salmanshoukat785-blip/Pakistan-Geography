package com.pakgeo.app

// Topic 11: Coastal and marine, Topic 12: Population, Topic 13: Disasters and environment
val contentPart6: Map<String, Pair<String, String>> = mapOf(
    // ================= TOPIC 11 =================
    c("11.0",
"""
The Arabian Sea is part of the Indian Ocean. Pakistan lies on its northern shore.

• It is bordered by Pakistan, Iran, Oman, Yemen, Somalia and India.
• Pakistan's exclusive economic zone (EEZ) is about 240,000 km².
• The Gulf of Oman links it to the Persian Gulf through the Strait of Hormuz.
• Monsoon winds change direction with the season and bring rain to South Asia.
• Winds also lift nutrient-rich water, which makes the sea rich in fish.
• Busy shipping lanes carry much of the world's oil and trade.
• Cyclones sometimes form here and hit the coast of Pakistan, Oman and India.
""",
"""
بحیرہ عرب بحر ہند کا حصہ ہے۔ پاکستان اس کے شمالی کنارے پر واقع ہے۔

• اس کے ساتھ پاکستان، ایران، عمان، یمن، صومالیہ اور بھارت کی سرحدیں ہیں۔
• پاکستان کا خصوصی اقتصادی زون (ای ای زیڈ) تقریباً 240,000 مربع کلومیٹر ہے۔
• خلیج عمان اسے آبنائے ہرمز کے ذریعے خلیج فارس سے ملاتی ہے۔
• موسمی ہوائیں موسم کے ساتھ رخ بدلتی ہیں اور جنوبی ایشیا میں بارش لاتی ہیں۔
• ہوائیں غذائیت سے بھرپور پانی کو اوپر لاتی ہیں، جس سے سمندر مچھلی سے مالا مال ہے۔
• مصروف بحری راستے دنیا کے تیل اور تجارت کا بڑا حصہ لے جاتے ہیں۔
• یہاں کبھی کبھی سمندری طوفان بنتے ہیں جو پاکستان، عمان اور بھارت کے ساحل سے ٹکراتے ہیں۔
"""),

    c("11.1",
"""
Pakistan's coastline is about 1,046 km long, from Sir Creek near the Indian border to Jiwani near the Iranian border.

• Sindh coast: about 270 km, with creeks and the Indus Delta
• Balochistan (Makran) coast: about 770 km
• Important places: Karachi, Port Qasim, Ormara, Pasni, Gwadar and Jiwani
• Offshore: Astola Island
• Climate: hot and humid, with little rain
• Fishing is the main livelihood of coastal people.
• The Makran Coastal Highway connects Karachi with Gwadar.
""",
"""
پاکستان کی ساحلی پٹی تقریباً 1,046 کلومیٹر لمبی ہے، بھارتی سرحد کے قریب سر کریک سے ایرانی سرحد کے قریب جیوانی تک۔

• سندھ کا ساحل: تقریباً 270 کلومیٹر، کھاڑیوں اور دریائے سندھ کے ڈیلٹا کے ساتھ
• بلوچستان (مکران) کا ساحل: تقریباً 770 کلومیٹر
• اہم مقامات: کراچی، پورٹ قاسم، اورماڑہ، پسنی، گوادر اور جیوانی
• سمندر میں: جزیرہ استولا
• آب و ہوا: گرم مرطوب، کم بارش
• ماہی گیری ساحلی لوگوں کا بنیادی ذریعۂ معاش ہے۔
• مکران کوسٹل ہائی وے کراچی کو گوادر سے ملاتی ہے۔
"""),

    c("11.2",
"""
Karachi Port is Pakistan's oldest and busiest seaport.

• Location: on the Arabian Sea, a natural harbour sheltered by Manora Island
• Developed under British rule; the Karachi Port Trust was set up in 1887.
• It handles a large part of the country's sea trade, including containers, oil and grain.
• Terminals are at Keamari and in the Karachi Port area.
• The Karachi Shipyard and fish harbour are nearby.
• Together with Port Qasim, it handles most of Pakistan's import and export cargo.
""",
"""
کراچی بندرگاہ پاکستان کی سب سے پرانی اور مصروف ترین بندرگاہ ہے۔

• مقام: بحیرہ عرب پر، منوڑا جزیرے سے محفوظ ایک قدرتی بندرگاہ
• برطانوی دور میں ترقی دی گئی؛ کراچی پورٹ ٹرسٹ 1887 میں بنا۔
• یہ ملک کی سمندری تجارت کا بڑا حصہ سنبھالتی ہے، جس میں کنٹینر، تیل اور اناج شامل ہیں۔
• ٹرمینل کیماڑی اور کراچی پورٹ کے علاقے میں ہیں۔
• کراچی شپ یارڈ اور فش ہاربر قریب ہی ہیں۔
• پورٹ قاسم کے ساتھ مل کر یہ پاکستان کے زیادہ تر درآمدی اور برآمدی مال کو سنبھالتی ہے۔
"""),

    c("11.3",
"""
Gwadar Port is a deep-water port in Balochistan, on the Makran coast.

• Gwadar was bought from Oman and became part of Pakistan in 1958.
• The modern port was built in the 2000s with Chinese help and is a key part of CPEC.
• It is a deep-water port, so large ships can enter.
• A Chinese company has run its terminals since 2013.
• Location: a few hundred kilometres from the Strait of Hormuz, an important sea route
• It is meant to serve trade for Pakistan, China and Central Asia, and has a free zone.
""",
"""
گوادر بندرگاہ بلوچستان میں ساحل مکران پر ایک گہرے پانی کی بندرگاہ ہے۔

• گوادر عمان سے خریدا گیا اور 1958 میں پاکستان کا حصہ بنا۔
• جدید بندرگاہ 2000 کی دہائی میں چین کی مدد سے بنی اور سی پیک کا اہم حصہ ہے۔
• یہ گہرے پانی کی بندرگاہ ہے، اس لیے بڑے جہاز داخل ہو سکتے ہیں۔
• ایک چینی کمپنی 2013 سے اس کے ٹرمینل چلا رہی ہے۔
• مقام: آبنائے ہرمز، ایک اہم بحری راستے، سے چند سو کلومیٹر دور
• اس کا مقصد پاکستان، چین اور وسطی ایشیا کی تجارت کی خدمت ہے، اور یہاں فری زون بھی ہے۔
"""),

    c("11.4",
"""
Port Qasim is Pakistan's second major seaport, on the creeks near Karachi.

• Named after Muhammad bin Qasim
• Set up in 1973 and operating since 1980
• Location: about 40 km from the centre of Karachi
• It handles bulk cargo such as coal, cement, steel and chemicals.
• LNG terminals at Port Qasim bring liquefied natural gas into Pakistan.
• Steel mills and industrial zones stand beside it.
• It has deep channels suitable for large ships.
""",
"""
پورٹ قاسم پاکستان کی دوسری بڑی بندرگاہ ہے، جو کراچی کے قریب کھاڑیوں پر واقع ہے۔

• نام محمد بن قاسم کے نام پر رکھا گیا
• 1973 میں قائم ہوئی اور 1980 سے کام کر رہی ہے
• مقام: کراچی کے مرکز سے تقریباً 40 کلومیٹر
• یہ کوئلہ، سیمنٹ، فولاد اور کیمیکلز جیسا تھوک مال سنبھالتی ہے۔
• پورٹ قاسم کے ایل این جی ٹرمینل مائع قدرتی گیس پاکستان لاتے ہیں۔
• اس کے ساتھ اسٹیل ملیں اور صنعتی زون ہیں۔
• اس کے گہرے راستے بڑے جہازوں کے لیے موزوں ہیں۔
"""),

    c("11.5",
"""
The Makran coast is the long western part of Pakistan's coastline, in Balochistan, running toward the Iranian border.

• Towns: Sonmiani, Ormara, Pasni, Gwadar and Jiwani
• Landscape: dry coastal plains, cliffs, sand and mud flats
• Famous features: Kund Malir beach, the "Princess of Hope" rock formation and mud volcanoes near Hingol
• Hingol National Park lies along the coast.
• The Makran Coastal Highway runs along it.
• Fishing is the main occupation.
• It lies above a subduction zone; the 1945 earthquake caused a tsunami here.
""",
"""
ساحل مکران پاکستان کی ساحلی پٹی کا لمبا مغربی حصہ ہے، جو بلوچستان میں ایرانی سرحد کی طرف جاتا ہے۔

• شہر: سونمیانی، اورماڑہ، پسنی، گوادر اور جیوانی
• منظر: خشک ساحلی میدان، چٹانیں، ریت اور کیچڑ کے میدان
• مشہور مقامات: کنڈ ملیر کا ساحل، "پرنسس آف ہوپ" چٹانی ساخت اور ہنگول کے قریب کیچڑ کے آتش فشاں
• ہنگول نیشنل پارک ساحل کے ساتھ ہے۔
• مکران کوسٹل ہائی وے اس کے ساتھ چلتی ہے۔
• ماہی گیری بنیادی پیشہ ہے۔
• یہ ایک سبڈکشن زون کے اوپر واقع ہے؛ 1945 کے زلزلے نے یہاں سونامی پیدا کی۔
"""),

    c("11.6",
"""
The Indus Delta is where the Indus River meets the Arabian Sea, in Thatta and Sujawal districts of Sindh.

• Area: about 41,000 km², one of the world's large river deltas
• Creeks: many channels and creeks, and large mangrove forests
• Keti Bandar is an old delta port.
• The delta feeds fish, shrimp and crab, and shelters birds and wildlife.
• Problem: much less fresh water and silt now reach the sea because of dams and canals, so the sea has moved inland and the land has become salty.
• Villages and farmland have been lost, and many people have migrated.
• It is a Ramsar wetland.
""",
"""
دریائے سندھ کا ڈیلٹا وہ جگہ ہے جہاں دریائے سندھ بحیرہ عرب سے ملتا ہے، سندھ کے اضلاع ٹھٹھہ اور سجاول میں۔

• رقبہ: تقریباً 41,000 مربع کلومیٹر، دنیا کے بڑے دریائی ڈیلٹاؤں میں سے ایک
• کھاڑیاں: بہت سی نالیاں اور کھاڑیاں، اور مینگرو کے بڑے جنگلات
• کیٹی بندر ڈیلٹا کی ایک پرانی بندرگاہ ہے۔
• ڈیلٹا مچھلی، جھینگے اور کیکڑے پالتا ہے، اور پرندوں اور جنگلی حیات کو پناہ دیتا ہے۔
• مسئلہ: ڈیموں اور نہروں کی وجہ سے اب سمندر تک میٹھا پانی اور گاد بہت کم پہنچتی ہے، اس لیے سمندر اندر کی طرف بڑھ آیا ہے اور زمین کھاری ہو گئی ہے۔
• گاؤں اور کھیت ختم ہوئے ہیں اور بہت سے لوگ نقل مکانی کر گئے ہیں۔
• یہ رامسر آبی علاقہ ہے۔
"""),

    c("11.7",
"""
Pakistan has several islands along its coast.

• Astola (Haft Talar): the largest offshore island, off the Balochistan coast near Pasni; an uninhabited island and a nesting site for green turtles; a protected area
• Churna Island: near Hub, a popular spot for diving and snorkelling
• Manora: near Karachi harbour, joined to the mainland by a causeway
• Bundal and Buddo: islands near Karachi in the mangrove area
• Many small islands lie in the creeks of the Indus Delta.

Islands support fishing, turtles, seabirds and tourism.
""",
"""
پاکستان کے ساحل کے ساتھ کئی جزیرے ہیں۔

• استولا (ہفت تلار): سب سے بڑا سمندری جزیرہ، پسنی کے قریب بلوچستان کے ساحل کے پاس؛ غیر آباد جزیرہ اور سبز کچھوؤں کے انڈے دینے کی جگہ؛ ایک محفوظ علاقہ
• چرنا جزیرہ: حب کے قریب، غوطہ خوری اور اسنارکلنگ کے لیے مقبول
• منوڑا: کراچی بندرگاہ کے قریب، ایک پشتے کے ذریعے خشکی سے جڑا
• بنڈل اور بدو: کراچی کے قریب مینگرو کے علاقے میں جزیرے
• دریائے سندھ کے ڈیلٹا کی کھاڑیوں میں بہت سے چھوٹے جزیرے ہیں۔

جزیرے ماہی گیری، کچھوؤں، سمندری پرندوں اور سیاحت کو سہارا دیتے ہیں۔
"""),

    c("11.8",
"""
The Arabian Sea gives Pakistan many marine resources.

• Fish: tuna, mackerel, sardines, pomfret and hilsa (palla)
• Shrimp, crab and lobster, which are exported
• Fish harbours: Karachi (the largest), Korangi, Gwadar, Pasni and Ormara
• Mangroves, which are nurseries for fish
• Salt, made by evaporating sea water
• Ship-breaking at Gadani, Balochistan
• Possible oil and gas offshore, still being explored
• Ports and shipping: most of the country's trade moves by sea.

Problems: overfishing, pollution and destructive nets.
""",
"""
بحیرہ عرب پاکستان کو بہت سے سمندری وسائل دیتا ہے۔

• مچھلی: ٹونا، میکرل، ساردین، پاپلیٹ اور پلا
• جھینگے، کیکڑے اور لابسٹر، جو برآمد ہوتے ہیں
• فش ہاربر: کراچی (سب سے بڑا)، کورنگی، گوادر، پسنی اور اورماڑہ
• مینگرو، جو مچھلی کی نرسری ہیں
• نمک، جو سمندری پانی کے بخارات سے بنتا ہے
• بلوچستان میں گڈانی پر جہاز توڑنے کی صنعت
• سمندر میں ممکنہ تیل اور گیس، جن کی تلاش جاری ہے
• بندرگاہیں اور جہاز رانی: ملک کی زیادہ تر تجارت سمندر کے ذریعے ہوتی ہے۔

مسائل: ضرورت سے زیادہ شکار، آلودگی اور نقصان دہ جال۔
"""),

    // ================= TOPIC 12 =================
    c("12.0",
"""
Pakistan is the fifth most populous country in the world.

• Population: about 241.5 million (2023 census)
• Earlier censuses: about 132 million (1998) and 208 million (2017)
• Growth rate: about 2.5% a year (2017–2023)
• Approximate shares: Punjab 53%, Sindh 23%, Khyber Pakhtunkhwa 17%, Balochistan 6%, Islamabad about 1%
• Young population: about two-thirds of Pakistanis are under 30.
• Urban population is about 39% and rural about 61%.
""",
"""
پاکستان آبادی کے لحاظ سے دنیا کا پانچواں بڑا ملک ہے۔

• آبادی: تقریباً 24.15 کروڑ (مردم شماری 2023)
• پچھلی مردم شماریاں: تقریباً 13.2 کروڑ (1998) اور 20.8 کروڑ (2017)
• شرح نمو: سالانہ تقریباً 2.5 فیصد (2017 تا 2023)
• تقریباً حصے: پنجاب 53 فیصد، سندھ 23 فیصد، خیبر پختونخوا 17 فیصد، بلوچستان 6 فیصد، اسلام آباد تقریباً 1 فیصد
• نوجوان آبادی: تقریباً دو تہائی پاکستانی 30 سال سے کم عمر ہیں۔
• شہری آبادی تقریباً 39 فیصد اور دیہی تقریباً 61 فیصد ہے۔
"""),

    c("12.1",
"""
Pakistan's population is spread very unevenly.

• Most people live in the Indus plain of Punjab and Sindh, where water and fertile land are available.
• The densest belt runs from Lahore through Faisalabad and Gujranwala to Sialkot.
• Large urban populations: Karachi, Lahore, Rawalpindi–Islamabad and Peshawar
• Thinly populated: the mountains of the north, the deserts and most of Balochistan.
• Balochistan is the largest province but has only about 6% of the people.
• Factors: water, soil, climate, jobs, transport and security.
""",
"""
پاکستان کی آبادی بہت غیر مساوی طور پر پھیلی ہوئی ہے۔

• زیادہ تر لوگ پنجاب اور سندھ کے میدان میں رہتے ہیں، جہاں پانی اور زرخیز زمین ہے۔
• سب سے گنجان پٹی لاہور سے فیصل آباد اور گوجرانوالہ ہوتے ہوئے سیالکوٹ تک جاتی ہے۔
• بڑی شہری آبادیاں: کراچی، لاہور، راولپنڈی اسلام آباد اور پشاور
• کم آباد: شمال کے پہاڑ، صحرا اور بلوچستان کا زیادہ تر حصہ
• بلوچستان سب سے بڑا صوبہ ہے مگر وہاں صرف تقریباً 6 فیصد لوگ ہیں۔
• عوامل: پانی، مٹی، آب و ہوا، روزگار، ذرائع نقل و حمل اور امن و امان۔
"""),

    c("12.2",
"""
Population density is the number of people per square kilometre.

• Pakistan overall: about 300 people per km²
• Islamabad: very high, over 2,500 per km²
• Punjab: about 620 per km² (highest among provinces)
• Khyber Pakhtunkhwa: about 400 per km²
• Sindh: about 400 per km²
• Balochistan: about 43 per km² (lowest among provinces)
• Gilgit-Baltistan: also very low
• Cities such as Karachi and Lahore have far higher densities than the provincial averages.

Figures are approximate.
""",
"""
آبادی کی کثافت فی مربع کلومیٹر افراد کی تعداد ہے۔

• پورا پاکستان: تقریباً 300 افراد فی مربع کلومیٹر
• اسلام آباد: بہت زیادہ، 2,500 فی مربع کلومیٹر سے اوپر
• پنجاب: تقریباً 620 فی مربع کلومیٹر (صوبوں میں سب سے زیادہ)
• خیبر پختونخوا: تقریباً 400 فی مربع کلومیٹر
• سندھ: تقریباً 400 فی مربع کلومیٹر
• بلوچستان: تقریباً 43 فی مربع کلومیٹر (صوبوں میں سب سے کم)
• گلگت بلتستان: بھی بہت کم
• کراچی اور لاہور جیسے شہروں کی کثافت صوبائی اوسط سے کہیں زیادہ ہے۔

اعداد تقریبی ہیں۔
"""),

    c("12.3",
"""
About 39% of Pakistanis live in towns and cities, and the share is growing.

• Karachi and Lahore have populations of more than 10 million each.
• People move to cities for jobs, schools and hospitals.
• Cities have factories, banks, universities and markets.
• Problems: overcrowding, housing shortage and informal settlements (katchi abadis)
• Traffic, air pollution, waste and water shortage
• Planning, public transport and housing are needed to manage growth.
""",
"""
تقریباً 39 فیصد پاکستانی قصبوں اور شہروں میں رہتے ہیں، اور یہ حصہ بڑھ رہا ہے۔

• کراچی اور لاہور کی آبادی ہر ایک کی 1 کروڑ سے زیادہ ہے۔
• لوگ روزگار، اسکولوں اور اسپتالوں کے لیے شہروں کا رخ کرتے ہیں۔
• شہروں میں کارخانے، بینک، جامعات اور بازار ہیں۔
• مسائل: ہجوم، رہائش کی کمی اور غیر رسمی بستیاں (کچی آبادیاں)
• ٹریفک، فضائی آلودگی، کچرا اور پانی کی کمی
• بڑھتی آبادی سنبھالنے کے لیے منصوبہ بندی، پبلک ٹرانسپورٹ اور رہائش ضروری ہیں۔
"""),

    c("12.4",
"""
About 61% of Pakistanis live in villages and rural areas.

• Most rural people depend on farming, livestock and related work.
• Rural families are usually larger, and many live in joint families.
• Services such as schools, hospitals, roads and clean water are often weaker than in cities.
• Incomes are lower and many young people move to cities or abroad.
• Floods, drought and price changes hit rural people hardest.
• Rural electrification, roads, small industries and better schools help development.
""",
"""
تقریباً 61 فیصد پاکستانی دیہات اور دیہی علاقوں میں رہتے ہیں۔

• زیادہ تر دیہی لوگ کاشت کاری، مویشیوں اور متعلقہ کاموں پر منحصر ہیں۔
• دیہی خاندان عموماً بڑے ہوتے ہیں اور بہت سے مشترکہ خاندانوں میں رہتے ہیں۔
• اسکول، اسپتال، سڑکیں اور صاف پانی جیسی سہولتیں اکثر شہروں سے کمزور ہوتی ہیں۔
• آمدنی کم ہے اور بہت سے نوجوان شہروں یا بیرون ملک چلے جاتے ہیں۔
• سیلاب، خشک سالی اور قیمتوں کی تبدیلی سب سے زیادہ دیہی لوگوں کو متاثر کرتی ہے۔
• دیہی بجلی، سڑکیں، چھوٹی صنعتیں اور بہتر اسکول ترقی میں مدد دیتے ہیں۔
"""),

    c("12.5",
"""
Pakistan's major cities and why they matter:

• Karachi: largest city, main port, financial and industrial centre
• Lahore: cultural and educational centre, with industry and history
• Islamabad: federal capital with government offices and embassies
• Rawalpindi: military headquarters and a trade centre
• Faisalabad: the textile and industrial city
• Multan: a trade centre for cotton, mangoes and shrines
• Peshawar: the gateway to Afghanistan and the Khyber Pass
• Quetta: the trade and military centre of Balochistan
• Hyderabad and Gujranwala: industrial and trade cities
""",
"""
پاکستان کے بڑے شہر اور ان کی اہمیت:

• کراچی: سب سے بڑا شہر، اہم بندرگاہ، مالیاتی اور صنعتی مرکز
• لاہور: ثقافتی اور تعلیمی مرکز، صنعت اور تاریخ کے ساتھ
• اسلام آباد: وفاقی دارالحکومت، سرکاری دفاتر اور سفارت خانوں کے ساتھ
• راولپنڈی: فوجی صدر دفاتر اور تجارتی مرکز
• فیصل آباد: ٹیکسٹائل اور صنعتی شہر
• ملتان: کپاس، آم اور مزارات کا تجارتی مرکز
• پشاور: افغانستان اور درۂ خیبر کا دروازہ
• کوئٹہ: بلوچستان کا تجارتی اور فوجی مرکز
• حیدرآباد اور گوجرانوالہ: صنعتی اور تجارتی شہر
"""),

    c("12.6",
"""
Migration means the movement of people from one place to another.

Kinds of migration:
• Rural to urban: people moving from villages to cities
• International: workers moving abroad, mainly to Saudi Arabia, the UAE, the UK, the USA and other countries
• Forced: after the 1947 Partition, because of conflict, and the arrival of Afghan refugees from 1979
• Seasonal and nomadic movements of herders
• Displacement caused by floods and other disasters

About 9 million Pakistanis live abroad, and their remittances are around 30 billion US dollars a year, one of the country's biggest sources of foreign money.

Push factors: poverty, unemployment, disasters. Pull factors: jobs, education and better services.
""",
"""
نقل مکانی کا مطلب لوگوں کا ایک جگہ سے دوسری جگہ جانا ہے۔

نقل مکانی کی اقسام:
• دیہات سے شہر: لوگوں کا گاؤں سے شہروں میں جانا
• بین الاقوامی: کارکنوں کا بیرون ملک جانا، خاص طور پر سعودی عرب، متحدہ عرب امارات، برطانیہ، امریکہ اور دیگر ممالک
• جبری: 1947 کی تقسیم کے بعد، تنازعات کی وجہ سے، اور 1979 سے افغان مہاجرین کی آمد
• چرواہوں کی موسمی اور خانہ بدوش نقل و حرکت
• سیلاب اور دیگر آفات سے بے گھر ہونا

تقریباً 90 لاکھ پاکستانی بیرون ملک رہتے ہیں اور ان کی ترسیلات زر سالانہ تقریباً 30 ارب ڈالر ہیں، جو ملک کے لیے زرمبادلہ کا ایک بڑا ذریعہ ہے۔

دھکیلنے والے عوامل: غربت، بے روزگاری، آفات۔ کھینچنے والے عوامل: روزگار، تعلیم اور بہتر سہولتیں۔
"""),

    c("12.7",
"""
Pakistan's population is growing quickly.

• Growth rate: about 2.5% a year, higher than many neighbours
• At this rate the population would double in about 28 years.
• Fertility: about 3.6 children per woman
• Reasons: high birth rate, falling death rate, early marriage and limited family planning
• Youth bulge: about 64% of people are under 30 years old.
• Pressure on water, land, schools, hospitals and jobs
• Opportunity: a young workforce can power growth if it is educated and employed.

Measures: girls' education, health services, family planning and job creation.
""",
"""
پاکستان کی آبادی تیزی سے بڑھ رہی ہے۔

• شرح نمو: سالانہ تقریباً 2.5 فیصد، کئی ہمسایوں سے زیادہ
• اسی شرح سے آبادی تقریباً 28 سال میں دگنی ہو جائے گی۔
• شرح پیدائش: ہر عورت کے تقریباً 3.6 بچے
• وجوہات: بلند شرح پیدائش، شرح اموات میں کمی، کم عمری کی شادی اور خاندانی منصوبہ بندی کی محدود سہولت
• نوجوانوں کا ابھار: تقریباً 64 فیصد لوگ 30 سال سے کم عمر ہیں۔
• پانی، زمین، اسکولوں، اسپتالوں اور روزگار پر دباؤ
• موقع: تعلیم یافتہ اور برسرروزگار نوجوان افرادی قوت ترقی کی طاقت بن سکتی ہے۔

اقدامات: لڑکیوں کی تعلیم، صحت کی سہولتیں، خاندانی منصوبہ بندی اور روزگار کے مواقع۔
"""),

    c("12.8",
"""
Human resources are the skills, knowledge and health of a country's people.

• Literacy rate: about 60%, with big gaps between men and women, and between cities and villages
• Labour force: roughly 70 million people
• Jobs: about 37% in agriculture, about a quarter in industry and the rest in services (approximate)
• Women's participation in paid work is low, at around a quarter.
• Millions of Pakistanis work abroad.
• IT services and freelancing are growing.

To use the youth bulge well, Pakistan needs better schools, technical and vocational training, health care and jobs.
""",
"""
انسانی وسائل کسی ملک کے لوگوں کی مہارت، علم اور صحت ہیں۔

• شرح خواندگی: تقریباً 60 فیصد، مردوں اور عورتوں اور شہروں اور دیہات کے درمیان بڑے فرق کے ساتھ
• افرادی قوت: تقریباً 7 کروڑ افراد
• روزگار: تقریباً 37 فیصد زراعت میں، تقریباً چوتھائی صنعت میں اور باقی خدمات میں (تقریبی)
• عورتوں کی اجرتی کام میں شرکت کم ہے، تقریباً چوتھائی۔
• لاکھوں پاکستانی بیرون ملک کام کرتے ہیں۔
• آئی ٹی خدمات اور فری لانسنگ بڑھ رہی ہیں۔

نوجوانوں کے ابھار سے اچھا فائدہ اٹھانے کے لیے پاکستان کو بہتر اسکولوں، فنی تربیت، صحت کی سہولتوں اور روزگار کی ضرورت ہے۔
"""),

    // ================= TOPIC 13 =================
    c("13.0",
"""
Pakistan lies where the Indian and Eurasian tectonic plates meet, so earthquakes are common, especially in the north and west.

Main fault zones: the Himalayan and Hindu Kush region, the Chaman Fault and the Makran subduction zone.

Major earthquakes:
• 1935 Quetta: tens of thousands killed
• 1945 Makran: caused a tsunami
• 2005 Kashmir (8 October): about 75,000–87,000 dead and millions homeless
• 2013 Awaran (Balochistan)
• 2015 Hindu Kush
• 2019 Mirpur (Azad Kashmir)

Safety: earthquake-resistant building codes, drills and public awareness. ERRA and NDMA manage reconstruction and response.
""",
"""
پاکستان وہاں واقع ہے جہاں ہندوستانی اور یوریشیائی ٹیکٹونک پلیٹیں ملتی ہیں، اس لیے زلزلے عام ہیں، خاص طور پر شمال اور مغرب میں۔

اہم فالٹ علاقے: ہمالیہ اور ہندوکش کا علاقہ، چمن فالٹ اور مکران سبڈکشن زون۔

بڑے زلزلے:
• 1935 کوئٹہ: دسیوں ہزار ہلاکتیں
• 1945 مکران: سونامی آئی
• 2005 کشمیر (8 اکتوبر): تقریباً 75,000 تا 87,000 ہلاکتیں اور لاکھوں بے گھر
• 2013 آواران (بلوچستان)
• 2015 ہندوکش
• 2019 میرپور (آزاد کشمیر)

حفاظت: زلزلہ برداشت کرنے والے تعمیراتی ضابطے، مشقیں اور عوامی آگاہی۔ ایرا اور این ڈی ایم اے تعمیر نو اور امداد سنبھالتے ہیں۔
"""),

    c("13.1",
"""
Floods are Pakistan's most frequent and costly natural disaster.

Causes:
• Heavy monsoon rain
• Snow and glacier melt, and glacial lake outbursts
• River banks overflowing, and poor drainage
• Cutting of forests and building on flood plains

Major floods: 1950, 1973, 1992, 2010 (about 20 million affected) and 2022 (about 33 million affected, more than 1,700 deaths, with Sindh and Balochistan hit hardest).

Effects: loss of life, homes, crops and livestock, damaged roads and bridges, disease and displacement.

Control: dams and embankments, river training, early warning, flood forecasting, afforestation and keeping flood plains free of building.
""",
"""
سیلاب پاکستان کی سب سے زیادہ بار آنے والی اور مہنگی قدرتی آفت ہے۔

اسباب:
• شدید مون سون بارش
• برف اور گلیشیئر کا پگھلنا، اور گلیشیائی جھیلوں کا پھٹنا
• دریا کے کناروں کا ٹوٹنا، اور ناقص نکاسی
• جنگلات کی کٹائی اور سیلابی میدانوں میں تعمیر

بڑے سیلاب: 1950، 1973، 1992، 2010 (تقریباً 2 کروڑ متاثر) اور 2022 (تقریباً 3.3 کروڑ متاثر، 1,700 سے زیادہ اموات، سندھ اور بلوچستان سب سے زیادہ متاثر)۔

اثرات: جانی نقصان، گھروں، فصلوں اور مویشیوں کا نقصان، سڑکوں اور پلوں کی تباہی، بیماریاں اور بے گھری۔

روک تھام: ڈیم اور پشتے، دریاؤں کی تربیت، پیشگی انتباہ، سیلاب کی پیشگوئی، شجرکاری اور سیلابی میدانوں کو تعمیر سے خالی رکھنا۔
"""),

    c("13.2",
"""
Drought is a long period of very little rain.

Areas most at risk: Thar and Cholistan, Balochistan (Kharan, Chagai, Zhob) and parts of Sindh.

Causes:
• Low or failed rainfall and western disturbances
• High temperatures and evaporation
• Poor water management
• Climate change

Effects:
• Crop failure and death of livestock
• Falling groundwater and drying wells
• Hunger, malnutrition and migration
• The severe drought of 1998–2002 hit Balochistan and Sindh badly.

Measures: rainwater harvesting, small dams and ponds, efficient irrigation, drought-tolerant crops, tree planting and early warning.
""",
"""
خشک سالی کم یا بالکل نہ ہونے والی بارش کا لمبا دور ہے۔

سب سے زیادہ خطرے والے علاقے: تھر اور چولستان، بلوچستان (خاران، چاغی، ژوب) اور سندھ کے کچھ حصے۔

اسباب:
• کم یا ناکام بارش اور مغربی ہواؤں کی کمی
• بلند درجہ حرارت اور بخارات
• پانی کا ناقص انتظام
• موسمیاتی تبدیلی

اثرات:
• فصلوں کی ناکامی اور مویشیوں کی موت
• زیر زمین پانی کی سطح گرنا اور کنوؤں کا خشک ہونا
• بھوک، غذائی قلت اور نقل مکانی
• 1998 تا 2002 کی شدید خشک سالی نے بلوچستان اور سندھ کو بری طرح متاثر کیا۔

اقدامات: بارش کے پانی کا ذخیرہ، چھوٹے ڈیم اور تالاب، مؤثر آبپاشی، خشک سالی برداشت کرنے والی فصلیں، شجرکاری اور پیشگی انتباہ۔
"""),

    c("13.3",
"""
A landslide is the downhill movement of rock, soil and mud.

Causes:
• Steep slopes and weak rock
• Heavy rain and melting snow
• Earthquakes
• Cutting of trees and road building on slopes

Risk areas: Murree and the Galiyat, Kaghan, Swat, Neelum Valley, Chitral and Gilgit-Baltistan (including the Karakoram Highway).

Examples: the Attabad landslide (2010) that formed a lake in Hunza, and the Hattian Bala landslide after the 2005 earthquake.

Effects: blocked roads, destroyed villages, temporary lakes and deaths.

Measures: retaining walls, slope stabilisation, planting trees, drainage, warnings and controls on building.
""",
"""
لینڈ سلائیڈنگ چٹانوں، مٹی اور کیچڑ کا ڈھلوان سے نیچے کھسکنا ہے۔

اسباب:
• عمودی ڈھلوانیں اور کمزور چٹانیں
• شدید بارش اور پگھلتی برف
• زلزلے
• ڈھلوانوں پر درختوں کی کٹائی اور سڑکوں کی تعمیر

خطرے والے علاقے: مری اور گلیات، کاغان، سوات، وادی نیلم، چترال اور گلگت بلتستان (قراقرم ہائی وے سمیت)۔

مثالیں: عطا آباد کی لینڈ سلائیڈنگ (2010) جس نے ہنزہ میں جھیل بنا دی، اور 2005 کے زلزلے کے بعد ہٹیاں بالا کی لینڈ سلائیڈنگ۔

اثرات: سڑکیں بند، گاؤں تباہ، عارضی جھیلیں اور اموات۔

اقدامات: روکنے والی دیواریں، ڈھلوانوں کی مضبوطی، شجرکاری، نکاسی، پیشگی انتباہ اور تعمیر پر پابندیاں۔
"""),

    c("13.4",
"""
Pakistan has more than 7,000 glaciers, more than any country outside the polar regions. They are in the Karakoram, Himalaya and Hindu Kush.

• Many Himalayan and Hindu Kush glaciers are retreating.
• Parts of the Karakoram have been unusually stable, which scientists call the "Karakoram anomaly".
• Melting is increasing because of rising temperatures.

Dangers:
• Glacial lake outburst floods (GLOFs): thousands of glacial lakes have formed, and dozens are considered dangerous.
• More floods in the short term, but less river water in the long term.
• Glacier surges, such as the Shisper glacier in Hunza (2022), block rivers and damage roads.

Response: monitoring, early-warning systems, community training and cutting greenhouse gases.
""",
"""
پاکستان میں 7,000 سے زیادہ گلیشیئر ہیں، جو قطبی علاقوں سے باہر کسی بھی ملک سے زیادہ ہیں۔ یہ قراقرم، ہمالیہ اور ہندوکش میں ہیں۔

• ہمالیہ اور ہندوکش کے بہت سے گلیشیئر پیچھے ہٹ رہے ہیں۔
• قراقرم کے کچھ حصے غیر معمولی طور پر مستحکم رہے ہیں، جسے سائنس دان "قراقرم کی انوکھی صورت" کہتے ہیں۔
• بڑھتے درجہ حرارت سے پگھلاؤ بڑھ رہا ہے۔

خطرات:
• گلیشیائی جھیلوں کے پھٹنے سے سیلاب (جی ایل او ایف): ہزاروں گلیشیائی جھیلیں بن چکی ہیں، اور درجنوں خطرناک سمجھی جاتی ہیں۔
• مختصر مدت میں زیادہ سیلاب، لیکن طویل مدت میں دریاؤں میں کم پانی۔
• گلیشیئر کا تیزی سے آگے بڑھنا، جیسے ہنزہ میں شسپر گلیشیئر (2022)، دریا بند کر دیتا ہے اور سڑکیں تباہ کرتا ہے۔

ردعمل: نگرانی، پیشگی انتباہی نظام، برادریوں کی تربیت اور گرین ہاؤس گیسوں میں کمی۔
"""),

    c("13.5",
"""
Climate change means long-term changes in temperature and weather patterns.

• Pakistan produces less than 1% of the world's greenhouse gases but is among the countries most affected.
• Effects: heatwaves, severe floods (2010, 2022), droughts, retreating glaciers, irregular monsoon, sea-level rise at the Indus Delta and lower crop yields
• Affects water, food, health and the economy.

Responses:
• National Climate Change Policy
• Tree-planting drives such as the Billion and Ten Billion Tree programmes
• Renewable energy (solar, wind and hydro)
• Water conservation and climate-smart farming
• Early-warning systems

Pakistan led the push at the 2022 UN climate conference for a fund for climate "loss and damage".
""",
"""
موسمیاتی تبدیلی کا مطلب درجہ حرارت اور موسمی انداز میں طویل مدتی تبدیلیاں ہیں۔

• پاکستان دنیا کی گرین ہاؤس گیسوں کا 1 فیصد سے کم پیدا کرتا ہے مگر سب سے زیادہ متاثر ممالک میں شامل ہے۔
• اثرات: ہیٹ ویو، شدید سیلاب (2010، 2022)، خشک سالی، گلیشیئروں کا پیچھے ہٹنا، بے قاعدہ مون سون، ڈیلٹا میں سمندر کی سطح بلند ہونا اور فصلوں کی کم پیداوار
• یہ پانی، خوراک، صحت اور معیشت کو متاثر کرتی ہے۔

اقدامات:
• قومی موسمیاتی تبدیلی پالیسی
• بلین اور ٹین بلین ٹری جیسی شجرکاری مہمات
• قابل تجدید توانائی (شمسی، ہوا اور پن بجلی)
• پانی کی بچت اور موسم دوست کاشت کاری
• پیشگی انتباہی نظام

پاکستان نے 2022 کی اقوام متحدہ کی موسمیاتی کانفرنس میں موسمیاتی "نقصان اور تلافی" کے فنڈ کے لیے کوششوں کی قیادت کی۔
"""),

    c("13.6",
"""
Air pollution is a serious problem in many Pakistani cities.

Causes:
• Smoke from vehicles, especially old ones and poor fuel
• Factories and brick kilns
• Burning of crop residue and rubbish
• Dust and construction
• Coal and oil burned for power

Smog: in October–January a thick smog often covers Punjab, and Lahore sometimes ranks among the most polluted cities in the world.

Health effects: asthma, lung and heart disease, eye irritation and a shorter life.

Measures: cleaner fuel, zig-zag brick kilns, a ban on stubble burning, public transport, trees, smog action plans and air-quality monitoring.
""",
"""
فضائی آلودگی پاکستان کے کئی شہروں میں ایک سنگین مسئلہ ہے۔

اسباب:
• گاڑیوں کا دھواں، خاص طور پر پرانی گاڑیاں اور ناقص ایندھن
• کارخانے اور اینٹوں کے بھٹے
• فصلوں کی باقیات اور کچرا جلانا
• گرد اور تعمیراتی کام
• بجلی کے لیے جلنے والا کوئلہ اور تیل

سموگ: اکتوبر سے جنوری تک گہری سموگ اکثر پنجاب کو ڈھانپ لیتی ہے، اور لاہور کبھی کبھی دنیا کے آلودہ ترین شہروں میں شمار ہوتا ہے۔

صحت پر اثرات: دمہ، پھیپھڑوں اور دل کی بیماریاں، آنکھوں میں جلن اور عمر میں کمی۔

اقدامات: صاف ایندھن، زِگ زیگ بھٹے، فصلوں کی باقیات جلانے پر پابندی، پبلک ٹرانسپورٹ، درخت، سموگ ایکشن پلان اور ہوا کے معیار کی نگرانی۔
"""),

    c("13.7",
"""
Water pollution makes water unsafe for drinking, farming and wildlife.

Causes:
• Untreated sewage poured into rivers and canals
• Factory waste and chemicals
• Fertiliser and pesticide runoff from farms
• Solid waste dumped in drains and rivers
• Natural arsenic in groundwater in parts of Punjab and Sindh

Affected waters: rivers such as the Ravi and Kabul, the Lyari River in Karachi, lakes such as Manchar, and the coast near Karachi.

Health effects: diarrhoea, typhoid, hepatitis and cholera, especially in children.

Measures: sewage treatment plants, strict rules for factories, safe drinking-water filtration, hygiene education and clean-up of waterways.
""",
"""
آبی آلودگی پانی کو پینے، کاشت کاری اور جنگلی حیات کے لیے غیر محفوظ بنا دیتی ہے۔

اسباب:
• دریاؤں اور نہروں میں ڈالا جانے والا غیر صاف شدہ گندا پانی
• کارخانوں کا فضلہ اور کیمیکل
• کھیتوں سے بہہ کر آنے والی کھاد اور کیڑے مار ادویات
• نالوں اور دریاؤں میں پھینکا جانے والا ٹھوس کچرا
• پنجاب اور سندھ کے کچھ حصوں میں زیر زمین پانی میں قدرتی سنکھیا

متاثرہ پانی: راوی اور کابل جیسے دریا، کراچی کا دریائے لیاری، منچھر جیسی جھیلیں، اور کراچی کے قریب ساحل۔

صحت پر اثرات: اسہال، ٹائیفائیڈ، ہیپاٹائٹس اور ہیضہ، خاص طور پر بچوں میں۔

اقدامات: گندے پانی کی صفائی کے پلانٹ، کارخانوں کے لیے سخت قوانین، پینے کے پانی کی محفوظ فلٹریشن، صفائی کی تعلیم اور آبی گزرگاہوں کی صفائی۔
"""),

    c("13.8",
"""
Soil erosion is the wearing away of the top layer of fertile soil.

Types:
• Water erosion: gullies and ravines on the Potohar and Hazara slopes
• Wind erosion: in the Thal, Cholistan and Thar deserts
• River-bank erosion: along the Indus in floods
• Coastal erosion: in the Indus Delta

Causes: cutting of trees, over-grazing, steep slopes, heavy rain and poor farming methods.

Effects: loss of fertile land, silting of dams (such as Tarbela and Mangla) and lower yields.

Measures: terracing, contour ploughing, planting trees and windbreaks, check dams and controlled grazing.
""",
"""
مٹی کا کٹاؤ زرخیز مٹی کی اوپری تہہ کا بہہ جانا یا اڑ جانا ہے۔

اقسام:
• پانی کا کٹاؤ: پوٹھوہار اور ہزارہ کی ڈھلوانوں پر نالے اور کھائیاں
• ہوا کا کٹاؤ: تھل، چولستان اور تھر کے صحراؤں میں
• دریائی کناروں کا کٹاؤ: سیلاب میں دریائے سندھ کے ساتھ
• ساحلی کٹاؤ: دریائے سندھ کے ڈیلٹا میں

اسباب: درختوں کی کٹائی، ضرورت سے زیادہ چرائی، عمودی ڈھلوانیں، شدید بارش اور کاشت کاری کے ناقص طریقے۔

اثرات: زرخیز زمین کا نقصان، ڈیموں (جیسے تربیلا اور منگلا) میں گاد بھرنا اور کم پیداوار۔

اقدامات: سیڑھی دار کھیت، ڈھلوان کے ساتھ ہل چلانا، درخت اور ہوا روکنے والی باڑیں لگانا، چھوٹے بند اور چرائی پر قابو۔
"""),

    c("13.9",
"""
Desertification is the spread of desert-like conditions into land that was once productive.

• Most of Pakistan is already arid or semi-arid.
• Areas most affected: Thal, Cholistan, Thar, Kharan and parts of Sindh and Balochistan
• Causes: deforestation, over-grazing, unsustainable farming, wind erosion, salinity and climate change
• Effects: loss of farmland and pasture, dust storms, poverty and migration
• World Day to Combat Desertification and Drought is 17 June.

Measures: planting trees and shelterbelts, stabilising sand dunes, rainwater harvesting, drought-tolerant plants, controlled grazing and better irrigation.
""",
"""
صحرا بننا یا صحرائی پھیلاؤ ان زمینوں میں صحرا جیسے حالات کا پھیلنا ہے جو پہلے زرخیز تھیں۔

• پاکستان کا زیادہ تر حصہ پہلے ہی خشک یا نیم خشک ہے۔
• سب سے زیادہ متاثرہ علاقے: تھل، چولستان، تھر، خاران اور سندھ اور بلوچستان کے کچھ حصے
• اسباب: جنگلات کی کٹائی، ضرورت سے زیادہ چرائی، غیر پائیدار کاشت کاری، ہوا کا کٹاؤ، کھاری پن اور موسمیاتی تبدیلی
• اثرات: کھیتوں اور چراگاہوں کا نقصان، گرد کے طوفان، غربت اور نقل مکانی
• صحرا بننے اور خشک سالی کے خلاف عالمی دن 17 جون ہے۔

اقدامات: درخت اور ہوا روکنے والی پٹیاں لگانا، ریت کے ٹیلوں کو مستحکم کرنا، بارش کے پانی کا ذخیرہ، خشک سالی برداشت کرنے والے پودے، چرائی پر قابو اور بہتر آبپاشی۔
""")
)

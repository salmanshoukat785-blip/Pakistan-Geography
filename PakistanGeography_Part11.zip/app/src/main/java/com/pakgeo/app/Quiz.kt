@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class
)

package com.pakgeo.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import kotlinx.coroutines.delay
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private val GOOD = Color(0xFF2E7D32)
private val BAD = Color(0xFFC62828)

// ---------- Session ----------
class QuizItem(val q: Q, val order: List<Int>)

class QuizSession(val mode: String, val items: List<QuizItem>, val timeLimit: Int = 0) {
    val userAns = MutableList<String?>(items.size) { null }

    fun correctShown(i: Int): Int = items[i].order.indexOf(items[i].q.answer)

    fun isCorrect(i: Int): Boolean {
        val item = items[i]
        val a = userAns[i] ?: return false
        return if (item.q.type == 2) matchesFib(item.q, a) else a == correctShown(i).toString()
    }

    fun score(): Int = items.indices.count { isCorrect(it) }

    fun userAnswerText(i: Int, lang: String): String {
        val item = items[i]
        val a = userAns[i] ?: return "—"
        if (item.q.type == 2) return a
        val idx = a.toIntOrNull() ?: return "—"
        val p = item.q.opts[item.order[idx]]
        return if (lang == "ur") p.second else p.first
    }
}

object Hold { var session: QuizSession? = null }

private fun norm(s: String): String =
    s.trim().lowercase().replace(Regex("\\s+"), " ").trimEnd('.')

fun matchesFib(q: Q, text: String): Boolean {
    val n = norm(text)
    return n.isNotEmpty() && q.alts.any { norm(it) == n }
}

fun makeSession(mode: String, pool: List<Q>, count: Int, rnd: Random = Random.Default, timeLimit: Int = 0): QuizSession {
    val items = pool.shuffled(rnd).take(count).map { q ->
        val order = if (q.type == 0) q.opts.indices.shuffled(rnd) else q.opts.indices.toList()
        QuizItem(q, order)
    }
    return QuizSession(mode, items, timeLimit)
}

fun modeName(mode: String, lang: String): String = when (mode) {
    "quiz" -> if (lang == "ur") "کوئز" else "Quiz"
    "self" -> if (lang == "ur") "سیلف ٹیسٹ" else "Self Test"
    "daily" -> if (lang == "ur") "روزانہ چیلنج" else "Daily Challenge"
    "paper" -> if (lang == "ur") "پچھلے پرچے" else "Past Papers"
    else -> if (lang == "ur") "غلطیوں کی مشق" else "Mistakes Practice"
}

// ---------- Setup ----------
@Composable
fun QuizSetupScreen(mode: String, nav: (String) -> Unit, onBack: () -> Unit) {
    val lang = LocalLang.current
    var sel by remember { mutableStateOf(setOf<Int>()) }
    var diff by remember { mutableStateOf(-1) }
    var src by remember { mutableStateOf("") }
    var count by remember { mutableStateOf(10) }
    var timer by remember { mutableStateOf(0) }
    val counts = if (mode == "self") listOf(5, 10, 20, 30) else listOf(5, 10, 15)

    val pool = allQuestions.filter { q ->
        (sel.isEmpty() || q.topic in sel) &&
            (mode == "paper" || diff == -1 || q.diff == diff) &&
            (mode != "paper" || (q.src.isNotEmpty() && (src.isEmpty() || q.src == src)))
    }

    PageScaffold(modeName(mode, lang), onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionTitle(
                if (mode == "self") tr("Choose topics (one or more)", "موضوعات منتخب کریں (ایک یا زیادہ)")
                else tr("Choose topic", "موضوع منتخب کریں")
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = sel.isEmpty(), onClick = { sel = emptySet() }, label = { Text(tr("All", "سب")) })
                topics.forEach { t ->
                    FilterChip(
                        selected = t.id in sel,
                        onClick = {
                            sel = if (mode == "self") {
                                if (t.id in sel) sel - t.id else sel + t.id
                            } else {
                                if (sel == setOf(t.id)) emptySet() else setOf(t.id)
                            }
                        },
                        label = { Text("${t.emoji} ${if (lang == "ur") t.ur else t.en}", fontSize = 12.sp) }
                    )
                }
            }

            if (mode == "paper") {
                SectionTitle(tr("Exam style", "امتحان کا انداز"))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("" to tr("All", "سب"), "CSS" to "CSS", "PMS" to "PMS", "NTS" to "NTS").forEach { (k, label) ->
                        FilterChip(selected = src == k, onClick = { src = k }, label = { Text(label) })
                    }
                }
            } else {
                SectionTitle(tr("Difficulty", "مشکل کی سطح"))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        -1 to tr("All", "سب"),
                        0 to tr("Easy", "آسان"),
                        1 to tr("Medium", "درمیانہ"),
                        2 to tr("Hard", "مشکل"),
                        3 to "CSS / PMS"
                    ).forEach { (k, label) ->
                        FilterChip(selected = diff == k, onClick = { diff = k }, label = { Text(label) })
                    }
                }
            }

            SectionTitle(tr("Number of questions", "سوالات کی تعداد"))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                counts.forEach { n ->
                    FilterChip(selected = count == n, onClick = { count = n }, label = { Text("$n") })
                }
            }

            SectionTitle(tr("Time per question", "ہر سوال کا وقت"))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to tr("No timer", "بغیر ٹائمر"), 15 to "15 s", 30 to "30 s", 60 to "60 s").forEach { (k, label) ->
                    FilterChip(selected = timer == k, onClick = { timer = k }, label = { Text(label) })
                }
            }

            Text(
                tr("Available questions: ${pool.size}", "دستیاب سوالات: ${pool.size}"),
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
            Button(
                enabled = pool.isNotEmpty(),
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Hold.session = makeSession(mode, pool, count, timeLimit = timer)
                    nav("play")
                }
            ) { Text(tr("Start", "شروع کریں")) }
        }
    }
}

// ---------- Play ----------
@Composable
fun PlayScreen(prefs: Prefs, replace: (String) -> Unit, onBack: () -> Unit) {
    val session = Hold.session
    if (session == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val lang = LocalLang.current
    var idx by remember { mutableStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var fibText by remember { mutableStateOf("") }
    var timedOut by remember { mutableStateOf(false) }
    var left by remember { mutableStateOf(session.timeLimit) }
    val n = session.items.size
    val item = session.items[idx]
    val q = item.q

    fun answer(a: String) {
        if (locked) return
        session.userAns[idx] = a
        locked = true
        prefs.noteAnswer(q.id, session.isCorrect(idx))
    }

    fun next() {
        if (idx < n - 1) {
            idx += 1
            locked = false
            fibText = ""
            timedOut = false
        } else {
            val score = session.score()
            prefs.saveResult(session.mode, score, n)
            if (session.mode == "daily") {
                val today = LocalDate.now()
                prefs.completeDaily(today.toString(), today.minusDays(1).toString(), score, n)
            }
            replace("result")
        }
    }

    LaunchedEffect(idx) {
        if (session.timeLimit > 0) {
            left = session.timeLimit
            while (left > 0 && !locked) {
                delay(1000)
                if (!locked) left -= 1
            }
            if (!locked && left <= 0) {
                locked = true
                timedOut = true
                prefs.noteAnswer(session.items[idx].q.id, false)
            }
        }
    }

    PageScaffold("${modeName(session.mode, lang)}  ${idx + 1} / $n", onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LinearProgressIndicator(progress = { (idx + 1).toFloat() / n }, modifier = Modifier.fillMaxWidth())
            if (session.timeLimit > 0) {
                Text(
                    "⏱ $left", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    color = if (left <= 5 && !locked) BAD else MaterialTheme.colorScheme.primary
                )
            }
            Text(
                topicTitle(q.topic, lang) + if (q.src.isNotEmpty()) "  •  ${q.src}" else "",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.primary
            )
            Text(
                q.text(lang), fontSize = 19.sp, fontWeight = FontWeight.SemiBold, lineHeight = 30.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            if (q.type == 2) {
                OutlinedTextField(
                    value = fibText,
                    onValueChange = { if (!locked) fibText = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(tr("Type your answer", "اپنا جواب لکھیں")) }
                )
                if (!locked) {
                    Button(
                        enabled = fibText.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { answer(fibText) }
                    ) { Text(tr("Check", "جانچیں")) }
                }
            } else {
                item.order.forEachIndexed { shown, orig ->
                    val p = q.opts[orig]
                    val isRight = shown == session.correctShown(idx)
                    val isPicked = session.userAns[idx] == shown.toString()
                    val bg = when {
                        locked && isRight -> GOOD.copy(alpha = 0.25f)
                        locked && isPicked -> BAD.copy(alpha = 0.25f)
                        else -> MaterialTheme.colorScheme.surface
                    }
                    Card(
                        onClick = { answer(shown.toString()) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = bg),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (lang == "ur") p.second else p.first,
                            fontSize = 16.sp, modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (locked) {
                val ok = session.isCorrect(idx)
                Text(
                    if (ok) tr("✓ Correct!", "✓ درست!") else if (timedOut) tr("⏰ Time is up", "⏰ وقت ختم") else tr("✗ Wrong", "✗ غلط"),
                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (ok) GOOD else BAD
                )
                if (!ok) {
                    Text(
                        tr("Correct answer: ", "درست جواب: ") + q.correctText(lang),
                        fontSize = 15.sp, color = MaterialTheme.colorScheme.onBackground
                    )
                }
                if (q.exp(lang).isNotEmpty()) {
                    Text(
                        q.exp(lang), fontSize = 14.sp, lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                    )
                }
                Button(onClick = { next() }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (idx < n - 1) tr("Next", "اگلا") else tr("Finish", "مکمل کریں"))
                }
            }
        }
    }
}

// ---------- Review card ----------
@Composable
fun ReviewCard(q: Q, yourAnswer: String?, lang: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                topicTitle(q.topic, lang), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary
            )
            Text(q.text(lang), fontSize = 16.sp, fontWeight = FontWeight.SemiBold, lineHeight = 26.sp,
                color = MaterialTheme.colorScheme.onSurface)
            if (yourAnswer != null) {
                Text(tr("Your answer: ", "آپ کا جواب: ") + yourAnswer, fontSize = 14.sp, color = BAD)
            }
            Text(tr("Correct answer: ", "درست جواب: ") + q.correctText(lang), fontSize = 14.sp, color = GOOD)
            if (q.exp(lang).isNotEmpty()) {
                Text(
                    q.exp(lang), fontSize = 13.sp, lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

// ---------- Result ----------
@Composable
fun ResultScreen(prefs: Prefs, home: () -> Unit, onBack: () -> Unit) {
    val session = Hold.session
    if (session == null) {
        LaunchedEffect(Unit) { home() }
        return
    }
    val lang = LocalLang.current
    val context = LocalContext.current
    val n = session.items.size
    val score = session.score()
    val pct = if (n == 0) 0 else score * 100 / n
    val wrong = session.items.indices.filter { !session.isCorrect(it) }
    val msg = when {
        pct >= 80 -> tr("Excellent!", "شاندار!")
        pct >= 50 -> tr("Good, keep practising", "اچھا، مشق جاری رکھیں")
        else -> tr("Needs more practice", "مزید مشق کی ضرورت ہے")
    }

    PageScaffold(tr("Result", "نتیجہ"), onBack) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(modeName(session.mode, lang), fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Text("$score / $n", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("$pct%", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(6.dp))
                        Text(msg, fontSize = 16.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            item {
                Button(onClick = home, modifier = Modifier.fillMaxWidth()) { Text(tr("Home", "ہوم")) }
            }
            item {
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val text = "I scored $score/$n ($pct%) in the Pakistan Geography quiz!"
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(i, null))
                    }
                ) { Text(tr("Share score", "اسکور شیئر کریں")) }
            }
            if (wrong.isNotEmpty()) {
                item { SectionTitle(tr("Review wrong answers", "غلط جوابات کا جائزہ")) }
                items(wrong) { i ->
                    ReviewCard(session.items[i].q, session.userAnswerText(i, lang), lang)
                }
            }
        }
    }
}

// ---------- All saved mistakes ----------
@Composable
fun ReviewScreen(prefs: Prefs, nav: (String) -> Unit, onBack: () -> Unit) {
    val lang = LocalLang.current
    val list = allQuestions.filter { it.id in prefs.wrongIds }
    PageScaffold(tr("Mistakes", "غلطیاں"), onBack) { pad ->
        if (list.isEmpty()) {
            EmptyMessage(
                pad,
                tr(
                    "No mistakes saved. Questions you answer wrongly appear here until you get them right.",
                    "کوئی غلطی محفوظ نہیں۔ جو سوالات آپ غلط حل کریں گے وہ درست جواب دینے تک یہاں نظر آئیں گے۔"
                )
            )
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val s = makeSession("review", list, list.size)
                            Hold.session = s
                            nav("play")
                        }
                    ) { Text(tr("Practice these (${list.size})", "ان کی مشق کریں (${list.size})")) }
                }
                items(list) { q -> ReviewCard(q, null, lang) }
            }
        }
    }
}

// ---------- Scores ----------
@Composable
fun ScoresScreen(prefs: Prefs, onBack: () -> Unit) {
    val lang = LocalLang.current
    val entries = prefs.history.split(";").filter { it.isNotBlank() }.mapNotNull {
        val p = it.split(",")
        if (p.size < 4) null
        else {
            val ts = p[0].toLongOrNull()
            val sc = p[2].toIntOrNull()
            val tot = p[3].toIntOrNull()
            if (ts == null || sc == null || tot == null) null else listOf(ts, p[1], sc, tot)
        }
    }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()) }

    PageScaffold(tr("Scores", "اسکور"), onBack) { pad ->
        if (entries.isEmpty()) {
            EmptyMessage(pad, tr("No scores yet. Take a quiz first.", "ابھی کوئی اسکور نہیں۔ پہلے کوئز دیں۔"))
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { SectionTitle(tr("Best scores", "بہترین اسکور")) }
                items(listOf("quiz", "self", "daily", "paper", "review")) { m ->
                    val best = entries.filter { it[1] == m }.maxOfOrNull { (it[2] as Int) * 100 / maxOf(1, it[3] as Int) }
                    if (best != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(modeName(m, lang), color = MaterialTheme.colorScheme.onBackground)
                            Text("$best%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    SectionTitle(tr("Recent attempts", "حالیہ کوششیں"))
                }
                items(entries.reversed()) { e ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(modeName(e[1] as String, lang), fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text(
                                    fmt.format(Date(e[0] as Long)), fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            Text(
                                "${e[2]} / ${e[3]}", fontSize = 16.sp, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------- Daily challenge ----------
@Composable
fun DailyScreen(prefs: Prefs, nav: (String) -> Unit, onBack: () -> Unit) {
    val today = LocalDate.now()
    val todayS = today.toString()
    val yesterdayS = today.minusDays(1).toString()
    val done = prefs.lastDaily == todayS
    val streak = prefs.effectiveStreak(todayS, yesterdayS)

    PageScaffold(tr("Daily Challenge", "روزانہ چیلنج"), onBack) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("🔥", fontSize = 64.sp)
            Text(
                tr("$streak day streak", "مسلسل $streak دن"),
                fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            if (done) {
                Text(
                    tr("Today's challenge is complete.", "آج کا چیلنج مکمل ہو چکا ہے۔"),
                    fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    tr("Score: ", "اسکور: ") + prefs.lastDailyScore,
                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    tr("Come back tomorrow to keep your streak.", "اپنا سلسلہ قائم رکھنے کے لیے کل دوبارہ آئیں۔"),
                    fontSize = 14.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            } else {
                Text(
                    tr("5 questions, one try per day.", "5 سوالات، روزانہ ایک کوشش۔"),
                    fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        val rnd = Random(today.toEpochDay())
                        Hold.session = makeSession("daily", allQuestions.sortedBy { it.id }, 5, rnd)
                        nav("play")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(tr("Start", "شروع کریں")) }
            }
        }
    }
}
